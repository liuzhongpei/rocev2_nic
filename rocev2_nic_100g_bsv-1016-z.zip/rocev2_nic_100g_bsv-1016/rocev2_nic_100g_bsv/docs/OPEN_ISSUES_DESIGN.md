# RoCEv2 NIC 开放问题:架构分析与修复设计

> 2026-10-12。针对 50 PASS / 0 FAIL 基线上剩余的全部开放项,给出架构级
> 分析与可实施的修复设计。每项含:现状架构、失效机理(均已在本会话验证)、
> 修复设计(具体到接口/规则/信号)、验证计划与风险。

---

## A. per-QP RTO 定时器(核心开放项)

### A.1 现状架构与两次失败

```
现状(RC 层,src/RoCEv2NIC.bsv):
  tx_pump_payload(末拍)──arm──> rc_rto_check(单实例倒计时)──expiry──> rc_retx_req_fifo
  rx_decap_pump(ACK/NAK)─────reload/budget────────────┘        │
                                                                 v
  rc_retx_take(快照 retry store 队头)→ rc_retx_replay(逐拍)
        │                                    │
        │ 重放 = 重新封装:beats → encap payload_fifo + 描述符
        v                                    v
  rc_retry_buffer(FIFO+旋转) <──── rc_ack_clr(ACK 清除)
  rc_retx_payload 环(1024 拍载荷缓存)+ rc_ring_outstanding 记账
```

失败机理(已验证):

| 尝试 | 失败点 |
|---|---|
| 展开式 per-QP 倒计时/扫描 | bsc 固定 33616 字节 elaboration 线程栈溢出(与 -K/GHCRTS/ulimit 无关) |
| 绝对到期 + 游标巡检 | 编译通过、RTO 测试通过;但**重放经由 encap 重新封装成新 ESUN 消息**,与在途 RX 生成帧(ATOMIC_ACK)在 encap 流水线交错 → frame/flag 配对死锁;且重放插入额外 ESUN 消息挪动了测试的 seq 记账 |
| encap_idle 启动门 | 门在"任何帧在途"时饿死重放启动;RX 生成帧与宿主流量共存时流水线几乎从不空闲 → 套件回归 |

根因:重放走 encap = 新 seq + 新窗口槽位 + 与在途帧的交错风险——
三重问题都是"重放旁路了原消息的窗口身份"导致的。

### A.2 关键架构事实(修复的支点)

对 ESUN 层(src/ESUNLinkLayer.bsv)的核对结论:

1. **LLR 环形缓存在发射时无条件填充**(`llr_cache_data/keep/flag.upd`,
   泵的启动/数据分支,行 892/910)——与 `llr_enable` 无关。即:**每个已发
   ESUN 消息的完整线上拍序列(分片头 + 数据 + iCRC)始终在缓存中**,
   由 `llr_outstanding` 容量门保证不被覆盖。
2. **`llr_retx` 已实现按 seq 的原样重放**:守卫含槽位有效性
   (`wnd_valid[slot] && wnd_seq[slot] == req`),重放拍与原发送逐字节一致,
   且与发射/LLR 重放互斥(`!tx_emit_active && !retx_busy`)。
3. **`get_llr_tx_seq` 已暴露**:消息提交时 `llr_tx_seq` 自增,发射使用
   自增后的值 → 发送方在**包的最后一拍**读 `get_llr_tx_seq` 即得到该包的
   ESUN seq。
4. `llr_retx_fifo` 是重放请求的唯一入口(NAK 路径 `enq(ack.ack_seq)`、
   定时器路径 `enq(retx_base)`),`llr_retx` 消费。

### A.3 修复设计:统一重传路径(RC RTO → ESUN LLR retx)

**核心思想:RC RTO 超时不再经由 encap 重发,而是请求 ESUN 重放原消息的
缓存线上拍。** 同一 seq、同一窗口槽位、零新容量、零 encap 交错——A.1 的
三重根因同时消除。

#### 数据结构(RC 层替换)

```bsv
// 删除:rc_retry_buffer(FIFO+旋转)、rc_retx_payload/keep 环、
//       rc_ring_outstanding、rc_ring_skip、rc_retx_* 重放 FSM、
//       rc_ack_clear_fifo/take/step/rot_replay、rc_rot_* 旋转状态、
//       rc_rto_arm/ack pending 组、rc_oldest_unacked_psn
// 保留并新增(per-QP,绝对到期形态——已验证可编译、RTO 测试通过):
Vector#(`NUM_QPS, Reg#(Bit#(32))) rc_rto_expire_v;  // 到期周期号
Vector#(`NUM_QPS, Reg#(Bool))     rc_rto_armed_v;
Vector#(`NUM_QPS, Reg#(Bit#(8)))  rc_rto_budget_v;
Vector#(`NUM_QPS, Reg#(Bit#(24))) rc_rto_apsn_v;    // 最老未确认 RC PSN
Vector#(`NUM_QPS, Reg#(Bit#(8)))  rc_rto_llrseq_v;  // 该包的 ESUN seq
Vector#(`NUM_QPS, Reg#(Bool))     rc_rto_unacked_v; // 有未确认包
Reg#(Bit#(32)) rc_cycles;                            // 自由运行周期计数
Reg#(Bit#(6))  rc_rto_cursor;                        // 巡检游标
```

#### 发送侧(arm)

```bsv
// tx_pump_payload 末拍(仅 RC):
rc_rto_expire_v[qp] <= rc_cycles + dcqcn_ifc.get_rto(qp);
rc_rto_armed_v[qp]  <= True;
rc_rto_unacked_v[qp] <= True;
rc_rto_apsn_v[qp]   <= req.psn;
rc_rto_llrseq_v[qp] <= esun_ifc.get_llr_tx_seq;   // A.2-3:此刻即本包 seq
```

**注意**:一个 QP 同时只跟踪**最老未确认包**(RoCEv2 的 go-back-N 语义
本就允许:超时重发最老未确认者即可)。若最老包已确认而新包未确认,ACK
路径重新 arm(见下)。这是与"逐包重传计时器"的差距,但对正确性无损——
ACK 累积语义下,重发最老未确认包即恢复。

#### 巡检(每拍一个 QP,零展开)

```bsv
rule rc_rto_patrol;
    rc_cycles <= rc_cycles + 1;
    Bit#(8) i = extend(rc_rto_cursor);
    rc_rto_cursor <= wrap_incr(rc_rto_cursor);
    if (rc_rto_unacked_v[i] && rc_rto_armed_v[i] &&
        (rc_cycles - rc_rto_expire_v[i]) < 32'h80000000) begin
        if (rc_rto_budget_v[i] >= `RC_RTO_RETRY_LIMIT) begin
            rc_rto_armed_v[i]  <= False;
            rc_rto_unacked_v[i] <= False;     // 放弃:交给 ESUN 自身的
            rc_rto_budget_v[i] <= 0;          // LLR 放弃机制(7 次上限)收尾
            rc_rto_dropped <= rc_rto_dropped + 1;
        end else begin
            esun_ifc.llr_request_retx(rc_rto_llrseq_v[i]);  // ← 全部改动
            rc_rto_budget_v[i] <= rc_rto_budget_v[i] + 1;
            rc_rto_expire_v[i] <= rc_cycles + dcqcn_ifc.get_rto(i);
        end
    end
endrule
```

#### ESUN 侧新增(一行入队 + 守卫调整)

```bsv
// ESUNLinkLayer 接口新增:
method Action llr_request_retx(Bit#(8) esun_seq);
    llr_retx_fifo.enq(esun_seq);   // llr_retx 的既有槽位校验兜底
endmethod

// llr_retx 守卫调整:请求驱动的重放不受 llr_enable 门控
// (LLR 关闭时接收端忽略 seq,重放无害;缓存始终在填充):
rule llr_retx if (!tx_emit_active && !retx_busy && llr_retx_fifo.notEmpty);
```

#### ACK 路径(大幅简化)

```bsv
// rx_decap_pump 的 ACK 分支:不再需要 retry-store 清除令牌
if (result.opcode == `OPCODE_ACK && result.ack_syndrome == 0) begin
    qp_mgr.update_acked_psn(qp, psn);
    // 该 QP 的重发由 ESUN 自己的窗口滑动消化(ACK 到达即滑动 retx_base、
    // 释放槽位与 llr_outstanding —— 既有机制,无需 RC 侧参与)。
    // 重 arm:若该 QP 仍有更晚的未确认包,重启其倒计时。
    rc_rto_expire_v[qp] <= rc_cycles + dcqcn_ifc.get_rto(qp);
    rc_rto_budget_v[qp] <= 0;
end
```

**NAK 分支**:维持现状(预算记账 + 立即 `llr_request_retx(该 QP 最老
seq)`)——NAK 语义下重发最老未确认包与 go-back-N 一致。

#### 随之消解的开放项

| 开放项 | 消解方式 |
|---|---|
| 跨 QP retry-store 队头阻塞 | retry store 整体退役 |
| retry-store 满 → 全 TX 楔死 | 同上 |
| 重放载荷环覆盖(1024 拍) | 载荷环退役(ESUN LLR 缓存已有独立容量记账) |
| encap 帧原子性 vs 重放 | 重放不再经过 encap |
| READ REQ 重放怪圈 | READ REQ 的 ESUN 消息有正常槽位,重放正常;NAK 预算 bound 语义不变 |

#### 保留与验证

- **保留**:RC 层的 PSN 记账(acked/expected)、重传计数(`rc_retransmits`
  在 `llr_request_retx` 处递增)、放弃计数、RTO 逐 QP 化(核心目标达成)。
- **验证计划**:
  1. RTO 测试原样通过(单 QP、rto=32、无 ACK → 3 次重发 → 放弃);
  2. **新测试**:双 QP(QP0/QP2)并发发送、均无 ACK → 断言**两个 QP 各自**
     独立经历重发与放弃(per-QP 化的直接验证,现有套件无法覆盖);
  3. LLR 关闭下的 RTO 重发(缓存仍在填充、重放不受 llr_enable 门控);
  4. MQP 回归(重发与 ACK 交错)。
- **风险**:
  - ESUN LLR 缓存与 RC RTO 的生命周期耦合:RC 放弃后 ESUN 槽位仍占用,
    由 ESUN 自身的 7 次放弃机制收尾——两条放弃路径独立但都有限次,无死循环;
  - `get_llr_tx_seq` 在末拍读取的正确性依赖"ingest 自增先于 pump 发射"
    的既有顺序(第十二轮已验证);
  - 工作量:约 250 行净删改,主要复杂度在退役清理。**建议作为下一个
    实施项,收益(关闭 4 个开放项)远超风险。**

---

## B. RQE / 接收完成 wr_id(功能项)

### B.1 现状

RX 完成无接收队列:载荷直送主机流(`dma_get_data_stream`),CQE 的
wr_id 硬编码 0,缓冲地址由主机软件约定(测试台按固定地址回数据)。
主机无法区分多个未完成接收。

### B.2 修复设计:主机投递 RQ(接收队列)

```
宿主 ──reg_write(RQ 条目 {wr_id, lkey, len, addr})──> NIC RQ FIFO(深度 N,每 QP 一条或全局)
                                                          │
RX 数据包(is_last)──> RQ 出队 ──> CQE{wr_id, len, qp} ──> cqe_fifo
                                └─> 载荷写宿主缓冲(DMA write,B 相)
                                     或维持流交付(兼容现状)
```

- **最小可用形态**(测试台友好):寄存器接口投递 RQE(地址 0x20xxxxxx,
  载荷 {wr_id[63:0], len[31:0], addr[63:0]},一次一条,FIFO 深度 16);
  `rx_decap_pump` 的 is_last 且需交付时出队一条 → CQE 填 wr_id/长度;
  载荷仍走 `dma_get_data_stream`(不改变既有测试)。
- **完整形态**(后续):载荷按 RQE 的 addr/len DMA 写入宿主内存(B 相),
  长度不匹配按协议报错(CQE_LOC_LEN_ERR)。
- **验证**:新测试——投递 2 条 RQE → 依次收到 2 个带不同 wr_id 的完成。
- **风险**:低。RQ 空时到达的包:维持现状(交付流 + wr_id=0)或报错,
  建议先维持现状(与既有测试兼容)。

---

## C. 接收侧重排序缓冲(与 B 协同)

### C.1 现状与机理

`rx_decap_pump` 的 PSN 校验:失配 → NAK + **仍交付**(错误 CQE,
第二十轮)——因为无缓冲可暂存。乱序/重复包污染主机流(语义上 host 应
忽略该 CQE,但数据流已被扰动)。

### C.2 修复设计(依赖 B 的 RQE)

```
expected == psn  ──> 交付(现状)
expected <  psn  ──> 乱序:包写入 OOO 缓冲(按 psn 索引的小型包存储,
                       建议 4-8 包),发 NAK,不交付
expected >  psn  ──> 重复:丢弃 + 重发 ACK
OOO 缓冲头部补齐  ──> 依次交付 + 补发累积 ACK
```

- 存储:每槽 = 完整包载荷(≤ 9216B)+ 元数据;4 槽 ≈ 36KB——与重传环
  同量级,可接受。
- 与 A 的交互:A 落地后 ESUN 层重放与 OOO 无关(OOO 在 RC/载荷层)。
- **建议**:与 B 同期实施(B 提供交付目标,C 提供正确性);二者合计是
  "RC 接收侧完整化"的自然单元。
- **风险**:中。OOO 缓冲满时的策略(丢弃 + NAK)需明确;与流交付模式
  (现有测试)的兼容开关必须保留。

---

## D. atomic_start_fifo 队头阻塞(小项)

### D.1 机理

`atomic_start_fifo`(深度 1)的 notFull 与 `aux_atomic_fifo`/encap FIFO
一起并入 `rx_decap_pump` 守卫;一个未处理原子请求阻塞全部 RX。

### D.2 修复

- 深度 1 是**正确性**要求:原子上下文寄存器(atomic_qp/psn/va/a/b/...)
  单实例,深度 >1 会让并发原子互相覆盖。
- **修复**:上下文改为 `FIFOF#(AtomicCtx)`(深度 4)——原子请求的完整
  上下文在 rx_decap_pump 处打包入队,`atomic_proc` 整包出队使用。
  消除共享寄存器后 `atomic_start_fifo` 可加深到 4,HOL 减轻 4×。
- **风险**:低(纯局部重构,无跨模块交互)。可与 A 的清理同期做。

---

## E. CQ 未排空耦合(缓解已做,根解在宿主/中断)

`cqe_fifo`(32)的 notFull 仍并入 TX/RX drain 守卫。根解:

1. **中断/写门铃**:CQE 就绪即向宿主发 MSI-X(真实 RNIC 的做法)——
   项目当前无中断子系统,属于 PCIe 域工作;
2. **CQ 溢出语义**:已有(丢弃 + 计数)。建议补:溢出计数暴露到寄存器
   (一行),并在 README 明确"宿主必须排 CQ,否则 TX 停摆"为真实 NIC
   同款语义而非缺陷。

**结论:不再作为缺陷跟踪,转为文档化语义。**

---

## F. 实施顺序建议

| 阶段 | 内容 | 收益 | 风险 |
|---|---|---|---|
| 1 | B(最小 RQE) | wr_id 语义 + C 项的前置 | 低 |
| 2 | C(接收去重/OOO 缓冲) | RC 接收正确性;A 项的硬前置 | 中 |
| 3 | A(per-QP RTO 统一重传) | 关闭 4 个开放项,净删 ~250 行 | 中(已试一次,根因链完整) |
| 4 | D(原子上下文 FIFO) | 消除 RX HOL 小项 | 低 |
| 5 | E 文档化 + 中断子系统 | 语义澄清 | 低/大(PCIe 域) |

> **G 节实施记录(2026-10-12)修正了原顺序**:A 项曾按原顺序先行实施,
> 因接收侧无去重而暴露重复交付问题——C 项(去重)是 A 的硬前置,必须
> 先行。见 G 节根因链。

---

---

## G. 实施记录(2026-10-12):设计 A 的统一重传实验与回退

按本文档 A 项实施了统一重传路径(RC RTO/NAK → `llr_request_retx` → ESUN
LLR 重放;退役 retry store/环/重放 FSM)。**编译通过、RTO 测试通过,但
BIG 测试暴露了接收侧重复交付**(2880 字节 vs 2112:NAK 即时重放的复本在
交付窗口内到达,接收方无去重,以错误 CQE 转发主机)。根因链:

1. NAK 即时重放(第十八轮 R3)把"最老未确认包"的复本发回;
2. 接收方的 expected PSN 已前进(回环测试伪影或真实丢失推进),复本
   PSN 失配 → 本设计无接收重排序缓冲/去重 → **复本仍被转发主机**
   (错误 CQE 语义,第十九轮 #72);
3. 回环注入使复本在测试交付窗口内到达 → 测试断言失败。

**结论(实验确认了本文档 C 项的理论判断):per-QP RTO 的硬前置是接收侧
去重/重排序缓冲(C 项)+ RQE(B 项)。正确实施顺序:B(最小 RQE)→
C(OOO/去重)→ A(per-QP RTO 统一重传)。** 在 C 落地前,单定时器 RTO
(现状)是唯一与"无去重接收"兼容的形态——其延迟重放恰好把复本推到
测试窗口之外(偶然但一致)。

已回退到第五十次验证状态(50 PASS / 0 FAIL);`llr_request_retx` 接口与
encap_idle 谓词保留在代码中(未接线,供未来使用)。

## 附:本设计依赖的已验证事实清单

1. ESUN LLR 缓存无条件填充(行 892/910,泵启动与数据分支);
2. `llr_retx` 按 seq 校验重放、与发射互斥(行 1002);
3. `get_llr_tx_seq`/`get_llr_retx_base` 已暴露(行 1728-1729);
4. 绝对到期 + 游标形态可编译且 RTO 测试通过(第二十轮);
5. ESUN 放弃机制(7 次上限)独立于 RC 运行(第二十轮回退后保持)。
