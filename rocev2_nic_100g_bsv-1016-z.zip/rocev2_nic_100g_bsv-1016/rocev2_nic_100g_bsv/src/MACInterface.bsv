// ============================================================================
// 100G RoCEv2 NIC - 100G MAC Interface Module
// ============================================================================
// 100 Gigabit Ethernet MAC with 512-bit data path at 156.25 MHz.
// IEEE 802.3ba compliant. 64b/66b PCS, PFC flow control, statistics.

`include "RoCEv2NICConfig.bh"
package MACInterface;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import RegFile :: *;
import GetPut :: *;
import RoCEv2NICInterfaces :: *;

// ============================================================================
// 100G MAC Top Module
// ============================================================================

typedef struct {
    Bit#(2)  sync_header;   // 01 = data, 10 = control
    Bit#(64) data;
} Block66 deriving (Bits);

module mkMAC100G(MAC100GIfc);

    Integer data_bytes = `DATA_BYTES;

    // MAC address registers
    Reg#(Bit#(48)) local_mac  <- mkReg(0);
    Reg#(Bit#(48)) remote_mac <- mkReg(48'hFFFFFFFFFFFF);
    Reg#(Bit#(32)) local_ip   <- mkReg(0);

    // TX interface
    // Sized to absorb a frame's beats ahead of the inter-packet gap, so the
    // ESUN/Link layer is not backpressured while the MAC waits between frames.
    FIFOF#(MACDataStream) tx_fifo <- mkSizedFIFOF(16);

    Reg#(Bool)        snoop_pend <- mkReg(False);
    Reg#(MACDataStream) snoop_beat <- mkReg(unpack(0));

    // Snoop mirror of the TX stream (for testbench observation)
    // Debug side-channel mirror of the TX stream. Sized generously so it
    // never backpressures the data path (its notFull poisons tx_request's
    // implicit condition); a production design would drop-on-full instead.
    FIFOF#(MACDataStream) tx_snoop_fifo <- mkSizedFIFOF(256);

    // RX interface
    FIFOF#(MACDataStream) rx_fifo <- mkFIFOF;

    // Inter-packet gap
    Reg#(Bit#(8)) ipg_counter <- mkReg(0);
    Reg#(Bit#(8)) ipg_required <- mkReg(12);
    Reg#(Bool)    mac_tx_active <- mkReg(False);

    // Statistics
    Reg#(Bit#(64)) tx_frames <- mkReg(0);
    Reg#(Bit#(64)) tx_octets <- mkReg(0);
    Reg#(Bit#(64)) rx_frames <- mkReg(0);
    Reg#(Bit#(64)) rx_octets <- mkReg(0);
    Reg#(Bit#(32)) tx_errors <- mkReg(0);
    Reg#(Bit#(32)) rx_errors <- mkReg(0);

    // TX: single-rule pump. A beat is transmitted when mid-frame, or when a
    // new frame is ready after the inter-packet gap. One rule avoids the
    // multi-writer scheduling conflicts of the previous state machine.
    rule mac_tx;
        // After the inter-packet gap, consume ANY head beat (not just first==1):
        // an orphaned mid-frame beat (first==0 with active==0, e.g. after an
        // on-wire LLR CTRL frame interleaved a data frame) would otherwise
        // deadlock the MAC forever.
        if (tx_fifo.notEmpty &&
            (mac_tx_active ||
             ipg_counter >= ipg_required)) begin
            let stream = tx_fifo.first;
            tx_fifo.deq;
            // Pulse the debug mirror (drained by tx_snoop_mirror below -
            // decoupled from this rule's scheduling).
            snoop_pend  <= True;
            snoop_beat  <= stream;

            // A beat with valid=0 is never transmitted. Consuming it as a real
            // beat would latch mac_tx_active on a last==0 beat, and nothing
            // else would ever clear it - the MAC wedges permanently.
            if (stream.valid == 1) begin

            Bit#(7) bc = pack(countOnes(stream.keep));
            tx_octets <= tx_octets + zeroExtend(bc);

            mac_tx_active <= (stream.last == 1) ? False : True;
            if (stream.last == 1) begin
                tx_frames <= tx_frames + 1;
                ipg_counter <= 0;
            end
            end else if (stream.last == 1 && mac_tx_active) begin
                // A dropped beat can still carry the frame's LAST marker:
                // without clearing active here, the next frame's first beat
                // is spliced into this never-transmitted frame.
                mac_tx_active <= False;
                ipg_counter   <= 0;
            end
        end else if (ipg_counter < ipg_required) begin
            ipg_counter <= ipg_counter + 1;
        end
    endrule

    // Debug mirror: drains the 1-beat pulse into the snoop FIFO when it has
    // room. tx_snoop_fifo's notFull is confined to THIS rule - a full snoop
    // drops beats (the newest pulse is overwritten by the next mac_tx deq)
    // instead of backpressuring the production path.
    rule tx_snoop_mirror if (snoop_pend && tx_snoop_fifo.notFull);
        tx_snoop_fifo.enq(snoop_beat);
        snoop_pend <= False;
    endrule

    // Interface methods
    // tx_request guards ONLY on the production FIFO: the snoop mirror used
    // to enq here, which hoisted tx_snoop_fifo's notFull into this method's
    // implicit condition - a full debug FIFO then backpressured the ENTIRE
    // TX path (the Round-28 intermittent wedge: LLR-era replay residue
    // filled the 256-deep snoop during a test phase with no consumer, and
    // the backpressure chain req_fifo -> encap -> ESUN -> MAC wedged the
    // host push). The mirror now runs off a 1-beat pulse register drained
    // by its own rule: when the snoop is full the pulse is overwritten
    // (drop-on-full with 1-beat skid) and the production path never feels
    // it. Frame/octet accounting stays in the mac_tx pump rule.
    method Action tx_request(MACDataStream stream);
        if (tx_fifo.notFull) begin
            tx_fifo.enq(stream);
        end
    endmethod

    method ActionValue#(MACDataStream) tx_snoop;
        let s = tx_snoop_fifo.first;
        tx_snoop_fifo.deq;
        return s;
    endmethod

    method ActionValue#(MACDataStream) rx_response;
        MACDataStream stream = rx_fifo.first;
        rx_fifo.deq;
        rx_frames <= rx_frames + 1;
        rx_octets <= rx_octets + fromInteger(data_bytes);
        return stream;
    endmethod

    method Action rx_inject(MACDataStream stream);
        if (rx_fifo.notFull) begin
            rx_fifo.enq(stream);
        end
    endmethod

    method Action set_mac_addr(Bit#(48) mac);
        local_mac <= mac;
    endmethod

    method Bit#(48) get_mac_addr;
        return local_mac;
    endmethod

    method Action set_ip_addr(Bit#(32) ip);
        local_ip <= ip;
    endmethod

    method Bit#(32) get_ip_addr;
        return local_ip;
    endmethod

endmodule

// ============================================================================
// 100G MAC PCS - 64b/66b Encoding
// ============================================================================

module mkMAC100GPCS(Empty);

    Integer num_lanes = 8;  // 512-bit = 8 x 64-bit lanes

    // 66-bit block structure

    // TX encoding
    Reg#(Vector#(8, Block66)) tx_blocks <- mkReg(unpack(0));
    Reg#(Bool) tx_scrambler_en <- mkReg(True);
    Reg#(Bit#(58)) tx_scrambler_state <- mkReg(58'h3FFFFFFFFFFFFFF);

    // RX decoding
    Reg#(Vector#(8, Block66)) rx_blocks <- mkReg(unpack(0));
    Reg#(Bool) rx_descrambler_en <- mkReg(True);
    Reg#(Bit#(58)) rx_descrambler_state <- mkReg(58'h3FFFFFFFFFFFFFF);

    // Alignment markers
    Reg#(Bit#(16)) am_counter <- mkReg(0);
    Reg#(Bit#(16)) am_interval <- mkReg(16383);
    Reg#(Bool) am_insert_pending <- mkReg(False);

    // Lane deskew
    Vector#(8, Reg#(Bit#(8))) lane_skew <- replicateM(mkReg(0));
    Reg#(Bool) deskew_active <- mkReg(False);

    // TX encoding rule
    rule tx_encode;
        if (tx_scrambler_en) begin
            // Apply self-synchronizing scrambler
            // Polynomial: x^58 + x^39 + x^28 + x^19 + 1
            tx_scrambler_state <= (tx_scrambler_state << 1) ^
                                  (tx_scrambler_state >> 19) ^
                                  (tx_scrambler_state >> 28) ^
                                  (tx_scrambler_state >> 39);
        end
        tx_scrambler_en <= !tx_scrambler_en;
    endrule

    // RX decoding rule
    rule rx_decode;
        if (rx_descrambler_en) begin
            rx_descrambler_state <= (rx_descrambler_state << 1) ^
                                    (rx_descrambler_state >> 19) ^
                                    (rx_descrambler_state >> 28) ^
                                    (rx_descrambler_state >> 39);
        end
        rx_descrambler_en <= !rx_descrambler_en;
    endrule

    // Alignment marker insertion
    rule insert_am;
        am_counter <= am_counter + 1;
        if (am_counter >= am_interval) begin
            am_counter <= 0;
            am_insert_pending <= True;
        end
    endrule

    // Lane deskew
    rule lane_deskew_rule;
        if (deskew_active) begin
            // Adjust lane delays using alignment markers
            for (Integer i = 0; i < num_lanes; i = i + 1) begin
                lane_skew[i] <= lane_skew[i];
            end
        end
    endrule

endmodule

// ============================================================================
// 100G MAC Flow Control (PFC)
// ============================================================================

module mkMAC100GFlowControl(Empty);

    // PAUSE frame generation
    Reg#(Bool) pause_enable <- mkReg(True);
    Reg#(Bool) pause_active <- mkReg(False);

    // Buffer occupancy monitoring
    Reg#(Bit#(16)) tx_buffer_occ <- mkReg(0);
    Reg#(Bit#(16)) rx_buffer_occ <- mkReg(0);

    // PFC (Priority Flow Control) - 8 priorities
    Reg#(Bit#(8)) pfc_enable <- mkReg(8'hFF);
    Reg#(Bit#(8)) pfc_mask   <- mkReg(0);
    Vector#(8, Reg#(Bit#(16))) pfc_pause_timer <-
        replicateM(mkReg(0));
    Vector#(8, Reg#(Bit#(16))) pfc_threshold_hi <-
        replicateM(mkReg(800));
    Vector#(8, Reg#(Bit#(16))) pfc_threshold_lo <-
        replicateM(mkReg(400));

    // Statistics
    Reg#(Bit#(32)) pause_frames_sent <- mkReg(0);
    Reg#(Bit#(32)) pause_frames_recv <- mkReg(0);

    // Buffer threshold check
    rule check_buffer;
        if (rx_buffer_occ > pfc_threshold_hi[0] && pause_enable) begin
            pause_active <= True;
            pfc_pause_timer[0] <= 65535;
            pause_frames_sent <= pause_frames_sent + 1;
        end else if (rx_buffer_occ < pfc_threshold_lo[0]) begin
            pause_active <= False;
        end

        // Timer decrement
        for (Integer p = 0; p < 8; p = p + 1) begin
            if (pfc_pause_timer[p] > 0) begin
                pfc_pause_timer[p] <= pfc_pause_timer[p] - 1;
            end
        end
    endrule

endmodule

endpackage
