// ============================================================================
// 100G RoCEv2 NIC - PCIe DMA Engine Module
// ============================================================================
// AXI4-MM for memory-mapped transfers, AXI4-Stream for 512-bit packet data.
// Descriptor ring management, doorbell handling, and MSI/MSI-X interrupts.
// Configured for 64 QPs at 512-bit data path, 156.25 MHz.

`include "RoCEv2NICConfig.bh"
package DMAEngine;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import RegFile :: *;
import BRAM :: *;
import GetPut :: *;
import ClientServer :: *;
import RoCEv2NICInterfaces :: *;

// ============================================================================
// DMA Descriptor Structures
// ============================================================================

// Send Queue Descriptor (64 bytes)
typedef struct {
    Bit#(64) buffer_addr;
    Bit#(32) buffer_len;
    Bit#(32) lkey;
    Bit#(16) mss;               // Max segment size for LSO
    Bit#(8)  cq_num;
    Bit#(8)  flags;
    Bit#(64) next_desc;
    Bit#(64) reserved;
} SendDescriptor deriving (Bits);

// Receive Queue Descriptor (64 bytes)
typedef struct {
    Bit#(64) buffer_addr;
    Bit#(32) buffer_len;
    Bit#(32) lkey;
    Bit#(16) max_pkt_len;
    Bit#(8)  cq_num;
    Bit#(8)  flags;
    Bit#(64) next_desc;
    Bit#(64) reserved;
} ReceiveDescriptor deriving (Bits);

// Doorbell Descriptor (16 bytes)
typedef struct {
    Bit#(32) qp_num;
    Bit#(16) bf_size;
    Bit#(16) reserved1;
    Bit#(64) data;
} DoorbellDescriptor deriving (Bits);

// Descriptor flags (defined in RoCEv2NICConfig.bh)

// ============================================================================
// Interface Definitions for DMA Sub-modules
// ============================================================================

interface DoorbellManagerIfc;
    method Action ring_doorbell(Bit#(8) qp_num, Bit#(1) is_send, Bit#(32) value);
    method ActionValue#(Bit#(32)) get_send_doorbell(Bit#(8) qp_num);
    method ActionValue#(Bit#(32)) get_recv_doorbell(Bit#(8) qp_num);
    method Action set_coalesce(Bit#(16) threshold, Bit#(16) timer);
endinterface

interface DMADataPathIfc;
    method Action tx_data(Bit#(`DATA_WIDTH) data, Bit#(`DATA_BYTES) keep,
                          Bool first, Bool last);
    method Action rx_data(Bit#(`DATA_WIDTH) data, Bit#(`DATA_BYTES) keep,
                          Bool first, Bool last);
    method Bit#(64) get_tx_packets;
    method Bit#(64) get_tx_bytes;
    method Bit#(64) get_rx_packets;
    method Bit#(64) get_rx_bytes;
endinterface

interface MSIGeneratorIfc;
    method Action trigger(Bit#(5) vector);
    method Action set_msi_entry(Bit#(5) index, Bit#(64) entry);
    method Action enable_msi(Bit#(5) vector);
    method Action mask_msi(Bit#(5) vector);
endinterface

// ============================================================================
// Doorbell Manager
// ============================================================================

module mkDoorbellManager(DoorbellManagerIfc);

    // Doorbell register per QP
    RegFile#(Bit#(`QP_BITS), Bit#(32)) send_doorbell <- mkRegFileFull;
    RegFile#(Bit#(`QP_BITS), Bit#(32)) recv_doorbell <- mkRegFileFull;

    // Doorbell FIFO for processing order
    FIFOF#(Bit#(40)) doorbell_fifo <- mkFIFOF;
    // Format: {qp_num[5:0], is_send[1], value[32], pad[1]}

    // Doorbell coalescing
    Reg#(Bit#(16)) coal_timer    <- mkReg(0);
    Reg#(Bit#(16)) coal_threshold <- mkReg(4);
    Reg#(Bit#(16)) coal_count    <- mkReg(0);

    // Statistics
    Reg#(Bit#(32)) total_doorbells    <- mkReg(0);
    Reg#(Bit#(32)) coalesced_doorbells <- mkReg(0);

    // Processing rule
    rule process_doorbell;
        if (doorbell_fifo.notEmpty) begin
            Bit#(40) db = doorbell_fifo.first;
            Bit#(6)  qp_num  = db[39:34];
            Bit#(1)  is_send = db[33];
            Bit#(32) value   = db[31:0];

            if (is_send == 0) begin
                recv_doorbell.upd(qp_num, value);
            end else begin
                send_doorbell.upd(qp_num, value);
            end

            doorbell_fifo.deq;
            total_doorbells <= total_doorbells + 1;
        end
    endrule

    // Coalescing timer rule
    rule doorbell_coalesce;
        if (coal_count >= coal_threshold) begin
            coal_count  <= 0;
            coal_timer  <= 0;
            coalesced_doorbells <= coalesced_doorbells + 1;
        end else if (coal_timer > 0) begin
            coal_timer <= coal_timer - 1;
        end else if (coal_count > 0) begin
            coal_count <= 0;
        end
    endrule

    // Methods
    method Action ring_doorbell(Bit#(8) qp_num, Bit#(1) is_send, Bit#(32) value);
        Bit#(40) db = {truncate(qp_num), is_send, value};
        doorbell_fifo.enq(db);
        coal_count  <= coal_count + 1;
        coal_timer  <= 1000;  // ~6.4us at 156.25 MHz
    endmethod

    method ActionValue#(Bit#(32)) get_send_doorbell(Bit#(8) qp_num);
        return send_doorbell.sub(qp_num[`QP_BITS-1:0]);
    endmethod

    method ActionValue#(Bit#(32)) get_recv_doorbell(Bit#(8) qp_num);
        return recv_doorbell.sub(qp_num[`QP_BITS-1:0]);
    endmethod

    method Action set_coalesce(Bit#(16) threshold, Bit#(16) timer);
        coal_threshold <= threshold;
        coal_timer     <= timer;
    endmethod

endmodule

// ============================================================================
// DMA Data Path - 512-bit AXI4-Stream
// ============================================================================

module mkDMADataPath(DMADataPathIfc);

    Integer data_width = `DATA_WIDTH;
    Integer data_bytes = `DATA_BYTES;

    // TX data path (RoCEv2 -> DMA -> PCIe)
    Reg#(Bit#(`DATA_WIDTH)) tx_data_reg  <- mkReg(0);
    Reg#(Bit#(`DATA_BYTES)) tx_keep_reg  <- mkReg(0);
    Reg#(Bool) tx_valid <- mkReg(False);
    Reg#(Bool) tx_ready <- mkReg(True);
    Reg#(Bool) tx_first <- mkReg(False);
    Reg#(Bool) tx_last  <- mkReg(False);

    // RX data path (PCIe -> DMA -> RoCEv2)
    Reg#(Bit#(`DATA_WIDTH)) rx_data_reg  <- mkReg(0);
    Reg#(Bit#(`DATA_BYTES)) rx_keep_reg  <- mkReg(0);
    Reg#(Bool) rx_valid <- mkReg(False);
    Reg#(Bool) rx_ready <- mkReg(True);
    Reg#(Bool) rx_first <- mkReg(False);
    Reg#(Bool) rx_last  <- mkReg(False);

    // Statistics
    Reg#(Bit#(64)) tx_packets <- mkReg(0);
    Reg#(Bit#(64)) tx_bytes   <- mkReg(0);
    Reg#(Bit#(64)) rx_packets <- mkReg(0);
    Reg#(Bit#(64)) rx_bytes   <- mkReg(0);

    // TX data path rule
    rule tx_data_path;
        if (tx_valid && tx_ready) begin
            if (tx_first) tx_packets <= tx_packets + 1;

            Bit#(64) byte_count = 0;
            for (Integer i = 0; i < data_bytes; i = i + 1) begin
                if (tx_keep_reg[i] == 1) byte_count = byte_count + 1;
            end
            tx_bytes <= tx_bytes + byte_count;
            tx_valid <= False;
        end
    endrule

    // RX data path rule
    rule rx_data_path;
        if (rx_valid && rx_ready) begin
            if (rx_first) rx_packets <= rx_packets + 1;

            Bit#(64) byte_count = 0;
            for (Integer i = 0; i < data_bytes; i = i + 1) begin
                if (rx_keep_reg[i] == 1) byte_count = byte_count + 1;
            end
            rx_bytes <= rx_bytes + byte_count;
        end
    endrule

    // Methods
    method Action tx_data(Bit#(`DATA_WIDTH) data, Bit#(`DATA_BYTES) keep,
                          Bool first, Bool last);
        tx_data_reg  <= data;
        tx_keep_reg  <= keep;
        tx_valid <= True;
        tx_first <= first;
        tx_last  <= last;
    endmethod

    method Action rx_data(Bit#(`DATA_WIDTH) data, Bit#(`DATA_BYTES) keep,
                          Bool first, Bool last);
        rx_data_reg  <= data;
        rx_keep_reg  <= keep;
        rx_valid <= True;
        rx_first <= first;
        rx_last  <= last;
    endmethod

    method Bit#(64) get_tx_packets;
        return tx_packets;
    endmethod
    method Bit#(64) get_tx_bytes;
        return tx_bytes;
    endmethod
    method Bit#(64) get_rx_packets;
        return rx_packets;
    endmethod
    method Bit#(64) get_rx_bytes;
        return rx_bytes;
    endmethod

endmodule

// ============================================================================
// DMA Engine - Top Module
// ============================================================================

// DMA state machine states
typedef enum {
    DMA_IDLE,
    DMA_AR_PENDING,   // Read address phase
    DMA_R_PENDING,     // Read data phase
    DMA_AW_PENDING,   // Write address phase
    DMA_W_PENDING,    // Write data phase
    DMA_B_PENDING     // Write response phase
} DMAState deriving (Bits, Eq);

module mkDMAInterface(DMAEngineIfc);

    Integer data_width = `DATA_WIDTH;
    Integer data_bytes = `DATA_BYTES;
    Integer num_qps    = `NUM_QPS;

    // FIFOs for DMA requests and responses
    FIFOF#(DMARequest)  dma_req_fifo  <- mkFIFOF;
    FIFOF#(DMAResponse) dma_resp_fifo <- mkFIFOF;

    // FIFOs for data stream
    // tx_stream_fifo carries host payload reads (the TX data path).
    // aux_stream_fifo carries every *other* DMA read completion - the WQE
    // descriptor fetch, the RDMA READ responder's local read, and the atomic
    // read-modify-write operand read. Keeping them apart is what stops one
    // consumer from stealing another's beats: previously all four shared one
    // depth-1 FIFO and atomic_proc (highest urgency) would silently eat a
    // host TX payload beat, corrupting both the packet and the atomic result.
    FIFOF#(DMADataStream) tx_stream_fifo  <- mkSizedFIFOF(4);
    // Auxiliary read completions, split PER CONSUMER by the stream tag so no
    // consumer can ever dequeue another's beats (a single shared aux FIFO let
    // the WQE fetch, the atomic operand read and the RDMA READ responder
    // steal each other's beats whenever more than one was armed).
    FIFOF#(DMADataStream) aux_wqe_fifo    <- mkSizedFIFOF(2);   // tag 1
    FIFOF#(DMADataStream) aux_atomic_fifo <- mkSizedFIFOF(2);   // tag 2
    FIFOF#(DMADataStream) aux_read_fifo   <- mkSizedFIFOF(2);   // tag 3
    FIFOF#(DMADataStream) rx_stream_fifo  <- mkFIFOF;

    Reg#(DMAState) dma_state <- mkReg(DMA_IDLE);

    // Pending request tracking
    Reg#(Bit#(8))  pending_qp   <- mkReg(0);
    Reg#(Bit#(64)) pending_addr <- mkReg(0);
    Reg#(Bit#(32)) pending_len   <- mkReg(0);
    Reg#(Bit#(32)) pending_count <- mkReg(0);
    Reg#(Bit#(64)) pending_wr_id <- mkReg(0);
    // Stream-open tracking for chained reads (multi-SGE): reserved[4] on a
    // request means "another read follows for the same stream". first is
    // asserted on the first beat of a CLOSED stream, last on the last beat of
    // a read that has no continuation - independent of any request that
    // happens to be latched in between.

    // Stream tag of the in-flight read, latched from req.reserved[3:0] (a field
    // the requesters otherwise leave at 0; wr_id is NOT usable - the host side
    // carries real data in it):
    // 0 = host TX payload (tx_stream_fifo), non-zero = auxiliary read
    // (aux_stream_fifo: 1 = WQE fetch, 2 = atomic operand, 3 = RDMA READ).
    Reg#(Bit#(4))  pending_tag   <- mkReg(0);

    // Doorbell channel: a FIFO, not a register plus a flag. The register form
    // let a second ring overwrite the first before it was consumed - a host
    // ringing two doorbells in consecutive cycles silently lost a packet.
    FIFOF#(DoorbellEntry) db_fifo <- mkSizedFIFOF(8);

    // Last DMA read source (for RTO payload re-fetch)
    Reg#(Bit#(64)) last_read_addr <- mkReg(0);
    Reg#(Bit#(32)) last_read_len  <- mkReg(0);

    // Byte enable generation function
    function Bit#(`DATA_BYTES) gen_byte_en(Bit#(64) addr, Bit#(32) len,
                                            Bit#(32) count);
        Bit#(`DATA_BYTES) byte_en = 0;
        // Full 32-bit arithmetic throughout. The previous form truncated the
        // remaining byte count to 7 bits and added it in Bit#(7), so a read of
        // 128 bytes (remaining = 128, [6:0] = 0) produced an EMPTY byte-enable
        // - half of every multi-beat read was silently dropped.
        // Only the FIRST beat of a transfer starts at the address's byte
        // offset; subsequent beats are full 64-byte chunks from lane 0.
        Bit#(32) start_byte = (count == 0) ? zeroExtend(addr[5:0]) : 0;
        Bit#(32) remaining  = len - count;
        Bit#(32) end_byte   = start_byte + remaining;
        if (end_byte > fromInteger(`DATA_BYTES))
            end_byte = fromInteger(`DATA_BYTES);

        for (Integer i = 0; i < `DATA_BYTES; i = i + 1) begin
            if (fromInteger(i) >= start_byte &&
                fromInteger(i) < end_byte) begin
                byte_en[i] = 1;
            end
        end
        return byte_en;
    endfunction

    // DMA request handler (urgenccy breaks the shared dma_state write with
    // dma_read_response: a new request is latched before a completion is
    // processed)
    (* descending_urgency = "dma_request_handler, dma_read_response" *)
    // The handler must not fire while a read is in flight: latching a new
    // request would overwrite pending_addr/len for the one in progress (a
    // second gather entry used to corrupt the first read's byte enables).
    // Writes complete immediately - there is no B-phase completion wired, so
    // an AW_PENDING state was a dead end that blocked every later request.
    // Must not fire while a read is in flight: latching a new request would
    // overwrite pending_addr/len for the one in progress.
    // Must not fire while a read is in flight: latching a new request would
    // overwrite pending_addr/len for the one in progress.
    rule dma_request_handler if (dma_state == DMA_IDLE);
        if (dma_req_fifo.notEmpty) begin
            DMARequest req = dma_req_fifo.first;

            pending_qp    <= req.qp_num;
            pending_addr  <= req.addr;
            pending_len    <= req.length;
            pending_count  <= 0;
            pending_wr_id <= req.wr_id;
            pending_tag   <= req.reserved[3:0];

            // Reads: AR phase (the simulated host bus has no latency, so the
            // completion is processed directly by dma_read_response).
            // Writes: complete immediately (no B phase is wired and the write
            // is informational in this model).
            if (req.req_type == 0) begin
                dma_state <= DMA_AR_PENDING;
                last_read_addr <= req.addr;
                last_read_len  <= req.length;
            end else begin
                dma_state <= DMA_IDLE;
            end

            dma_req_fifo.deq;
        end
    endrule

    // DMA read completion: host memory data (via dma_response) feeds the TX
    // path through get_data_stream. Protocol: ONE response PER 64-byte beat,
    // dequeued as it is consumed. (The old convention - one response feeding
    // every beat of the transaction, dequeued only at the end - repeated the
    // first beat's 64 bytes across beats 2..N of any multi-beat read, and a
    // host model that pushed per-beat responses would have had beats 2..N
    // read the stale head entry plus residue polluting the next read.)
    // The transaction terminates on the REQUEST's length (pending_len), not
    // the response's.
    rule dma_read_response;
        if ((dma_state == DMA_AR_PENDING || dma_state == DMA_R_PENDING) &&
            dma_resp_fifo.notEmpty) begin
            DMAResponse resp = dma_resp_fifo.first;
            dma_resp_fifo.deq;   // one response per beat

            // The byte-enable window for this beat; its width is how many
            // bytes this beat actually transfers (the last beat of a read is
            // usually shorter than 64).
            Bit#(`DATA_BYTES) beat_be = gen_byte_en(pending_addr, pending_len,
                                                    pending_count);
            Bit#(32) beat_bytes = zeroExtend(pack(countOnes(beat_be)));

            DMADataStream stream;
            stream.data    = resp.data;
            stream.keep    = beat_be;
            stream.first   = (pending_count == 0) ? 1 : 0;
            stream.last    = (pending_count + beat_bytes >= pending_len) ? 1 : 0;
            stream.qp_num  = resp.qp_num;
            stream.valid   = 1;
            stream.ready   = 0;
            stream.dest    = pending_tag;
            stream.reserved = 0;

            // DMA read data (host memory -> NIC): route by the request's tag so
            // each consumer only ever sees its own beats.
            if (pending_tag == 1) begin
                aux_wqe_fifo.enq(stream);
            end else if (pending_tag == 2) begin
                aux_atomic_fifo.enq(stream);
            end else if (pending_tag == 3) begin
                aux_read_fifo.enq(stream);
            end else begin
                tx_stream_fifo.enq(stream);
            end

            pending_count  <= pending_count + beat_bytes;
            pending_addr   <= pending_addr + fromInteger(data_bytes);

            if (pending_count + beat_bytes >= pending_len) begin
                dma_state <= DMA_IDLE;
            end
        end
    endrule

    // ========================================================================
    // Interface Methods
    // ========================================================================

    method Action request(DMARequest req);
        dma_req_fifo.enq(req);
    endmethod

    method Action response(DMAResponse resp);
        dma_resp_fifo.enq(resp);
    endmethod

    method Action data_stream(DMADataStream stream);
        if (stream.valid == 1) begin
            // Host TX data (outbound): feeds the NIC TX path
            tx_stream_fifo.enq(stream);
        end
    endmethod

    method ActionValue#(DMADataStream) get_data_stream;
        DMADataStream stream = tx_stream_fifo.first;
        tx_stream_fifo.deq;
        return stream;
    endmethod

    // Auxiliary DMA read completions (WQE fetch / atomic operand / RDMA READ
    // responder). Kept separate from get_data_stream so no rule can consume
    // another consumer's beats.
    method ActionValue#(DMADataStream) get_wqe_stream;
        DMADataStream stream = aux_wqe_fifo.first;
        aux_wqe_fifo.deq;
        return stream;
    endmethod

    method ActionValue#(DMADataStream) get_atomic_stream;
        DMADataStream stream = aux_atomic_fifo.first;
        aux_atomic_fifo.deq;
        return stream;
    endmethod

    method ActionValue#(DMADataStream) get_read_stream;
        DMADataStream stream = aux_read_fifo.first;
        aux_read_fifo.deq;
        return stream;
    endmethod

    method Action rx_data_stream(DMADataStream stream);
        if (stream.valid == 1) begin
            // NIC RX data (inbound): delivered to the host
            rx_stream_fifo.enq(stream);
        end
    endmethod

    method ActionValue#(DMADataStream) get_rx_data_stream;
        DMADataStream stream = rx_stream_fifo.first;
        rx_stream_fifo.deq;
        return stream;
    endmethod

    method Action doorbell(Bit#(8) qp_num, Bit#(32) value);
        DoorbellEntry db;
        db.qp_num = qp_num;
        db.value  = value;
        db_fifo.enq(db);
    endmethod

    method ActionValue#(DoorbellEntry) get_doorbell;
        let db = db_fifo.first;
        db_fifo.deq;
        return db;
    endmethod

    method Bool doorbell_pending;
        return db_fifo.notEmpty;
    endmethod

    method Bool dma_read_pending;   // a read is latched and awaiting data
        return dma_state == DMA_AR_PENDING || dma_state == DMA_R_PENDING;
    endmethod

    method Bit#(64) get_last_read_addr;
        return last_read_addr;
    endmethod

    method Bit#(32) get_last_read_len;
        return last_read_len;
    endmethod

endmodule

// ============================================================================
// MSI/MSI-X Interrupt Generator
// ============================================================================

module mkMSIGenerator(MSIGeneratorIfc);

    Integer max_vectors = 32;

    // MSI-X table
    RegFile#(Bit#(5), Bit#(64)) msi_table <- mkRegFileFull;
    Reg#(Bit#(32)) msi_enable  <- mkReg(0);
    Reg#(Bit#(32)) msi_pending <- mkReg(0);
    Reg#(Bit#(32)) msi_mask    <- mkReg(0);

    // MSI-X
    Reg#(Bit#(64)) msix_table_base <- mkReg(0);
    Reg#(Bit#(64)) msix_pba_base   <- mkReg(0);
    Reg#(Bit#(32)) msix_enable     <- mkReg(0);
    Reg#(Bit#(32)) msix_mask       <- mkReg(0);

    // Interrupt state
    Reg#(Bool)   int_pending <- mkReg(False);
    Reg#(Bit#(5)) int_vector  <- mkReg(0);
    Reg#(Bit#(32)) interrupts_generated <- mkReg(0);

    // Methods
    method Action trigger(Bit#(5) vector);
        if (msi_enable[vector] == 1 && msi_mask[vector] == 0) begin
            int_vector  <= vector;
            int_pending <= True;
            interrupts_generated <= interrupts_generated + 1;
        end
    endmethod

    method Action set_msi_entry(Bit#(5) index, Bit#(64) entry);
        msi_table.upd(index, entry);
    endmethod

    method Action enable_msi(Bit#(5) vector);
        Bit#(32) en = msi_enable;
        en[vector] = 1;
        msi_enable <= en;
    endmethod

    method Action mask_msi(Bit#(5) vector);
        Bit#(32) m = msi_mask;
        m[vector] = 1;
        msi_mask <= m;
    endmethod

endmodule

endpackage
