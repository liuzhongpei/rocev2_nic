// ============================================================================
// 100G RoCEv2 NIC - QP Manager Module
// ============================================================================
// Queue Pair management for 64 QPs with RC and UD transport.
// QP context storage, PSN tracking, CQ management, doorbell processing.

`include "RoCEv2NICConfig.bh"
package QPManager;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import RegFile :: *;
import BRAM :: *;
import GetPut :: *;
import RoCEv2NICInterfaces :: *;

// ============================================================================
// QP Bank Module - 16 QPs per bank, 4 banks total
// ============================================================================

module mkQPBank#(Integer bank_id)(Empty);

    Integer qps_per_bank = `NUM_QPS_PER_BANK;
    Integer qp_bits_in_bank = 4;

    // QP context BRAM
    BRAM2Port#(Bit#(4), QPContext) qp_bram <- mkBRAM2Server(defaultValue);

    // Fast-access registers per QP
    Vector#(`NUM_QPS_PER_BANK, Reg#(QPState)) qp_states <-
        replicateM(mkReg(QPState_RESET));
    Vector#(`NUM_QPS_PER_BANK, Reg#(Bool)) qp_valid <-
        replicateM(mkReg(False));
    Vector#(`NUM_QPS_PER_BANK, Reg#(Bool)) qp_ready <-
        replicateM(mkReg(False));

    // PSN tracking per QP
    Vector#(`NUM_QPS_PER_BANK, Reg#(Bit#(24))) send_psn <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS_PER_BANK, Reg#(Bit#(24))) recv_psn <-
        replicateM(mkReg(0));

    // Doorbell registers
    Vector#(`NUM_QPS_PER_BANK, Reg#(Bit#(32))) send_doorbell <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS_PER_BANK, Reg#(Bit#(32))) recv_doorbell <-
        replicateM(mkReg(0));

    // Methods would be exposed for per-bank access in full implementation

endmodule


// ============================================================================
// Completion Queue Interface
// ============================================================================

interface CompletionQueueIfc;
    method Bit#(32) get_drops;

    method Action post_cqe(CompletionQueueEntry cqe);
    method ActionValue#(CompletionQueueEntry) get_cqe;
    method Bool cqe_available;
    method Action arm(Bit#(8) cq_num);
    method Bool is_armed;
    method Action set_doorbell(Bit#(32) addr);
    method Bit#(32) get_doorbell;
endinterface

// ============================================================================
// Completion Queue Module
// ============================================================================

module mkCompletionQueue#(Integer cq_id, Integer depth)(CompletionQueueIfc);

    RegFile#(Bit#(`CQ_BITS), CompletionQueueEntry) cq_mem <- mkRegFileFull;

    // Head/tail are 11-bit (mod 2048) against CQ_DEPTH=1024 so that full
    // (occupancy == 1024) and empty (== 0) are unambiguous, and occupancy is
    // DERIVED (head - tail) rather than counted: post_cqe is the SOLE
    // cq_head writer and get_cqe the SOLE cq_tail writer, so a same-cycle
    // post+get pair can no longer lose an update. The old separate cq_count
    // was read-modify-written by BOTH methods - in the generated hardware
    // semantics a same-cycle pair lost one increment/decrement (Bluesim's
    // sequential execution masked it in simulation).
    Reg#(Bit#(11)) cq_head <- mkReg(0);
    Reg#(Bit#(11)) cq_tail <- mkReg(0);

    Reg#(Bit#(32)) doorbell_addr <- mkReg(0);
    Reg#(Bool) armed <- mkReg(False);
    Reg#(Bool) cqe_valid <- mkReg(False);
    Reg#(Bit#(32)) cq_drops <- mkReg(0);   // CQEs dropped because the CQ was full

    Bit#(11) cq_occ = cq_head - cq_tail;

    method Action post_cqe(CompletionQueueEntry cqe);
        if (cq_occ < fromInteger(depth)) begin
            cq_mem.upd(cq_head[9:0], cqe);
            cq_head <= cq_head + 1;
            cqe_valid <= True;

            if (armed) begin
                armed <= False;
                // In full implementation, trigger MSI/MSI-X
            end
        end else begin
            // CQ full: count the drop instead of silently losing the CQE
            cq_drops <= cq_drops + 1;
        end
    endmethod

    method ActionValue#(CompletionQueueEntry) get_cqe if (cq_occ > 0);
        CompletionQueueEntry cqe = cq_mem.sub(cq_tail[9:0]);
        cq_tail <= cq_tail + 1;
        cqe_valid <= (cq_occ > 1);
        return cqe;
    endmethod

    method Bool cqe_available;
        return (cq_occ > 0);
    endmethod

    method Action arm(Bit#(8) cq_num);
        armed <= True;
    endmethod

    method Bool is_armed;
        return armed;
    endmethod

    method Action set_doorbell(Bit#(32) addr);
        doorbell_addr <= addr;
    endmethod

    method Bit#(32) get_doorbell;
        return doorbell_addr;
    endmethod

endmodule

// ============================================================================
// QP Manager Top Module
// ============================================================================

module mkQPManager(QPManagerIfc);

    Integer num_qps = `NUM_QPS;

    // QP context storage (banked for timing)
    // 4 banks of 16 QPs each
    BRAM2Port#(Bit#(`QP_BITS), QPContext) qp_ctx_bram <- mkBRAM2Server(defaultValue);

    // Fast-access state per QP
    Vector#(`NUM_QPS, Reg#(QPState)) qp_states <-
        replicateM(mkReg(QPState_RESET));
    Vector#(`NUM_QPS, Reg#(Bool)) qp_valid <-
        replicateM(mkReg(False));
    Vector#(`NUM_QPS, Reg#(Bool)) qp_ready_to_send <-
        replicateM(mkReg(False));
    Vector#(`NUM_QPS, Reg#(Bool)) qp_ready_to_recv <-
        replicateM(mkReg(False));

    // PSN tracking
    Vector#(`NUM_QPS, Reg#(Bit#(24))) send_psn <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(24))) recv_psn <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(24))) expected_psn <-
        replicateM(mkReg(0));   // Expected PSN for RC RX validation
    Vector#(`NUM_QPS, Reg#(Bit#(24))) last_acked_psn <-
        replicateM(mkReg(0));   // Last acked PSN for RC TX retransmission
    Vector#(`NUM_QPS, Reg#(Bit#(24))) min_psn <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(24))) max_psn <-
        replicateM(mkReg(0));

    // Doorbell registers
    Vector#(`NUM_QPS, Reg#(Bit#(32))) send_db <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(32))) recv_db <- replicateM(mkReg(0));

    // Transport mode per QP
    Vector#(`NUM_QPS, Reg#(TransportMode)) transport_mode <-
        replicateM(mkReg(Transport_RC));
    Vector#(`NUM_QPS, Reg#(Bit#(32))) qp_qkey <- replicateM(mkReg(0));

    // Fast-access remote addressing snapshot per QP (TX hot path)
    Vector#(`NUM_QPS, Reg#(QPRemoteAddr)) qp_remote <-
        replicateM(mkReg(unpack(0)));

    // Completion queues (up to 8 CQs)
    // Per-QP CQ ids (fast-access copies of the BRAM context fields)
    Vector#(`NUM_QPS, Reg#(Bit#(8))) qp_send_cq <- replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(8))) qp_recv_cq <- replicateM(mkReg(0));

    Vector#(8, CompletionQueueIfc) cqs <-
        replicateM(mkCompletionQueue(0, `CQ_DEPTH));

    // QP context lookup response pipe (BRAM read has ~2 cycle latency)
    FIFOF#(QPContext) qp_lookup_resp <- mkFIFOF;

    rule qp_lookup_respond;
        let r <- qp_ctx_bram.portA.response.get;
        qp_lookup_resp.enq(r);
    endrule

    // Round-robin scheduler state
    Reg#(Bit#(`QP_BITS)) rr_index <- mkReg(0);
    FIFOF#(Bit#(8)) ready_qp_fifo <- mkFIFOF;

    // Round-robin scheduler rule (guarded so the FIFO cannot overflow)
    rule rr_scheduler;
        if (ready_qp_fifo.notFull) begin
            Bool found = False;
            for (Integer i = 0; i < num_qps; i = i + 1) begin
                Bit#(`QP_BITS) idx = rr_index + fromInteger(i);
                if (qp_ready_to_send[idx] && !found) begin
                    ready_qp_fifo.enq(zeroExtend(idx));
                    rr_index <= idx + 1;
                    found = True;
                end
            end
        end
    endrule

    // ========================================================================
    // Interface Methods
    // ========================================================================

    method Action create_qp(Bit#(8) qp_num, QPContext ctx);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];

        // Store full context in BRAM
        qp_ctx_bram.portB.request.put(BRAMRequest{
            write: True, responseOnWrite: False, address: idx, datain: ctx});

        // Update fast-access registers
        qp_states[idx] <= ctx.state;
        qp_valid[idx] <= True;
        transport_mode[idx] <= ctx.transport;
        qp_qkey[idx] <= ctx.qkey;   // DETH QKey (UD TX)

        // Initialize PSNs
        send_psn[idx] <= ctx.send_psn;
        recv_psn[idx] <= ctx.recv_psn;
        expected_psn[idx] <= ctx.recv_psn;  // Expected = initial recv PSN
        last_acked_psn[idx] <= ctx.send_psn;  // Last acked = initial send PSN
        min_psn[idx] <= ctx.min_psn;
        max_psn[idx] <= ctx.max_psn;

        // CQ routing: a completion must land in the CQ the host configured for
        // this QP, not in "QP number mod 8" (which scattered unrelated QPs'
        // completions into CQ 0 and left the configured CQ empty).
        qp_send_cq[idx] <= ctx.send_cq;
        qp_recv_cq[idx] <= ctx.recv_cq;

        // Set readiness based on state
        qp_ready_to_send[idx] <= (ctx.state == QPState_RTS);
        qp_ready_to_recv[idx] <= (ctx.state == QPState_RTR ||
                                   ctx.state == QPState_RTS);

        // Snapshot remote addressing for the TX hot path
        QPRemoteAddr ra;
        ra.remote_mac   = ctx.remote_mac;
        ra.remote_ip    = ctx.remote_ip;
        ra.remote_qpn   = ctx.remote_qpn;
        ra.r_key        = ctx.r_key;
        ra.virtual_addr = ctx.virtual_addr;
        qp_remote[idx] <= ra;
    endmethod

    method Action destroy_qp(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        qp_valid[idx] <= False;
        qp_ready_to_send[idx] <= False;
        qp_ready_to_recv[idx] <= False;
        qp_states[idx] <= QPState_RESET;
        // Clear the fast-access bypass copies too: after destroy, CQE
        // routing (cq_for_qp) and get_remote/get_qkey must not keep serving
        // stale snapshots of a QP that no longer exists.
        qp_send_cq[idx]      <= 0;
        qp_recv_cq[idx]      <= 0;
        qp_remote[idx]       <= unpack(0);
        qp_qkey[idx]         <= 0;
        transport_mode[idx]  <= Transport_RC;
        send_psn[idx]        <= 0;
        recv_psn[idx]        <= 0;
        expected_psn[idx]    <= 0;
        last_acked_psn[idx]  <= 0;
        send_db[idx]         <= 0;
        recv_db[idx]         <= 0;
    endmethod

    method Action modify_qp(Bit#(8) qp_num, QPState state);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        qp_states[idx] <= state;

        case (state)
            QPState_RTR: begin
                qp_ready_to_recv[idx] <= True;
            end
            QPState_RTS: begin
                qp_ready_to_send[idx] <= True;
                qp_ready_to_recv[idx] <= True;
            end
            QPState_RESET: begin
                qp_ready_to_send[idx] <= False;
                qp_ready_to_recv[idx] <= False;
            end
            QPState_ERROR: begin
                qp_ready_to_send[idx] <= False;
                qp_ready_to_recv[idx] <= False;
            end
        endcase
    endmethod

    // Aggregate CQ-overflow drops across the eight CQ instances.
    method Bit#(32) get_cq_drops;
        Bit#(32) t = 0;
        for (Integer k = 0; k < 8; k = k + 1)
            t = t + cqs[k].get_drops;
        return t;
    endmethod

    method ActionValue#(QPContext) get_qp(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        // Issue a BRAM read; the response arrives via qp_lookup_resp (~2 cyc)
        qp_ctx_bram.portA.request.put(BRAMRequest{
            write: False, responseOnWrite: False, address: idx, datain: ?});
        let ctx = qp_lookup_resp.first;
        qp_lookup_resp.deq;
        return ctx;
    endmethod

    method ActionValue#(QPContext) get_next_ready_qp;
        // Get next QP from round-robin scheduler
        Bit#(8) next_qp = ready_qp_fifo.first;
        ready_qp_fifo.deq;
        // Return context for this QP
        Bit#(`QP_BITS) idx = next_qp[`QP_BITS-1:0];
        QPContext ctx = unpack(0);
        ctx.qp_num = next_qp;
        ctx.state = qp_states[idx];
        ctx.transport = transport_mode[idx];
        ctx.send_psn = send_psn[idx];
        ctx.recv_psn = recv_psn[idx];
        ctx.expected_psn = expected_psn[idx];
        ctx.last_acked_psn = last_acked_psn[idx];
        return ctx;
    endmethod

    method Action update_psn(Bit#(8) qp_num, Bit#(24) s_psn,
                              Bit#(24) r_psn);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        send_psn[idx] <= s_psn;
        recv_psn[idx] <= r_psn;
    endmethod

    method Bit#(24) get_expected_psn(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return expected_psn[idx];
    endmethod

    method Action update_expected_psn(Bit#(8) qp_num, Bit#(24) psn);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        expected_psn[idx] <= psn;
    endmethod

    method Action update_acked_psn(Bit#(8) qp_num, Bit#(24) acked_psn);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        last_acked_psn[idx] <= acked_psn;
    endmethod

    method Bit#(24) get_last_acked_psn(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return last_acked_psn[idx];
    endmethod

    method Bit#(24) get_send_psn(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return send_psn[idx];
    endmethod

    method Bit#(24) get_recv_psn(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return recv_psn[idx];
    endmethod

    method QPState get_qp_state(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return qp_states[idx];
    endmethod

    method Bool is_qp_ready_to_send(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return qp_ready_to_send[idx];
    endmethod

    method Action update_doorbell(Bit#(8) qp_num, Bit#(1) is_send,
                                    Bit#(32) value);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        if (is_send == 1) begin
            send_db[idx] <= value;
        end else begin
            recv_db[idx] <= value;
        end
        // Mark QP as ready to send when doorbell is rung
        if (is_send == 1 && qp_states[idx] == QPState_RTS) begin
            qp_ready_to_send[idx] <= True;
        end
    endmethod

    method QPRemoteAddr get_remote(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return qp_remote[idx];
    endmethod

    method Bit#(32) get_qkey(Bit#(8) qp_num);
        Bit#(`QP_BITS) idx = qp_num[`QP_BITS-1:0];
        return qp_qkey[idx];
    endmethod

    method ActionValue#(CompletionQueueEntry) get_cqe(Bit#(8) cq_num);
        Bit#(3) cq_idx = cq_num[2:0];
        let cqe <- cqs[cq_idx].get_cqe;
        return cqe;
    endmethod

    // Which CQ a QP's completions belong in. Synchronous register read, so it
    // is usable from cqe_pump without the 2-cycle get_qp round trip.
    method Bit#(8) cq_for_qp(Bit#(8) qp_num, Bool is_send);
        return is_send ? qp_send_cq[qp_num[5:0]]
                       : qp_recv_cq[qp_num[5:0]];
    endmethod

    method Action post_cqe(Bit#(8) cq_num, CompletionQueueEntry cqe);
        Bit#(3) cq_idx = cq_num[2:0];
        cqs[cq_idx].post_cqe(cqe);
    endmethod

endmodule

endpackage
