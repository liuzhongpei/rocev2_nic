// ============================================================================
// 100G RoCEv2 NIC - Top-Level Module
// ============================================================================
// Integrates DMA (PCIe), RoCEv2 engine (64 QPs, DCQCN),
// ESUN link layer (fragmentation, LLR), and 100G MAC interface.
// 512-bit data path at 156.25 MHz for 100G line rate.

`include "RoCEv2NICConfig.bh"
package RoCEv2NIC;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import RegFile :: *;
import ConfigReg :: *;
import GetPut :: *;
import Connectable :: *;
import RoCEv2NICInterfaces :: *;
import DMAEngine :: *;
import QPManager :: *;
import DCQCN :: *;
import EncDecapEngine :: *;
import ESUNLinkLayer :: *;
import MACInterface :: *;

// ============================================================================
// Top-Level NIC Module
// ============================================================================

typedef enum {
    NIC_TX_IDLE,     // waiting for a doorbell
    NIC_TX_STREAM,   // streaming payload beats into the encap engine
    NIC_TX_DRAIN,    // draining the encap output to ESUN/MAC
    NIC_TX_WQE       // fetching/parsing the WQE before streaming (R10)
} NICTXState deriving (Bits, Eq);

// ========================================================================
// RX Path State
// ========================================================================

typedef enum {
    NIC_RX_IDLE,
    NIC_RX_FROM_MAC,
    NIC_RX_ESUN,
    NIC_RX_DECAP,
    NIC_RX_TO_DMA
} NICRXState deriving (Bits, Eq);

module mkRoCEv2NIC(RoCEv2NICIfc);

    Integer num_qps = `NUM_QPS;
    Integer data_bytes = `DATA_BYTES;

    // ========================================================================
    // Sub-Module Instantiation
    // ========================================================================

    // DMA Engine (PCIe interface)
    DMAEngineIfc dma_ifc <- mkDMAInterface;

    // QP Manager (64 QPs)
    QPManagerIfc qp_mgr <- mkQPManager;

    // DCQCN Congestion Control
    DCQCNIfc dcqcn_ifc <- mkDCQCN;

    // Encapsulation Engine (TX)
    EncapEngineIfc encap_ifc <- mkEncapEngine;

    // Decapsulation Engine (RX)
    DecapEngineIfc decap_ifc <- mkDecapEngine;

    // ESUN Link Layer (between RoCEv2 and MAC)
    ESUNLinkLayerIfc esun_ifc <- mkESUNLinkLayer;

    // 100G MAC Interface
    MAC100GIfc mac_ifc <- mkMAC100G;

    // ========================================================================
    // Address Registers
    // ========================================================================

    Reg#(Bit#(48)) local_mac  <- mkReg(0);
    Reg#(Bit#(32)) local_ip    <- mkReg(0);
    Reg#(Bit#(128)) local_gid  <- mkReg(0);

    // ========================================================================
    // Transport Mode per QP
    // ========================================================================

    // Vector of Regs, not a RegFile: the reset value must be a defined
    // Transport_RC, because this is read for every received packet to decide
    // RC vs UD (an uninitialised entry would misclassify a packet).
    Vector#(`NUM_QPS, Reg#(TransportMode)) qp_transport_mode <-
        replicateM(mkReg(Transport_RC));
    Reg#(Bit#(`NUM_QPS)) rc_qps_active <- mkReg(0);
    Reg#(Bit#(`NUM_QPS)) ud_qps_active <- mkReg(0);

    // ========================================================================
    // TX Path State
    // ========================================================================

    Reg#(NICTXState) tx_state <- mkReg(NIC_TX_IDLE);
    Reg#(Bit#(8)) tx_current_qp   <- mkReg(0);
    Reg#(Bit#(32)) tx_pkt_len     <- mkReg(0);  // payload bytes of current packet
    // Per-QP TX PSN. A single global counter was shared across QPs: two QPs
    // interleaving TX produced one combined PSN sequence, so each QP's PSN
    // stream had gaps - a real responder NAKs every such packet (R3).
    Vector#(`NUM_QPS, Reg#(Bit#(24))) tx_qp_psn <- replicateM(mkReg(0));
    Reg#(Bit#(8))  tx_cq_num       <- mkReg(0);  // CQ for TX completion
    Reg#(Bool)     tx_payload_done <- mkReg(False);  // all payload beats pumped
    Reg#(Bool)     tx_drain_done   <- mkReg(False);  // encap output fully drained

    // RDMA operation control
    Reg#(Bit#(8))  tx_opcode       <- mkReg(`OPCODE_SEND_FIRST);  // Current TX opcode
    Reg#(Bit#(1))  tx_is_rdma      <- mkReg(0);  // 1 for RDMA WRITE/READ
    Reg#(Bit#(64)) tx_remote_addr  <- mkReg(0);  // Remote VA for RDMA
    Reg#(Bit#(32)) tx_r_key        <- mkReg(0);  // Remote key for RDMA
    Reg#(Bit#(64)) tx_wr_id        <- mkReg(0);  // WQE wr_id, reported in the CQE
    // A WQE whose opcode produces no payload stream (an initiator READ REQ:
    // its data arrives later in the peer's READ RESPONSE). The FSM skips the
    // STREAM state entirely; without this the FSM sat in STREAM forever,
    // blocking every later doorbell and the RTO retransmission.
    Reg#(Bool)     tx_skip_stream  <- mkReg(False);
    // Dual SGE: an optional second gather entry lives in WQE bytes 40-51
    // {addr, len}. len == 0 means "not present", so single-SGE WQEs are
    // unchanged and remain backward compatible.



    Reg#(Bit#(64)) tx_packets <- mkReg(0);
    Reg#(Bit#(64)) tx_bytes   <- mkReg(0);
    Reg#(Bit#(32)) tx_errors   <- mkReg(0);

    // ========================================================================
    // WQE Fetch (R10): per-QP host SQ base + fetch state
    // ========================================================================

    // Host Send-Queue base address per QP. Non-zero enables WQE mode: on the
    // doorbell the NIC DMA-reads the WQE from the SQ, parses it, then
    // DMA-reads the payload buffer. Zero keeps the legacy push mode.
    // Vector of Regs (explicit mkReg(0) reset): RegFile full does not
    // guarantee a 0 reset value, which would spuriously enable WQE mode.
    Vector#(`NUM_QPS, Reg#(Bit#(64))) qp_sq_base <- replicateM(mkReg(0));
    // Set by wqe_fetch once the payload read has been issued; consumed by
    // tx_launch to move NIC_TX_WQE -> NIC_TX_STREAM. 2-writer flag ordered by
    // descending_urgency (wqe_fetch before tx_launch).
    Reg#(Bool)     wqe_payload_ready <- mkReg(False);
    Reg#(Bit#(64)) wqe_fetched       <- mkReg(0);   // WQEs fetched+parsed

    // ========================================================================
    // RC Reliable Transport - Retry Buffer and RTO
    // ========================================================================
    // Retry buffer stores sent RC packet descriptors for RTO retransmission.
    // Cross-QP head-of-line blocking (a FIFO clears only at the head, so an
    // entry of QP A behind un-ACKed entries of QP B was never cleared by A's
    // ACKs until the buffer filled and wedged ALL TX) is handled by the
    // TWO-PHASE ROTATION in the maintenance rules below: a non-matching head
    // is dequeued into rc_rot_hold and re-enqueued at the back one cycle
    // later, bounded by rc_rot_cnt so each pass terminates. (A scan-based
    // slot array was tried first and REVERTED: its 128-entry dynamic-index
    // muxes blew bsc elaboration up to hours.)
    FIFOF#(RetryEntry) rc_retry_buffer <- mkSizedFIFOF(`RETRY_BUFFER_DEPTH);
    // 1-deep staging FIFO between tx_pump_payload's last beat and the retry
    // buffer itself (see rc_retry_commit below for why the enq is deferred).
    FIFOF#(RetryEntry) rc_retry_pend   <- mkSizedFIFOF(1);
    // Rotation hold register (phase 1 deq, phase 2 re-enq at the back).
    Reg#(Bool)      rc_rot_hold_v <- mkReg(False);
    Reg#(RetryEntry) rc_rot_hold  <- mkReg(unpack(0));
    Reg#(Bit#(8))   rc_rot_cnt    <- mkReg(0);   // rotations this pass
    // Per-QP RTO values, owned by the NIC (reg 0x14 set_rto) - NOT read
    // from DCQCN: dcqcn_tick overwrites DCQCN's rto_value during congestion
    // episodes (16384/8192/4096), which silently clobbered host-programmed
    // RTOs. Default 4096 (the previous effective default).
    Vector#(`NUM_QPS, Reg#(Bit#(32))) rc_rto_val_v <- replicateM(mkReg(4096));
    // Per-QP RTO (retransmission timeout) tracking. NOTE: the single-timer
    // form tracks ONE QP - a second QP's arm overwrites the first's, so
    // with two QPs sending concurrently only the newest packet has RTO
    // protection. THREE per-QP implementations were attempted (2026-10-08/
    // 09) and REVERTED: (a) 64-entry unrolled countdown/scans overflowed
    // bsc's fixed 33616-byte elaboration stack; (b,c) an absolute-expiry
    // cursor compiled and passed the RTO test, but its retransmission
    // REPLAY - whether re-encapsulated (b) or routed through the ESUN LLR
    // replay (c) - delivers DUPLICATE RoCEv2 packets to a receiver whose
    // expected PSN has already advanced, and this design has NO receiver
    // reorder buffer/dedup: the duplicates are forwarded to the host (with
    // an error CQE) and corrupt test expectations. Per-QP RTO therefore
    // requires, as a PREREQUISITE, the receiver-side dedup/reorder buffer
    // (design: docs/OPEN_ISSUES_DESIGN.md item C). Deferred with this note.
    Reg#(Bit#(32)) rc_rto_timer <- mkReg(0);
    Reg#(Bit#(8))  rc_rto_qp <- mkReg(0);
    Reg#(Bool)     rc_rto_active <- mkReg(False);
    Reg#(Bit#(8))  rc_retry_count <- mkReg(0);
    // RC packets given up after the RTO retry budget (the retry entry is
    // dropped; the packet is no longer protected).
    Reg#(Bit#(32)) rc_retry_dropped <- mkReg(0);
    // RC packets transmitted without retry-buffer protection (ring full).
    Reg#(Bit#(32)) rc_retry_nocache <- mkReg(0);
    // Worst-case packet size in 64B beats (MAX_PKT_SIZE bytes).
    Bit#(9) max_pkt_beats = 144;   // MAX_PKT_SIZE (9216) / 64B beats
    // True while the CURRENT packet's beats are being skipped (no ring space
    // reserved at its first beat).
    Reg#(Bool)     rc_ring_skip     <- mkReg(False);
    // Beats cached in the retransmission ring but not yet ACK-cleared. The
    // 1024-beat ring has NO linkage to the oldest unacked entry, so without
    // this accounting a full lap silently overwrites the payload of live
    // entries - an RTO replay then retransmits CORRUPTED payload with a
    // valid recomputed iCRC. New packets are no longer cached when their
    // beats would not fit (they transmit without RTO protection instead).
    Reg#(Bit#(11)) rc_ring_outstanding <- mkReg(0);
    // Give-up handshake for the RTO retry budget (rc_rto_check sets it; the
    // rotation rule below consumes it).
    Reg#(Bool)     rc_giveup_pending <- mkReg(False);
    Reg#(Bit#(8))  rc_giveup_qp      <- mkReg(0);

    // RTO retransmission request FIFO (enq by rc_rto_check on expiry and by
    // the NAK branch; consumed by rc_retx_take). Carries {qp[7:0],
    // psn[23:0]}.
    FIFOF#(Bit#(32)) rc_retx_req_fifo <- mkFIFOF;
    // ACK tokens {qp[7:0], acked_psn[23:0]} consumed by the ACK-clear rules,
    // the sole deq'ers of rc_retry_buffer.
    FIFOF#(Bit#(32)) rc_ack_clear_fifo <- mkFIFOF;
    // ACK-clear handshake state (take/step/rot_replay rule trio below).
    Reg#(Bool)     rc_ack_clr_busy <- mkReg(False);
    Reg#(Bit#(8))  rc_ack_clr_qp   <- mkReg(0);
    Reg#(Bit#(24)) rc_ack_clr_psn  <- mkReg(0);
    // RTO arming (set by tx_pump_payload when an RC packet is sent) and ACK
    // reset (set by rx_decap_pump); consumed by rc_rto_check, the sole owner
    // of the timer/active state.
    Reg#(Bool)     rc_rto_arm_pending <- mkReg(False);
    Reg#(Bit#(8))  rc_rto_arm_qp  <- mkReg(0);
    Reg#(Bit#(24)) rc_rto_arm_psn <- mkReg(0);
    Reg#(Bit#(32)) rc_rto_arm_rto <- mkReg(0);
    Reg#(Bool)     rc_rto_ack_pending <- mkReg(False);
    Reg#(Bit#(8))  rc_rto_ack_qp  <- mkReg(0);
    Reg#(Bit#(24)) rc_oldest_unacked_psn <- mkReg(0);

    // Payload retransmission cache (FPGA URAM/RegFile): each RC packet's
    // payload beats are stored here at send time so RTO can replay them
    // without re-reading host memory. 1024 beats x 64B = 64KB ring.
    RegFile#(Bit#(10), Bit#(`DATA_WIDTH)) rc_retx_payload <- mkRegFileFull;
    RegFile#(Bit#(10), Bit#(`DATA_BYTES)) rc_retx_keep    <- mkRegFileFull;
    Reg#(Bit#(10)) rc_retx_wr_ptr   <- mkReg(0);   // next free cache slot
    Reg#(Bit#(10)) rc_retx_pkt_base <- mkReg(0);   // first beat of current packet
    Reg#(Bit#(9))  rc_retx_pkt_beats <- mkReg(0);  // beat count of current packet

    // Retransmission FSM state (owned solely by rc_retx_take/rc_retx_replay)
    Reg#(Bool)     rc_retx_active     <- mkReg(False);
    Reg#(EncapRequest) rc_retx_desc   <- mkReg(unpack(0));
    Reg#(Bit#(10)) rc_retx_rd_ptr     <- mkReg(0);
    Reg#(Bit#(9))  rc_retx_beats_left <- mkReg(0);
    Reg#(Bit#(9))  rc_retx_total      <- mkReg(0);
    Reg#(Bit#(64)) rc_retransmits     <- mkReg(0);

    // RDMA READ response context (R8)    // RDMA READ response context (R8): the responder reads local memory via
    // DMA and sends the data back as a READ RESPONSE packet.
    Reg#(Bool)     rdma_read_pending <- mkReg(False);
    // Per-packet PSN verdict: validated on the FIRST beat (the decap emits
    // one result per beat, all carrying the packet's psn), consumed by the
    // last beat's ACK/NAK generation.
    // B: host-posted Receive Queue entries (minimal form). The host posts
    // one 32-bit wr_id per expected receive (reg 0x20); each delivered data
    // packet's completion consumes one, so the host can correlate CQEs with
    // its buffers. Stored in registers (NOT a FIFO): a FIFO's notEmpty/
    // first would hoist into rx_decap_pump's guard and deadlock all RX the
    // moment no RQEs are posted.
    Vector#(16, Reg#(Bit#(64))) rq_wr_ids  <- replicateM(mkReg(0));
    Reg#(Bit#(5))  rq_count <- mkReg(0);
    Reg#(Bit#(5))  rq_head  <- mkReg(0);
    Reg#(Bit#(5))  rq_tail  <- mkReg(0);
    Reg#(Bool)     rx_psn_ok_pkt     <- mkReg(True);
    // Receiver dedup enable: when True, a packet that failed PSN
    // validation is NAKed and DROPPED (not forwarded to the host) - the
    // RC-correct semantic. Default OFF: the testbench's RX expected PSN is
    // not synchronized across tests, so the drop would break loopback
    // delivery tests. Enable together with the per-test PSN sync
    // (reg 0x02 write) for dedup-sensitive testing.
    Reg#(Bool)     rx_dedup_en       <- mkReg(False);
    Reg#(Bit#(32)) rc_nak_rx         <- mkReg(0);   // NAKs received
    Reg#(Bit#(8))  rdma_read_qp      <- mkReg(0);
    Reg#(Bit#(24)) rdma_read_psn     <- mkReg(0);
    Reg#(Bit#(32)) rdma_read_len     <- mkReg(0);
    Reg#(Bit#(48)) rdma_read_src_mac <- mkReg(0);
    Reg#(Bit#(32)) rdma_read_src_ip  <- mkReg(0);

    // Running write cursor for RX-initiated DMA writes. The decap emits one
    // result per payload beat, all carrying the SAME base address, so without
    // this every beat of a multi-beat write targeted the first byte.
    Reg#(Bit#(64)) rx_wr_addr <- mkReg(0);

    // RDMA READ initiator (R8): where an incoming READ RESPONSE must be
    // written. Recorded from the WQE when the READ REQ is issued. Only one
    // outstanding initiator read is supported.
    Reg#(Bool)     rd_ini_pending <- mkReg(False);
    Reg#(Bit#(64)) rd_ini_addr    <- mkReg(0);
    Reg#(Bit#(32)) rd_ini_len     <- mkReg(0);
    Reg#(Bit#(8))  rd_ini_qp      <- mkReg(0);
    Reg#(Bit#(64)) rdma_read_resps   <- mkReg(0);  // READ RESPONSEs sent

    // R9 - Atomic operations (responder): CMP_SWAP / FETCH_ADD at a remote
    // va. Flow: DMA-read the local 8 bytes -> compute -> stream the result
    // back to the host (write-back) -> send ATOMIC_ACK carrying the original.
    // Start token via FIFO (not a shared Reg): rx_decap_pump enq's, atomic_proc
    // deq's - a Reg written by both rules would create a write-write cycle.
    FIFOF#(Bit#(8)) atomic_start_fifo <- mkFIFOF;
    Reg#(Bit#(8))  atomic_qp     <- mkReg(0);
    Reg#(Bit#(24)) atomic_psn    <- mkReg(0);
    Reg#(Bit#(64)) atomic_va     <- mkReg(0);
    Reg#(Bool)     atomic_is_fadd <- mkReg(False);  // False = CMP_SWAP
    Reg#(Bit#(64)) atomic_a      <- mkReg(0);   // swap value / addend
    Reg#(Bit#(64)) atomic_b      <- mkReg(0);   // compare value
    Reg#(Bit#(48)) atomic_mac    <- mkReg(0);
    Reg#(Bit#(32)) atomic_ip     <- mkReg(0);
    Reg#(Bit#(64)) atomic_op_count <- mkReg(0);
    Reg#(Bit#(64)) ud_qkey_errors  <- mkReg(0);

    // ========================================================================
    // Register Interface State
    // ========================================================================

    Reg#(Bit#(32)) rg_read_addr  <- mkReg(0);
    Reg#(Bit#(32)) rg_write_data <- mkReg(0);
    Reg#(Bit#(4))  rg_write_strb <- mkReg(0);
    Reg#(Bit#(2))  rg_op         <- mkReg(0);
    Reg#(Bit#(32)) rg_read_data   <- mkReg(0);
    Reg#(Bool)     rg_data_valid  <- mkReg(False);

    // ========================================================================
    // CQE Posting (single consumer to avoid TX/RX CQ conflicts)
    // ========================================================================

    FIFOF#(CompletionQueueEntry) cqe_fifo <- mkSizedFIFOF(32);

    // ========================================================================
    // TX Path Rules
    // ========================================================================

    // TX: single writer of tx_state. Transitions driven by the doorbell
    // (IDLE->STREAM) and by the pump/drain completion flags. The pump/drain
    // rules clear and set their own flags, so tx_launch must not touch them
    // (that would create scheduling conflicts with those rules).
    // The doorbell branch is its own rule. It used to live inside tx_launch,
    // whose only guard was dma_req_fifo.notFull; now that the doorbell channel
    // is a FIFO, get_doorbell's implicit notEmpty would have been conjoined
    // into that guard and blocked the WQE->STREAM->DRAIN->IDLE transitions
    // whenever the FIFO was empty. The two rules are exclusive on tx_state
    // (IDLE vs not IDLE), which BSV can prove.
    // Encap frame atomicity: the encap pairs descriptors with payload beats
    // in FIFO order, so only ONE payload-carrying frame may be in flight.
    // Host TX (doorbell), READ RESPONSE (rdma_read_pending), RTO replay
    // (rc_retx_active) and ATOMIC_ACK (atomic_start_fifo) are mutually
    // exclusive at their STARTERS; header-only RX frames (ACK/NAK/CNP) are
    // safe to splice (they complete between descriptors).
    // STARTER GATES - DO NOT REMOVE (audited 2026-10-13 after this exact
    // gate was lost once in a rollback and corrupted frames): every
    // payload-frame starter below must carry the OTHER THREE starters'
    // in-flight predicates. In particular rc_retx_replay pumps beats for up
    // to 144 cycles while tx_state stays NIC_TX_IDLE, so tx_state alone
    // gates nothing - each starter needs !rc_retx_active explicitly.
    rule tx_doorbell if (tx_state == NIC_TX_IDLE && dma_ifc.doorbell_pending &&
                         !rdma_read_pending && !rc_retx_active &&
                         !atomic_start_fifo.notEmpty);
        DoorbellEntry db <- dma_ifc.get_doorbell;
        tx_current_qp <= db.qp_num;
            // Start of a NEW transmission: clear the completion flags so the
            // FSM cannot skip past the payload (they were left set from the
            // previous packet). tx_launch is ordered after the pump/drain by
            // descending_urgency, so the write-write is resolved.
            tx_payload_done <= False;
            tx_drain_done   <= False;
            wqe_payload_ready <= False;
            // R10: if the QP has a host SQ base configured, fetch the WQE
            // (64B) from the SQ ring first; otherwise use the legacy push mode.
            if (qp_sq_base[db.qp_num] != 0) begin
                DMARequest wreq;
                wreq.qp_num     = db.qp_num;
                wreq.req_type   = 0;   // Read (fetch WQE)
                wreq.is_doorbell = 0;
                wreq.reserved   = 1;   // DMA stream tag: 1 = WQE descriptor fetch
                wreq.addr       = qp_sq_base[db.qp_num] +
                                  (zeroExtend(db.value[15:0]) << 6);
                wreq.length     = 64;
                wreq.lkey       = 0;
                wreq.wr_id      = 0;
                dma_ifc.request(wreq);
                tx_state <= NIC_TX_WQE;
            end else begin
                tx_state <= NIC_TX_STREAM;
            end
    endrule

    // The non-doorbell transitions. Fires only when a transmission is in
    // progress, so it never competes with tx_doorbell for a doorbell.
    rule tx_launch if (tx_state != NIC_TX_IDLE);
        if (tx_state == NIC_TX_WQE && wqe_payload_ready) begin
            // A no-payload WQE (an initiator READ REQ) skips STREAM entirely:
            // with no beats to pump, tx_payload_done would never be set and
            // the FSM sat in STREAM forever, blocking every later doorbell
            // and the RTO retransmission.
            tx_state      <= tx_skip_stream ? NIC_TX_IDLE : NIC_TX_STREAM;
            tx_skip_stream <= False;
        end else if (tx_state == NIC_TX_STREAM && tx_payload_done) begin
            tx_state      <= NIC_TX_DRAIN;
        end else if (tx_state == NIC_TX_DRAIN && tx_drain_done) begin
            tx_state      <= NIC_TX_IDLE;
        end
    endrule

    // R10 - WQE fetch: consumes the 64-byte WQE DMA-read from the host SQ,
    // parses opcode/length/remote_addr/rkey/buffer_addr, writes the descriptor
    // input regs (tx_opcode etc., read by tx_pump_payload), issues the payload
    // DMA read, and signals tx_launch to move WQE -> STREAM. Single rule owns
    // wqe_payload_ready's set side; tx_launch clears it (ordered by urgency).
    (* descending_urgency = "wqe_fetch, tx_launch, tx_doorbell" *)
    rule wqe_fetch if (tx_state == NIC_TX_WQE);
        DMADataStream w <- dma_ifc.get_wqe_stream;
        // 64-byte WQE, MSB-first (byte0 = data[511:504]):
        //   opcode@byte0, length@bytes4-7, remote_addr@bytes8-15,
        //   rkey@bytes16-19, buffer_addr@bytes24-31, wr_id@bytes32-39
        Bit#(8)  op    = w.data[511:504];
        Bit#(32) wlen  = w.data[479:448];
        Bit#(64) raddr = w.data[447:384];
        Bit#(32) rk    = w.data[383:352];
        Bit#(64) baddr = w.data[319:256];
        Bit#(64) wrid  = w.data[255:192];
        // SGE1: bytes 40-47 = address, bytes 48-51 = length


        tx_opcode      <= op;
        tx_is_rdma     <= ((op >= `OPCODE_RDMA_WRITE_FIRST &&
                            op <= `OPCODE_RDMA_READ_REQ) ||
                           (op >= `OPCODE_RDMA_READ_RSP_FST &&
                            op <= `OPCODE_RDMA_READ_RSP_LST)) ? 1 : 0;
        tx_remote_addr <= raddr;
        tx_r_key       <= rk;
        tx_wr_id       <= wrid;

        if (op == `OPCODE_RDMA_READ_REQ && !rd_ini_pending) begin
            // A READ has no local data to send: the payload comes back in the
            // peer's READ RESPONSE. Submit the READ REQ descriptor directly -
            // a header-only RETH packet (BTH + RETH + iCRC, no payload) - and
            // record where the response must be written. Only ONE initiator
            // read context exists (rd_ini_*): a second concurrent READ REQ
            // would overwrite it and misdirect both responses, so it is
            // refused instead.
            EncapRequest rr;
            rr.qp_num     = tx_current_qp;
            rr.opcode     = `OPCODE_RDMA_READ_REQ;
            rr.is_first   = 1;
            rr.is_last    = 1;
            rr.is_imm     = 0;
            rr.is_rdma    = 1;
            rr.is_ack     = 0;
            rr.reserved1  = 0;
            rr.transport  = pack(Transport_RC);
            rr.reserved2a = 7'b0000011;     // [0]=no_payload, [1]=host TX
            rr.length     = wlen;           // RETH dma_len
            rr.psn        = tx_qp_psn[tx_current_qp];
            rr.ack_syndrome = 0;
            rr.remote_qpn   = zeroExtend(qp_mgr.get_remote(tx_current_qp).remote_qpn);
            rr.remote_addr  = raddr;
            rr.r_key        = rk;
            rr.imm_data     = 0;
            rr.remote_mac   = qp_mgr.get_remote(tx_current_qp).remote_mac;
            rr.dst_ip       = qp_mgr.get_remote(tx_current_qp).remote_ip;
            rr.qkey         = 0;
            encap_ifc.request(rr);
            tx_qp_psn[tx_current_qp] <= tx_qp_psn[tx_current_qp] + 1;

            // No payload beats follow, so the FSM skips STREAM entirely
            // (otherwise it sat in STREAM forever, blocking every later
            // doorbell and the RTO retransmission).
            tx_skip_stream  <= True;
            rd_ini_pending  <= True;
            rd_ini_qp       <= tx_current_qp;
            rd_ini_addr     <= baddr;
            rd_ini_len      <= wlen;
        end else if (op == `OPCODE_RDMA_READ_REQ) begin
            // READ REQ refused: an initiator read is already outstanding.
            // Skip the STREAM state as for the accepted case so the FSM
            // cannot sit there waiting for payload beats that will never
            // come (no DMA read was issued). The WQE was consumed from the
            // SQ, so the host must learn the wr_id failed - post an error
            // CQE, otherwise that wr_id leaks (its completion never comes).
            tx_skip_stream <= True;
            CompletionQueueEntry ref_cqe;
            ref_cqe.wr_id    = wrid;
            ref_cqe.status   = zeroExtend(pack(CQE_LOC_PROT_ERR));
            ref_cqe.opcode   = zeroExtend(op);
            ref_cqe.length   = 0;
            ref_cqe.qp_num   = tx_current_qp;
            ref_cqe.src_qp   = 0;
            ref_cqe.sl       = 0;
            ref_cqe.is_send  = 1;
            ref_cqe.reserved = 0;
            cqe_fifo.enq(ref_cqe);
            $display("  [TX] READ REQ refused: initiator read outstanding (wr_id error CQE)");
        end else begin
            // Issue the payload DMA read from the WQE's buffer.
            DMARequest preq;
            preq.qp_num    = tx_current_qp;
            preq.req_type  = 0;   // Read (payload buffer)
            preq.is_doorbell = 0;
            preq.reserved  = 0;
            preq.addr      = baddr;
            preq.length    = wlen;
            preq.lkey      = rk;
            preq.wr_id     = 0;
            dma_ifc.request(preq);
        end

        wqe_payload_ready <= True;
        wqe_fetched       <= wqe_fetched + 1;
        $display("  [WQE] opcode=0x%02h len=%d buf=0x%h raddr=0x%h rkey=0x%h",
                 op, wlen, baddr, raddr, rk);
    endrule

    // TX: pump payload beats from DMA into the encap engine; on the last beat,
    // build and submit the packet descriptor (payload-first protocol).
    // Signals completion via tx_payload_done (does not write tx_state).
    // Urgency breaks the scheduling cycle: pump reads tx_state (written by
    // launch) and writes tx_payload_done (read by launch). Ordering pump before
    // launch resolves the cycle deterministically.
    // Running byte count of the frame currently being drained, reset on the
    // first beat. The ESUN layer derives its fragment count from the
    // payload_length stamped here, and it reads that field on the LAST beat -
    // so each beat carries the cumulative count and the last beat carries the
    // exact total. (Using the tx_pkt_len register here was wrong twice over:
    // it lags the beat stream by a cycle and, on a frame's first beat, it
    // still holds the PREVIOUS packet's length - so a >2048B host TX never
    // fragmented at all, and every RX-generated ACK was stamped with the last
    // host packet's length instead of its own.)
    Reg#(Bit#(32)) drain_len <- mkReg(0);

    (* descending_urgency = "tx_pump_payload, tx_encap_drain, tx_launch" *)
    // Rule-level guard: tx_state==STREAM MUST be in the guard (not just the
    // body if), otherwise this rule fires as a no-op whenever the host TX
    // stream FIFO is non-empty (e.g. DMA data for the rdma_read_rsp_pump) and
    // suppresses that lower-urgency rule (WILL_FIRE = CAN_FIRE && !WILL_FIRE).
    rule tx_pump_payload if (tx_state == NIC_TX_STREAM);
        DMADataStream s <- dma_ifc.get_data_stream;
        encap_ifc.enq_payload(s);

            TransportMode transport = qp_transport_mode[tx_current_qp];

            // RC: cache this payload beat into the URAM retransmission buffer.
            // Beats are stored in order; the entry's cache_ptr/beats are
            // captured from the locals on the last beat (never from the
            // registers, which update at end of cycle).
            // RC retry-ring caching. SPACE IS RESERVED AT THE FIRST BEAT for
            // the worst-case packet (MAX_PKT_SIZE/64 beats): the packet's
            // real beat count is only known at its last beat, but the ring
            // writes happen per beat - deciding at the last beat (the
            // previous NOCACHE design) still wrote the beats and advanced
            // the pointer, so in the saturated regime the orphans clobbered
            // LIVE entries' cached payload and an RTO replay retransmitted
            // corrupted data under a valid recomputed iCRC. A packet that
            // might not fit is not cached at all (transmits without RTO
            // protection); a packet that reserved space always fits.
            Bit#(10) cache_base = (s.first == 1) ? rc_retx_wr_ptr : rc_retx_pkt_base;
            Bit#(9)  new_beats  = (s.first == 1) ? 1 : (rc_retx_pkt_beats + 1);
            Bool rc_cache_pkt = False;
            if (transport == Transport_RC) begin
                if (s.first == 1) begin
                    rc_cache_pkt = (zeroExtend(max_pkt_beats) +
                                    rc_ring_outstanding <= 1024);
                    rc_ring_skip <= !rc_cache_pkt;
                end else begin
                    rc_cache_pkt = !rc_ring_skip;
                end
                if (rc_cache_pkt) begin
                    rc_retx_payload.upd(rc_retx_wr_ptr, s.data);
                    rc_retx_keep.upd(rc_retx_wr_ptr, s.keep);
                    rc_retx_wr_ptr    <= rc_retx_wr_ptr + 1;
                    rc_retx_pkt_base  <= cache_base;
                    rc_retx_pkt_beats <= new_beats;
                end
            end

            // Accumulate payload byte count for this beat
            Bit#(32) cnt = 0;
            for (Integer i = 0; i < data_bytes; i = i + 1)
                if (s.keep[i] == 1) cnt = cnt + 1;

            // Track total payload length (reset on the first beat of a packet)
            Bit#(32) new_len = (s.first == 1) ? cnt : (tx_pkt_len + cnt);
            tx_pkt_len <= new_len;

            tx_payload_done <= (s.last == 1);

            if (s.last == 1) begin
                QPRemoteAddr remote = qp_mgr.get_remote(tx_current_qp);

                // Build the packet descriptor
                EncapRequest req;
                req.qp_num     = tx_current_qp;
                if (tx_is_rdma == 1) begin
                    req.opcode = tx_opcode;
                    req.is_rdma = 1;
                    req.remote_addr = tx_remote_addr;
                    req.r_key = tx_r_key;
                end else if (transport == Transport_UD) begin
                    req.opcode = `OPCODE_SEND_ONLY;
                    req.is_rdma = 0;
                    req.remote_addr = 0;
                    req.r_key = 0;
                end else begin
                    req.opcode = tx_opcode;  // default SEND_FIRST
                    req.is_rdma = 0;
                    req.remote_addr = 0;
                    req.r_key = 0;
                end
                req.is_first    = 1;
                req.is_last     = 1;
                req.is_imm      = 0;
                req.is_ack      = 0;
                req.transport   = pack(transport);
                req.reserved1   = 0;
                req.reserved2a  = 7'b0000010;   // [1]=host TX frame (CQE gating)
                req.length      = new_len;   // total payload bytes
                req.psn         = tx_qp_psn[tx_current_qp];
                req.ack_syndrome = 0;
                req.remote_qpn  = zeroExtend(remote.remote_qpn);
                req.imm_data    = 0;
                req.remote_mac  = remote.remote_mac;
                req.dst_ip      = remote.remote_ip;
                req.qkey        = qp_mgr.get_qkey(tx_current_qp);  // DETH (UD)
                encap_ifc.request(req);

                tx_packets    <= tx_packets + 1;
                tx_bytes      <= tx_bytes + zeroExtend(req.length);
                tx_qp_psn[tx_current_qp] <= tx_qp_psn[tx_current_qp] + 1;

                if (transport == Transport_RC && rc_cache_pkt) begin
                    RetryEntry re;
                    re.req         = req;
                    re.cache_ptr   = cache_base;
                    re.cache_beats = new_beats;
                    // Staged into rc_retry_pend - rc_retry_commit publishes
                    // it into rc_retry_buffer (and arms the RTO) once the
                    // buffer can accept it without stealing a rotator's
                    // slot. rc_ring_outstanding already counts this packet's
                    // ring beats from here on: the reserve check must stay
                    // conservative while the entry waits.
                    rc_retry_pend.enq(re);
                    rc_ring_outstanding <= rc_ring_outstanding +
                        zeroExtend(new_beats);
                end else if (transport == Transport_RC && !rc_cache_pkt) begin
                    rc_retry_nocache <= rc_retry_nocache + 1;
                    $display("  [RC RETX-NOCACHE] QP=%d beats=%0d outstanding=%0d - sent without RTO protection",
                             tx_current_qp, new_beats, rc_ring_outstanding);
                end
            end
    endrule

    // Deferred commit of a sent RC packet's retry entry (see rc_retry_pend).
    // WHY THE ENQ IS DEFERRED: rc_rot_replay (phase-2 rotation re-enq) needs
    // one FREE retry-buffer slot to land the held entry, and a direct enq
    // from tx_pump_payload could consume the very slot a deq'er freed in the
    // same cycle - both rules read cycle-start state, so a !rc_rot_hold_v
    // gate on the enq cannot see a hold latched THAT cycle - leaving the
    // buffer full with rc_rot_hold_v set: rot_replay then waits for a free
    // slot while every deq'er waits for !rc_rot_hold_v, and the whole retry
    // buffer deadlocks (RTO, ACK clearing, retransmission all frozen).
    // This rule yields to any active rotator (!rc_rot_hold_v) and to a full
    // buffer (notFull is hoisted from the enq); tx_pump_payload backpressures
    // through the pend FIFO's own notFull, which preserves submission order.
    // Reachability of progress: (buffer full AND rc_rot_hold_v) is
    // unreachable - a hold is only set by a deq, and the sole other enq'er
    // (rc_rot_replay) is mutually exclusive with all deq'ers via the same
    // flag - so whenever the buffer is full a future ACK clear / RTO give-up
    // / retx-take deq frees a slot and the entry commits.
    rule rc_retry_commit if (rc_retry_pend.notEmpty && !rc_rot_hold_v);
        RetryEntry re = rc_retry_pend.first;
        rc_retry_pend.deq;
        rc_retry_buffer.enq(re);
        // RTO arming moves here with the entry: arming before the entry is
        // in the buffer would let an expiry give up the WRONG (older) entry.
        rc_rto_arm_pending <= True;
        rc_rto_arm_qp      <= re.req.qp_num;
        rc_rto_arm_psn     <= re.req.psn;
        rc_rto_arm_rto     <= rc_rto_val_v[re.req.qp_num];
    endrule

    // TX: drain the encap output beat-by-beat into the ESUN link layer.
    // Always-on: handles both host TX packets (tx_state == NIC_TX_DRAIN) and
    // RX-generated control packets (ACK/NAK/CNP) that share the TX path.
    rule tx_encap_drain;
        MACDataStream pkt <- encap_ifc.get_packet;
        $display("  [DRAIN] beat first=%d last=%d keep=0x%016h", pkt.first, pkt.last, pkt.keep);

        // Count PAYLOAD bytes only: the encap's beat stream is
        // [header(first)][payload beats...][iCRC(last)], and the ESUN derives
        // its fragment count from the payload length. A single-beat frame
        // (first && last, e.g. an ACK/CNP) is counted whole - it is the whole
        // frame, and any value below the fragment size yields one fragment.
        Bool drain_single = (pkt.first == 1) && (pkt.last == 1);
        Bool drain_count  = drain_single || ((pkt.first == 0) && (pkt.last == 0));
        Bit#(32) drain_add = drain_count ?
                             zeroExtend(pack(countOnes(pkt.keep))) : 32'h0;
        Bit#(32) drain_new = (pkt.first == 1) ? drain_add
                                              : (drain_len + drain_add);
        drain_len <= drain_new;

        // Convert MACDataStream to ESUNFrame (per beat)
        ESUNFrame esun_frame;
        esun_frame.frag_hdr.frag_id        = 0;
        esun_frame.frag_hdr.frag_type      = zeroExtend(pack(ESUN_FRAG_SOLO));
        esun_frame.frag_hdr.frag_index     = 0;
        esun_frame.frag_hdr.total_frags    = 1;
        esun_frame.frag_hdr.payload_length = truncate(drain_new);
        esun_frame.frag_hdr.llr_seq        = 0;
        esun_frame.frag_hdr.llr_ack_req   = 1;
        esun_frame.frag_hdr.reserved       = 0;
        esun_frame.qp_num = tx_current_qp;
        esun_frame.data  = pkt.data;
        esun_frame.keep  = pkt.keep;
        esun_frame.first = pkt.first;
        esun_frame.last  = pkt.last;

        esun_ifc.tx_frame(esun_frame);

        if (pkt.last == 1) begin
            // Frame ownership: the encap pushes one flag per captured
            // descriptor (EncapRequest.reserved2a[1]). RX-generated frames
            // (ACK/NAK/CNP/READ RESPONSE/ATOMIC_ACK) share this drain path;
            // without the flag, one of them completing while a host frame is
            // in DRAIN posted a SPURIOUS send CQE with the host's wr_id and
            // prematurely set tx_drain_done - the next doorbell then
            // clobbered tx_current_qp/tx_wr_id mid-frame.
            Bool host_frame <- encap_ifc.get_frame_host;
            if (tx_state == NIC_TX_DRAIN && host_frame) begin
                // Host TX completion: signal drain done (CQE via cqe_fifo)
                tx_drain_done <= True;
                CompletionQueueEntry tx_cqe;
                tx_cqe.wr_id    = tx_wr_id;   // from the WQE (bytes 32-39)
                Bit#(32) cqe_status_success = zeroExtend(pack(CQE_SUCCESS));
                tx_cqe.status   = cqe_status_success;
                tx_cqe.opcode   = 32'h00000000;  // SEND opcode
                tx_cqe.length   = truncate(tx_pkt_len);
                tx_cqe.qp_num   = tx_current_qp;
                tx_cqe.src_qp   = 0;
                tx_cqe.sl       = 0;
                tx_cqe.is_send  = 1;
                tx_cqe.reserved = 0;
                cqe_fifo.enq(tx_cqe);
            end
        end
    endrule

    // TX: pump ESUN output (MAC stream) to the MAC interface
    rule tx_esun_pump;
        MACDataStream mac_stream <- esun_ifc.tx_get_mac_stream;
        mac_ifc.tx_request(mac_stream);
    endrule

    // RDMA READ response (R8): stream the DMA-read local memory data into the
    // encap engine and submit a READ RESPONSE descriptor on the last beat.
    // Rule-level guard (memory #10): rdma_read_pending in the body would let
    // this rule fire as a no-op whenever the TX stream has data (e.g. an
    // atomic's DMA read), suppressing atomic_proc.
    (* descending_urgency = "tx_pump_payload, rdma_read_rsp_pump" *)
    rule rdma_read_rsp_pump if (rdma_read_pending && tx_state == NIC_TX_IDLE &&
                                !rc_retx_active);
        DMADataStream s <- dma_ifc.get_read_stream;
        // A zero-length read produces one keep=0 beat. Forwarding it would
        // strand it in the encap's payload FIFO (a descriptor with length 0
        // takes the inline-iCRC path and never dequeues the payload stage),
        // permanently occupying a slot; drop it instead - the length-0
        // READ RESPONSE descriptor alone forms the complete frame.
        if (s.keep != 0)
            encap_ifc.enq_payload(s);

            if (s.last == 1) begin
                EncapRequest rsp;
                rsp.qp_num      = rdma_read_qp;
                rsp.opcode      = `OPCODE_RDMA_READ_RSP_FST;
                rsp.is_first    = 1;
                rsp.is_last     = 1;
                rsp.is_imm      = 0;
                // READ RESPONSE carries an AETH (4B), NOT a RETH: use the
                // is_ack extension so no RETH is emitted (opcode is 0x0B).
                rsp.is_rdma     = 0;
                rsp.is_ack      = 1;
                rsp.transport   = pack(Transport_RC);
                rsp.reserved1   = 0;
                rsp.reserved2a  = 0;
                rsp.length      = rdma_read_len;
                rsp.psn         = rdma_read_psn;
                rsp.ack_syndrome = 0;
                rsp.remote_qpn  = zeroExtend(qp_mgr.get_remote(rdma_read_qp).remote_qpn);
                rsp.remote_addr = 0;
                rsp.r_key       = 0;
                rsp.imm_data    = 0;
                rsp.remote_mac  = rdma_read_src_mac;
                rsp.dst_ip      = rdma_read_src_ip;
                rsp.qkey        = 0;
                encap_ifc.request(rsp);
                rdma_read_pending <= False;
                rdma_read_resps   <= rdma_read_resps + 1;
                $display("  [RDMA READ RSP TX] QP=%d PSN=%d len=%d",
                         rdma_read_qp, rdma_read_psn, rdma_read_len);
            end
    endrule

    // TX: send a CNP frame (generated by DCQCN) on the wire (R5)
    rule tx_cnp_pump;
        if (dcqcn_ifc.tx_cnp_available) begin
            CNPPacket cnp <- dcqcn_ifc.get_tx_cnp;
            QPRemoteAddr remote = qp_mgr.get_remote(cnp.qp_num);
            EncapRequest req;
            req.qp_num      = cnp.qp_num;
            req.opcode      = `OPCODE_CNP;
            req.is_first    = 1;
            req.is_last     = 1;
            req.is_imm      = 0;
            req.is_rdma     = 0;
            req.is_ack      = 0;
            req.transport   = pack(Transport_RC);
            req.reserved1   = 0;
            req.reserved2a  = 0;
            req.length      = 0;
            req.psn         = cnp.psn;
            req.ack_syndrome = 0;
            req.remote_qpn  = zeroExtend(remote.remote_qpn);
            req.remote_addr = 0;
            req.r_key       = 0;
            req.imm_data    = 0;
            req.remote_mac  = remote.remote_mac;
            req.dst_ip      = remote.remote_ip;
            req.qkey        = 0;
            encap_ifc.request(req);
            $display("  [CNP TX] QP=%d PSN=%d -> %02h:%02h:%02h:%02h:%02h:%02h",
                     cnp.qp_num, cnp.psn, remote.remote_mac[47:40],
                     remote.remote_mac[39:32], remote.remote_mac[31:24],
                     remote.remote_mac[23:16], remote.remote_mac[15:8],
                     remote.remote_mac[7:0]);
        end
    endrule

    // ========================================================================
    // RC RTO Tick (per-QP)
    // ========================================================================
    // Every QP owns an independent countdown, so QP A's timeout can fire
    // while QP B's is mid-countdown (the single-timer form tracked one QP: a
    // ========================================================================
    // RC RTO Timeout Check Rule
    // ========================================================================
    // Consumes the arm (packet sent) and ack flags and runs the countdown;
    // on expiry requests a retransmission. Re-arms after each expiry; after
    // RC_RTO_RETRY_LIMIT expiries without an ACK the QP's oldest entry is
    // given up. The NAK path charges the same budget without reloading the
    // countdown, so a dup-NAK loop is bounded by the give-up.
    rule rc_rto_check;
        if (rc_rto_arm_pending) begin
            rc_rto_arm_pending <= False;
            rc_rto_active      <= True;
            rc_rto_qp          <= rc_rto_arm_qp;
            rc_rto_timer       <= rc_rto_arm_rto;
            rc_oldest_unacked_psn <= rc_rto_arm_psn;
        end
        else if (rc_rto_ack_pending) begin
            rc_rto_ack_pending <= False;
            rc_rto_timer       <= rc_rto_val_v[rc_rto_ack_qp];
            rc_rto_active      <= rc_retry_buffer.notEmpty;
        end
        else if (rc_rto_active) begin
            if (rc_rto_timer > 0) begin
                rc_rto_timer <= rc_rto_timer - 1;
            end else if (rc_retry_count >= `RC_RTO_RETRY_LIMIT) begin
                rc_retry_count    <= 0;
                rc_rto_active     <= False;
                rc_giveup_pending <= True;
                rc_giveup_qp      <= rc_rto_qp;
                $display("  [RC RTO GIVEUP] QP=%d after %0d retries",
                         rc_rto_qp, `RC_RTO_RETRY_LIMIT);
            end else begin
                rc_retx_req_fifo.enq({rc_rto_qp, rc_oldest_unacked_psn});
                rc_retry_count <= rc_retry_count + 1;
                rc_rto_timer   <= rc_rto_val_v[rc_rto_qp];
                rc_rto_active  <= True;
                $display("  [RC RTO] QP=%d PSN=%d -> retransmit (retry %0d)",
                         rc_rto_qp, rc_oldest_unacked_psn, rc_retry_count + 1);
            end
        end
    endrule

    // RTO give-up: drop the OLDEST entry of the expired QP. The QP's entry
    // may sit behind other QPs' entries: rotate (two-phase deq/re-enq,
    // bounded by rc_rot_cnt) until it reaches the head, then drop. A full
    // circle without a match releases the give-up (the QP has no entry left).
    // SPLIT like rc_ack_clr_done/step: reading .first (in the match/phase-1
    // branches) hoists the FIFO's notEmpty into the rule's CAN_FIRE, so an
    // empty-store exit inside the scanning rule is unreachable once the
    // buffer drains - rc_giveup_pending would latch True forever and (via
    // the !rc_giveup_pending gate) block every later retransmission while
    // the retx-request FIFO fills up and stalls the whole RX path.
    rule rc_rto_giveup_done if (rc_giveup_pending && !rc_ack_clr_busy &&
                                !rc_rot_hold_v &&
                                (!rc_retry_buffer.notEmpty ||
                                 rc_rot_cnt >= fromInteger(`RETRY_BUFFER_DEPTH)));
        // empty store, or a full circle without a match
        rc_rot_cnt        <= 0;
        rc_giveup_pending <= False;
    endrule

    rule rc_rto_giveup if (rc_giveup_pending && !rc_ack_clr_busy &&
                           !rc_rot_hold_v && rc_retry_buffer.notEmpty &&
                           rc_rot_cnt < fromInteger(`RETRY_BUFFER_DEPTH));
        if (rc_retry_buffer.first.req.qp_num == rc_giveup_qp) begin
            RetryEntry re = rc_retry_buffer.first;
            rc_retry_buffer.deq;
            rc_ring_outstanding <=
                rc_ring_outstanding >= zeroExtend(re.cache_beats) ?
                rc_ring_outstanding - zeroExtend(re.cache_beats) : 0;
            rc_retry_dropped <= rc_retry_dropped + 1;
            rc_rot_cnt        <= 0;
            rc_giveup_pending <= False;
            $display("  [RC GIVEUP] QP=%d PSN=%d entry dropped (ring outstanding=%0d)",
                     re.req.qp_num, re.req.psn, rc_ring_outstanding);
        end else begin
            // phase 1: hold the non-matching head (rc_rot_replay does the
            // phase-2 re-enqueue - this rule no longer duplicates it)
            rc_rot_hold   <= rc_retry_buffer.first;
            rc_rot_hold_v <= True;
            rc_retry_buffer.deq;
        end
    endrule

    // RTO retransmission: take = snapshot the OLDEST entry of the requested
    // QP (rotate, two-phase, bounded, until a matching head is found; the
    // entry STAYS in the buffer until its ACK clears it). The token stays in
    // the request FIFO for the whole replay (deq'd on the last beat).
    // Stale-token drain (see rc_rto_giveup_done for why this is a separate
    // rule: the take rule reads .first, so its empty-store exit was dead).
    // Also drops the token after a full circle without a match.
    rule rc_retx_take_stale if (tx_state == NIC_TX_IDLE && !rc_retx_active &&
                                !rdma_read_pending && !rc_rot_hold_v &&
                                !rc_giveup_pending && !rc_ack_clr_busy &&
                                rc_retx_req_fifo.notEmpty &&
                                (!rc_retry_buffer.notEmpty ||
                                 rc_rot_cnt >= fromInteger(`RETRY_BUFFER_DEPTH)));
        rc_rot_cnt <= 0;
        rc_retx_req_fifo.deq;   // stale: the entry is gone
    endrule

    rule rc_retx_take if (tx_state == NIC_TX_IDLE && !rc_retx_active &&
                          !rdma_read_pending && !rc_rot_hold_v &&
                          !rc_giveup_pending && !rc_ack_clr_busy &&
                          rc_retx_req_fifo.notEmpty &&
                          rc_retry_buffer.notEmpty &&
                          rc_rot_cnt < fromInteger(`RETRY_BUFFER_DEPTH));
        Bit#(32) req_tok = rc_retx_req_fifo.first;
        Bit#(8)  req_qp  = req_tok[31:24];
        if (rc_retry_buffer.first.req.qp_num == req_qp) begin
            let re = rc_retry_buffer.first;
            rc_retx_desc       <= re.req;
            rc_retx_rd_ptr     <= re.cache_ptr;
            rc_retx_beats_left <= re.cache_beats;
            rc_retx_total      <= re.cache_beats;
            rc_retx_active     <= True;
            rc_rot_cnt         <= 0;
        end else begin
            rc_rot_hold   <= rc_retry_buffer.first;
            rc_rot_hold_v <= True;
            rc_retry_buffer.deq;
        end
    endrule

    // Replay: one cached payload beat per cycle into the encap (payload-
    // first); the descriptor is submitted on the last beat. Gated on
    // tx_state==IDLE so a host TX cannot interleave, and the take rule
    // cannot run while a replay is active.
    (* descending_urgency = "rc_retx_replay, tx_pump_payload, rc_rto_check" *)
    rule rc_retx_replay if (tx_state == NIC_TX_IDLE && rc_retx_active);
        let d = rc_retx_payload.sub(rc_retx_rd_ptr);
        let k = rc_retx_keep.sub(rc_retx_rd_ptr);
        DMADataStream beat;
        beat.data     = d;
        beat.keep     = k;
        beat.first    = (rc_retx_beats_left == rc_retx_total) ? 1 : 0;
        beat.last     = (rc_retx_beats_left == 1) ? 1 : 0;
        beat.valid    = 1;
        beat.ready    = 0;
        beat.qp_num   = rc_retx_desc.qp_num;
        beat.dest     = 0;
        beat.reserved = 0;
        encap_ifc.enq_payload(beat);
        if (rc_retx_beats_left == 1) begin
            encap_ifc.request(rc_retx_desc);
            rc_retransmits  <= rc_retransmits + 1;
            rc_retx_active  <= False;
            rc_retx_req_fifo.deq;
            $display("  [RC RETX] QP=%d PSN=%d beats=%d",
                     rc_retx_desc.qp_num, rc_retx_desc.psn, rc_retx_total);
        end else begin
            rc_retx_beats_left <= rc_retx_beats_left - 1;
            rc_retx_rd_ptr     <= rc_retx_rd_ptr + 1;
        end
    endrule

    // ACK clearing: the token rotates the buffer (two-phase, bounded) and
    // clears EVERY matching entry wherever it sits. The PSN compare is
    // WRAP-SAFE: covered iff the ACK is within the positive half of the
    // 24-bit PSN space from the entry (modular distance < 2^23).
    rule rc_ack_clr_take if (rc_ack_clear_fifo.notEmpty && !rc_ack_clr_busy);
        Bit#(32) tok = rc_ack_clear_fifo.first;
        rc_ack_clear_fifo.deq;
        rc_ack_clr_qp   <= tok[31:24];
        rc_ack_clr_psn  <= tok[23:0];
        rc_ack_clr_busy <= True;
        rc_rot_cnt      <= 0;
    endrule

    // ACK-clearing scan, step phase. SPLIT INTO TWO RULES: reading .first
    // anywhere in a rule body hoists the FIFO's notEmpty into the rule's
    // CAN_FIRE, so a single rule containing the empty-store exit could never
    // fire once the buffer drained (the covered branch had just dequeued the
    // last entry) - rc_ack_clr_busy latched True forever and the ACK token
    // FIFO filled up, deadlocking the whole RX path. The empty/full-circle
    // exit lives in its own rule that touches no .first and can therefore
    // always fire. (Verified in the generated scheduler: CAN_FIRE of the
    // step rule below now contains no notEmpty term other than the explicit
    // guarded one; the done rule carries none.)
    rule rc_ack_clr_done if (rc_ack_clr_busy && !rc_rot_hold_v &&
                             (!rc_retry_buffer.notEmpty ||
                              rc_rot_cnt >= fromInteger(`RETRY_BUFFER_DEPTH)));
        // done: empty store, or a full circle without further matches
        rc_ack_clr_busy <= False;
        rc_rot_cnt      <= 0;
    endrule

    rule rc_ack_clr_step if (rc_ack_clr_busy && !rc_rot_hold_v &&
                             rc_retry_buffer.notEmpty &&
                             rc_rot_cnt < fromInteger(`RETRY_BUFFER_DEPTH));
        // WRAP-SAFE: covered iff the ACK is within the positive half of the
        // 24-bit PSN space from the entry (modular distance < 2^23).
        if (rc_retry_buffer.first.req.qp_num == rc_ack_clr_qp &&
            (rc_ack_clr_psn - rc_retry_buffer.first.req.psn) < 24'h800000) begin
            RetryEntry re = rc_retry_buffer.first;
            rc_retry_buffer.deq;
            rc_ring_outstanding <=
                rc_ring_outstanding >= zeroExtend(re.cache_beats) ?
                rc_ring_outstanding - zeroExtend(re.cache_beats) : 0;
        end else begin
            // phase 1: hold the non-matching head
            rc_rot_hold   <= rc_retry_buffer.first;
            rc_rot_hold_v <= True;
            rc_retry_buffer.deq;
        end
    endrule

    // Phase 2 for every rotator: re-enqueue the held non-matching entry.
    // (rc_rto_giveup's own phase-2 branch was removed when it was split -
    // giveup and this rule are now structurally exclusive via !rc_rot_hold_v,
    // so the old double-enq hazard is gone by construction.)
    rule rc_rot_replay if (rc_rot_hold_v);
        // phase 2: the held non-matching entry goes to the back
        rc_retry_buffer.enq(rc_rot_hold);
        rc_rot_hold_v <= False;
        rc_rot_cnt    <= rc_rot_cnt + 1;
    endrule

    // PIN THE RETRY-BUFFER COMMIT/ROTATE ORDER: bsc currently schedules
    // rc_retry_commit (enq) BEFORE all three deq-with-hold rotators, which
    // is what makes the (buffer full AND rc_rot_hold_v) state unreachable -
    // but that order was alphabetical luck, not a declared constraint, and
    // any future rule addition could flip it into a permanent retry-buffer
    // deadlock (the Round-27 review derived the hazard; the Round-32 wedge
    // analysis confirmed the generated order). Commit first: a deq cycle
    // cannot be followed by a same-cycle commit enq (its notFull snapshot
    // saw the pre-deq full buffer), so the freed slot survives for
    // rc_rot_replay.
    // ========================================================================
    // RX Path State
    // ========================================================================

    Reg#(NICRXState) rx_state <- mkReg(NIC_RX_IDLE);
    Reg#(Bit#(8)) rx_current_qp <- mkReg(0);
    Reg#(Bit#(8)) rx_cq_num     <- mkReg(0);  // CQ for RX completion

    Reg#(Bit#(64)) rx_packets <- mkReg(0);
    Reg#(Bit#(64)) rx_bytes   <- mkReg(0);
    Reg#(Bit#(32)) rx_errors   <- mkReg(0);

    // ========================================================================
    // RX Path Rules
    // ========================================================================

    // RX: pump MAC output into the ESUN link layer
    // PIN THE RETRY-BUFFER COMMIT/ROTATE ORDER (see the note above the RX
    // Path section): rc_retry_commit (enq) must stay ahead of the three
    // deq-with-hold rotators - that ordering is what makes the
    // (buffer full AND rc_rot_hold_v) state unreachable, and it was
    // alphabetical luck until pinned here. All five rules are defined above.
    (* descending_urgency = "rc_retry_commit, rc_ack_clr_step, rc_rto_giveup, rc_retx_take, rc_rot_replay" *)
    rule rx_mac_pump;
        MACDataStream pkt <- mac_ifc.rx_response;
        esun_ifc.rx_mac_stream(pkt);
    endrule

    // RX: pump reassembled ESUN frames into the decap engine
    rule rx_esun_pump;
        ESUNFrame frame <- esun_ifc.rx_get_frame;

        MACDataStream mac_stream;
        mac_stream.data  = frame.data;
        mac_stream.keep  = frame.keep;
        mac_stream.valid = 1;
        mac_stream.ready = 1;
        mac_stream.first = frame.first;
        mac_stream.last  = frame.last;
        mac_stream.error = 0;

        decap_ifc.receive_packet(mac_stream);
    endrule

    // RX: process decap results (per beat)
    // Urgency: order the per-QP RTO tick after this rule (an ACK's timer
    // reload wins over the same cycle's decrement) and resolve the shared
    // encap request writes (self-arbitration).
    (* descending_urgency = "rx_decap_pump, tx_pump_payload, rc_rto_check" *)
    rule rx_decap_pump;
        if (decap_ifc.result_available) begin
            DecapResult result <- decap_ifc.get_result;
            rx_current_qp <= result.qp_num;

            // UD QKey validation (RNIC security): a UD packet whose DETH QKey
            // does not match the QP's configured QKey is dropped. Only UD QPs
            // are checked - for RC packets the ext field is payload, not a
            // DETH, so the qkey field is meaningless there.
            Bool ud_qkey_drop =
                (qp_transport_mode[result.qp_num] ==
                 Transport_UD) &&
                (result.qkey != qp_mgr.get_qkey(result.qp_num));
            if (ud_qkey_drop) begin
                ud_qkey_errors <= ud_qkey_errors + 1;
                $display("  [UD QKEY MISMATCH] QP=%d qkey=%h -> dropped",
                         result.qp_num, result.qkey);
            end

            // Check for CNP
            if (result.is_cnp == 1) begin
                CNPPacket cnp;
                cnp.qp_num   = result.qp_num;
                cnp.psn      = result.psn;
                cnp.qdepth   = 0;
                cnp.prio = 0;
                cnp.reserved = 0;
                dcqcn_ifc.receive_cnp(cnp);
            end

            // Handle RC ACK: received ACK from remote. The retry-buffer
            // clearing is delegated to rc_ack_clear (single consumer) via a
            // token, so this rule no longer depends on rc_retry_buffer.
            // A NAK is the SAME wire opcode with a non-zero AETH syndrome:
            // it must NOT advance the acked PSN or clear retry entries
            // (doing so silently drops the un-ACKed packet). R3: the RTO
            // countdown is reset so the oldest un-ACKed packet for this QP
            // is retransmitted promptly.
            if (result.opcode == `OPCODE_ACK && result.ack_syndrome == 8'h00) begin
                qp_mgr.update_acked_psn(result.qp_num, result.psn);
                rc_ack_clear_fifo.enq({result.qp_num, result.psn});
                // Reset the RTO countdown (rx_decap_pump's urgency orders
                // this flag before rc_rto_check consumes it).
                rc_rto_ack_pending <= True;
                rc_rto_ack_qp      <= result.qp_num;
                rc_retry_count <= 0;
                $display("  [RC ACK] QP=%d, acked_psn=%d", result.qp_num, result.psn);
            end else if (result.opcode == `OPCODE_ACK) begin
                rc_nak_rx <= rc_nak_rx + 1;
                // R3: a NAK is an EXPLICIT retransmission request - enqueue
                // one immediately instead of waiting a full RTO period. The
                // replay targets the QP's OLDEST entry; if that is not the
                // NAK'd packet, the dup answer is another NAK - so the NAK
                // path CHARGES the retry budget (rc_retry_count): without
                // it, a dup round-trip shorter than the RTO would reset the
                // countdown (rc_rto_ack_pending) before every expiry, the
                // give-up budget would never be reached, and the same entry
                // would be replayed forever. Each NAK consumes budget; the
                // give-up drops the head, and the NAK'd packet eventually
                // becomes the oldest. NOTE: the RTO countdown is NOT
                // reloaded here (rc_rto_ack_pending stays unset) so the
                // timer's own expiries keep charging the budget too.
                rc_retry_count <= rc_retry_count + 1;
                rc_retx_req_fifo.enq({result.qp_num, result.psn});
                $display("  [RC NAK RX] QP=%d, missing_psn=%d -> retransmit (budget %0d)",
                         result.qp_num, result.psn, rc_retry_count + 1);
            end

            // RC PSN validation on RX; on mismatch send a NAK (R3).
            // Validated ONCE per packet, on the FIRST beat: the decap emits
            // one result per payload beat carrying the SAME psn, so a
            // per-beat validation advanced the expected PSN on beat 1 and
            // then mismatched on beats 2..N (spurious rx_errors and a NAK
            // for a perfectly received multi-beat packet). The verdict is
            // remembered per packet and consumed by the last beat's ACK/NAK
            // generation below.
            TransportMode rx_transport = qp_transport_mode[result.qp_num];
            Bool psn_first_ok = True;
            if (rx_transport == Transport_RC && result.opcode != `OPCODE_ACK &&
                result.is_first == 1) begin
                Bit#(24) expected = qp_mgr.get_expected_psn(result.qp_num);
                if (result.psn == expected) begin
                    qp_mgr.update_expected_psn(result.qp_num, expected + 1);
                    rx_psn_ok_pkt <= True;
                end else begin
                    psn_first_ok = False;
                    rx_psn_ok_pkt <= False;
                    rx_errors <= rx_errors + 1;
                    $display("  [PSN ERROR] QP=%d, expected=%d, got=%d",
                             result.qp_num, expected, result.psn);
                end
            end
            Bool psn_ok = (result.is_first == 1) ? psn_first_ok
                                                 : rx_psn_ok_pkt;

            // ECN-CE received: trigger a CNP back to the sender (R5)
            if (result.is_last == 1 && result.ecn == 2'b11) begin
                dcqcn_ifc.generate_cnp(result.qp_num, result.psn, 0);
                $display("  [CNP GEN] QP=%d PSN=%d (CE marked)", result.qp_num, result.psn);
            end

            // RC reliable transport: generate an ACK (or NAK on PSN mismatch)
            // for each received RC data packet, on its last beat (R1/R3).
            // ATOMIC_ACK (0x0F) IS itself an acknowledgment (of the atomic
            // request) - responding to a response doubles the hop count and,
            // mixed with SEND traffic on the same QP, desynchronizes the
            // expected-PSN tracking against the responder's PSN sequence.
            if (result.is_last == 1 && rx_transport == Transport_RC &&
                result.opcode != `OPCODE_ACK && result.opcode != `OPCODE_CNP &&
                result.opcode != `OPCODE_ATOMIC_ACK) begin
                EncapRequest ack_req;
                ack_req.qp_num      = result.qp_num;
                ack_req.opcode      = `OPCODE_ACK;
                ack_req.is_first    = 1;
                ack_req.is_last     = 1;
                ack_req.is_imm      = 0;
                ack_req.is_rdma     = 0;
                ack_req.is_ack      = 1;
                ack_req.transport   = pack(Transport_RC);
                ack_req.reserved1   = 0;
                ack_req.reserved2a  = 0;
                ack_req.length      = 0;
                ack_req.psn         = result.psn;
                ack_req.ack_syndrome = psn_ok ? 8'h00 : 8'h01;
                ack_req.remote_qpn  = 0;
                ack_req.remote_addr = 0;
                ack_req.r_key       = 0;
                ack_req.imm_data    = 0;
                ack_req.remote_mac  = result.src_mac;   // reply to the sender
                ack_req.dst_ip      = result.src_ip;
                ack_req.qkey        = 0;
                encap_ifc.request(ack_req);
                $display("  [RC %s] QP=%d PSN=%d",
                         psn_ok ? "ACK" : "NAK", result.qp_num, result.psn);
            end

            // Forward payload beats to the host (RX stream); control packets
            // (ACK/CNP) carry no payload and are not forwarded. A UD packet
            // with a mismatched QKey is dropped (no data delivery).
            // byte_en != 0 skips the final beat when it carried only pad+iCRC.
            // RECEIVER DEDUP: a packet that failed PSN validation is out of
            // order or a duplicate - it is NAKed and DROPPED (not forwarded
            // to the host). The RC layer retransmits it (RTO/NAK-driven);
            // when its PSN becomes in-order it is delivered normally.
            if (result.length != 0 && result.byte_en != 0 && !ud_qkey_drop) begin
                DMADataStream dma_stream;
                dma_stream.data     = result.data;
                dma_stream.keep     = result.byte_en;
                dma_stream.first    = result.is_first;
                dma_stream.last     = result.is_last;
                dma_stream.qp_num   = result.qp_num;
                dma_stream.valid    = 1;
                dma_stream.ready    = 0;
                dma_stream.dest     = 0;
                dma_stream.reserved  = 0;
                dma_ifc.rx_data_stream(dma_stream);
            end

            // Handle RDMA WRITE: write data to local address from RETH
            if (result.is_rdma == 1 && result.byte_en != 0 &&
                result.opcode >= `OPCODE_RDMA_WRITE_FIRST &&
                result.opcode <= `OPCODE_RDMA_WRITE_IMM) begin
                // Advance the write cursor per beat: the first beat writes at
                // the RETH va, the next at va + (bytes written so far).
                Bit#(64) wa = (result.is_first == 1) ? result.local_addr
                                                     : rx_wr_addr;
                rx_wr_addr <= wa + zeroExtend(pack(countOnes(result.byte_en)));
                DMARequest wr_req;
                wr_req.qp_num    = result.qp_num;
                wr_req.req_type  = 1;  // Write
                wr_req.is_doorbell = 0;
                wr_req.reserved  = 0;
                wr_req.addr      = wa;
                wr_req.length    = truncate(result.length);
                wr_req.lkey      = result.r_key;
                wr_req.wr_id     = 0;
                dma_ifc.request(wr_req);
                $display("  [RDMA WRITE RX] addr=0x%h, len=%d, rkey=0x%h",
                         wa, result.length, result.r_key);
            end

            // Handle RDMA READ REQUEST: read local memory via DMA and prepare
            // to send a READ RESPONSE back to the requester (R8)
            if (result.opcode == `OPCODE_RDMA_READ_REQ && result.is_last == 1 &&
                !rdma_read_pending) begin
                DMARequest rd_req;
                rd_req.qp_num    = result.qp_num;
                rd_req.req_type  = 0;   // Read local memory
                rd_req.is_doorbell = 0;
                rd_req.reserved  = 3;   // DMA stream tag: 3 = RDMA READ local read
                rd_req.addr      = result.local_addr;   // RETH va = local addr
                rd_req.length    = result.dma_len;
                rd_req.lkey      = result.r_key;
                rd_req.wr_id     = 0;
                dma_ifc.request(rd_req);
                rdma_read_pending <= True;
                rdma_read_qp      <= result.qp_num;
                rdma_read_psn     <= result.psn;
                rdma_read_len     <= result.dma_len;
                rdma_read_src_mac <= result.src_mac;
                rdma_read_src_ip  <= result.src_ip;
                $display("  [RDMA READ REQ RX] addr=0x%h len=%d rkey=0x%h",
                         result.local_addr, result.dma_len, result.r_key);
            end

            // Handle RDMA READ Response (initiator side, R8): write the data
            // to the local buffer the WQE named when the READ REQ was issued.
            // The decap cannot know that address (it lives in the WQE), so
            // without this context the write went to address 0. With no
            // outstanding initiator read, the payload is only delivered to the
            // host stream (the response was not solicited by us).
            if (result.opcode >= `OPCODE_RDMA_READ_RSP_FST &&
                result.opcode <= `OPCODE_RDMA_READ_RSP_LST &&
                result.qp_num == rd_ini_qp &&
                result.byte_en != 0 && rd_ini_pending) begin
                DMARequest rd_rsp_req;
                rd_rsp_req.qp_num    = rd_ini_qp;
                rd_rsp_req.req_type  = 1;  // Write to local buffer
                rd_rsp_req.is_doorbell = 0;
                rd_rsp_req.reserved  = 0;
                Bit#(64) ra = (result.is_first == 1) ? rd_ini_addr
                                                     : rx_wr_addr;
                rx_wr_addr <= ra + zeroExtend(pack(countOnes(result.byte_en)));
                rd_rsp_req.addr      = ra;
                rd_rsp_req.length    = truncate(result.length);
                rd_rsp_req.lkey      = 0;
                rd_rsp_req.wr_id     = 0;
                dma_ifc.request(rd_rsp_req);
                $display("  [RDMA READ RSP RX] ->local addr=0x%h len=%d (of %0d)",
                         rd_ini_addr, result.length, rd_ini_len);
            end

            // The initiator READ completes on the response's LAST beat - which
            // is always the iCRC beat (the encap emits the iCRC separately and
            // the decap's is_last rides on its stream.last), whose byte_en is
            // 0. The clear therefore CANNOT live inside the data-write block
            // above (its byte_en != 0 gate made it unreachable dead code:
            // rd_ini_pending latched True after the FIRST initiator READ,
            // silently rejecting every later one and mis-directing any
            // further inbound READ RSP data at the stale address).
            if (result.opcode >= `OPCODE_RDMA_READ_RSP_FST &&
                result.opcode <= `OPCODE_RDMA_READ_RSP_LST &&
                result.qp_num == rd_ini_qp &&
                result.is_last == 1 && rd_ini_pending) begin
                rd_ini_pending <= False;   // READ completed
            end

            // Handle R9 atomic requests (CMP_SWAP / FETCH_ADD): DMA-read the
            // local 8 bytes at va; atomic_proc computes and answers.
            // The iCRC verdict IS the functional consumer of the decap's
            // check: a frame that failed it (or carries no complete iCRC at
            // all) must NOT be executed - executing a corrupted atomic would
            // write corruption-controlled data to host memory and answer
            // with an ACK derived from it. RoCEv2 drops such packets.
            if ((result.opcode == `OPCODE_COMPARE_SWAP ||
                 result.opcode == `OPCODE_FETCH_ADD) &&
                result.is_last == 1 && result.i_crc_ok == 1 &&
                // A LEN/ADDR-errored frame (p_len==0 emit path) reports
                // i_crc_ok=1 vacuously - the is_error check is what keeps a
                // malformed atomic from executing (and it already posts an
                // error CQE below; executing it as well would write host
                // memory from a frame we just declared broken).
                result.is_error == 0 &&
                !atomic_start_fifo.notEmpty) begin
                DMARequest ar_req;
                ar_req.qp_num    = result.qp_num;
                ar_req.req_type  = 0;   // Read local memory (8 bytes)
                ar_req.is_doorbell = 0;
                ar_req.reserved  = 2;   // DMA stream tag: 2 = atomic operand read
                ar_req.addr      = result.local_addr;
                ar_req.length    = 8;
                ar_req.lkey      = result.r_key;
                ar_req.wr_id     = 0;
                dma_ifc.request(ar_req);
                atomic_start_fifo.enq(result.qp_num);
                atomic_qp       <= result.qp_num;
                atomic_psn      <= result.psn;
                atomic_va       <= result.local_addr;
                atomic_is_fadd  <= (result.opcode == `OPCODE_FETCH_ADD);
                atomic_a        <= result.atomic_a;
                atomic_b        <= result.atomic_b;
                atomic_mac      <= result.src_mac;
                atomic_ip       <= result.src_ip;
                $display("  [ATOMIC REQ RX] QP=%d va=%h a=%h b=%h",
                         result.qp_num, result.local_addr,
                         result.atomic_a, result.atomic_b);
            end

            // Malformed packet (LEN/ADDR error): post an error CQE so software
            // sees the failure. ACK frames are excluded (looped control noise).
            Bool err_pkt = (result.is_error == 1 &&
                            result.opcode != `OPCODE_ACK);

            rx_packets <= rx_packets + 1;
            rx_bytes   <= rx_bytes + zeroExtend(result.length);

            // Post RX completion CQE (RECV completion) via the shared cqe_fifo.
            // One CQE per PACKET (on the last beat), not per beat: the decap
            // emits one result per payload beat, all carrying the packet's
            // PSN - a per-beat CQE floods the CQ (N entries per N-beat packet).
            // Malformed packets get an error-status CQE; UD packets with a
            // mismatched QKey get no CQE at all (dropped).
            // Control/request frames have no RECV completion: ACK/NAK and CNP
            // are protocol chatter, and a READ REQ / ATOMIC REQ is completed
            // by its RESPONSE (or write-back), not by a host receive. They
            // used to post wr_id=0 length-0 "success" CQEs - flooding the CQ
            // (every loopback ACK doubled the occupancy). Malformed frames of
            // these opcodes still get their error CQE via err_pkt.
            Bool ctrl_frame = (result.opcode == `OPCODE_ACK ||
                               result.opcode == `OPCODE_CNP ||
                               result.opcode == `OPCODE_RDMA_READ_REQ ||
                               result.opcode == `OPCODE_ATOMIC_ACK ||
                               result.opcode == `OPCODE_COMPARE_SWAP ||
                               result.opcode == `OPCODE_FETCH_ADD ||
                               // A solicited READ RESPONSE completes the
                               // initiator's own READ (tracked by
                               // rd_ini_pending, matched per QP so an
                               // unsolicited response on another QP is a
                               // genuine host receive), not a host receive -
                               // the initiator path posts no CQE (README).
                               (rd_ini_pending &&
                                result.qp_num == rd_ini_qp &&
                                result.opcode >= `OPCODE_RDMA_READ_RSP_FST &&
                                result.opcode <= `OPCODE_RDMA_READ_RSP_LST));
            if (!ud_qkey_drop && result.is_last == 1 &&
                (err_pkt || !ctrl_frame)) begin
                CompletionQueueEntry rx_cqe;
                rx_cqe.wr_id    = 0;  // RQE pairing deferred (Stage C)
                // A packet that FAILED PSN validation is out of order or a
                // duplicate: the host must not read its completion as a
                // clean receive (the payload is still forwarded - this
                // design has no receiver-side reorder buffer to hold it
                // back - but the status says what happened).
                Bit#(32) rx_cqe_status = err_pkt ?
                    zeroExtend(pack(CQE_LOC_PROT_ERR)) :
                    (!psn_ok ? zeroExtend(pack(CQE_REM_OP_ERR)) :
                               zeroExtend(pack(CQE_SUCCESS)));
                rx_cqe.status   = rx_cqe_status;
                rx_cqe.opcode   = zeroExtend(result.opcode);
                rx_cqe.length   = truncate(result.length);
                rx_cqe.qp_num   = result.qp_num;
                rx_cqe.src_qp   = truncate(result.src_qp);
                rx_cqe.sl       = 0;
                rx_cqe.is_send  = 0;  // RECV
                rx_cqe.reserved = 0;
                cqe_fifo.enq(rx_cqe);
                if (err_pkt) begin
                    $display("  [ERROR CQE] QP=%d opcode=0x%02h",
                             result.qp_num, result.opcode);
                end
            end
        end
    endrule

    // ========================================================================
    // R9 - Atomic operation processing: consume the DMA-read original value,
    // compute the result, stream the write-back to the host, and answer with
    // ATOMIC_ACK carrying the original value.
    // Urgency: atomic_proc above rx_decap_pump. Its encap req_fifo.enq feeds
    // rx_decap_pump's guard (notFull) while rx_decap_pump's start-token enq
    // feeds this rule's deq - a scheduling cycle that starves this rule
    // without explicit priority.
    // ========================================================================
    (* descending_urgency = "atomic_proc, rx_decap_pump, tx_pump_payload, rc_rto_check" *)
    rule atomic_proc if (atomic_start_fifo.notEmpty && tx_state == NIC_TX_IDLE &&
                         !rdma_read_pending && !rc_retx_active);
        DMADataStream s <- dma_ifc.get_atomic_stream;
        if (s.last == 1) begin
            Bit#(64) orig  = s.data[511:448];   // local memory at va
            Bit#(64) newv  = orig;
            if (atomic_is_fadd) begin
                newv = orig + atomic_a;                  // FETCH_ADD
            end else begin
                newv = (orig == atomic_b) ? atomic_a : orig;  // CMP_SWAP
            end

            // Write the result back to local memory (host-visible stream).
            DMADataStream wb;
            wb.data     = {newv, 448'h0};   // MSB-first: bytes 0-7
            wb.keep     = 64'h00000000000000FF;   // 8 bytes
            wb.valid    = 1;
            wb.ready    = 0;
            wb.first    = 1;
            wb.last     = 1;
            wb.qp_num   = atomic_qp;
            wb.dest     = 0;
            wb.reserved = 0;
            dma_ifc.rx_data_stream(wb);

            // ATOMIC_ACK: BTH + AETH + the original 8 bytes.
            EncapRequest ack;
            ack.qp_num      = atomic_qp;
            ack.opcode      = `OPCODE_ATOMIC_ACK;
            ack.is_first    = 1;
            ack.is_last     = 1;
            ack.is_imm      = 0;
            ack.is_rdma     = 0;
            ack.is_ack      = 1;      // AETH extension
            ack.transport   = pack(Transport_RC);
            ack.reserved1   = 0;
            ack.reserved2a  = 0;
            ack.length      = 8;
            ack.psn         = atomic_psn;
            ack.ack_syndrome = 0;
            ack.remote_qpn  = 0;
            ack.remote_addr = 0;
            ack.r_key       = 0;
            ack.imm_data    = 0;
            ack.remote_mac  = atomic_mac;
            ack.dst_ip      = atomic_ip;
            ack.qkey        = 0;
            encap_ifc.request(ack);
            DMADataStream pl;
            pl.data     = {orig, 448'h0};   // MSB-first: bytes 0-7
            pl.keep     = 64'h00000000000000FF;
            pl.valid    = 1;
            pl.ready    = 0;
            pl.first    = 1;
            pl.last     = 1;
            pl.qp_num   = atomic_qp;
            pl.dest     = 0;
            pl.reserved = 0;
            encap_ifc.enq_payload(pl);

            atomic_start_fifo.deq;
            atomic_op_count <= atomic_op_count + 1;
            $display("  [ATOMIC] orig=%h new=%h -> ATOMIC_ACK", orig, newv);
        end
    endrule

    // ========================================================================
    // CQE Consumer - single writer to the QP manager CQs
    // ========================================================================
    rule cqe_pump;
        let cqe = cqe_fifo.first;
        cqe_fifo.deq;
        // Route to the CQ the QP was configured with, not "QP number mod 8".
        qp_mgr.post_cqe(qp_mgr.cq_for_qp(cqe.qp_num, cqe.is_send == 1), cqe);
    endrule



    // ========================================================================
    // Interface Methods
    // ========================================================================

    // --- PCIe DMA Interface ---
    method Action dma_request(DMARequest req);
        dma_ifc.request(req);
    endmethod

    method Action dma_response(DMAResponse resp);
        dma_ifc.response(resp);
    endmethod

    method Bool dma_read_pending = dma_ifc.dma_read_pending;

    method Action dma_data_stream(DMADataStream stream);
        dma_ifc.data_stream(stream);
    endmethod

    method ActionValue#(DMADataStream) dma_get_data_stream;
        // Host reads inbound (RX) payload data
        let ret_val <- dma_ifc.get_rx_data_stream;
        return ret_val;
    endmethod

    method Action doorbell(Bit#(8) qp_num, Bit#(32) value);
        dma_ifc.doorbell(qp_num, value);
        qp_mgr.update_doorbell(qp_num, 1, value);
    endmethod

    // --- 100G MAC Interface ---
    // Note: mac_tx method removed for Verilog compatibility
    // (it creates a scheduling cycle with tx_to_mac rule)
    // Use the internal TX pipeline instead.
    // For test injection, use mac_rx_inject for RX path.

    method ActionValue#(MACDataStream) mac_rx;
        let ret_val <- mac_ifc.rx_response;
        return ret_val;
    endmethod

    method Action mac_rx_inject(MACDataStream stream);
        mac_ifc.rx_inject(stream);
    endmethod

    method ActionValue#(MACDataStream) mac_tx_snoop;
        let s <- mac_ifc.tx_snoop;
        return s;
    endmethod

    method Action set_mac_address(Bit#(48) mac);
        local_mac <= mac;
        mac_ifc.set_mac_addr(mac);
        encap_ifc.set_local_mac(mac);
        decap_ifc.set_local_mac(mac);
    endmethod

    method Action set_ip_address(Bit#(32) ip);
        local_ip <= ip;
        mac_ifc.set_ip_addr(ip);
        encap_ifc.set_local_ip(ip);
        decap_ifc.set_local_ip(ip);
    endmethod

    // --- QP Management ---
    method Action create_qp(Bit#(8) qp_num, QPContext ctx);
        $display("  [NIC-DBG] create_qp qp=%0d transport=%0d", qp_num, ctx.transport);
        qp_mgr.create_qp(qp_num, ctx);
        qp_transport_mode[qp_num] <= ctx.transport;
        decap_ifc.set_qp_transport(qp_num, ctx.transport);

        // Update active bitmap
        if (ctx.transport == Transport_RC) begin
            Bit#(`NUM_QPS) one = 1;
            UInt#(`QP_BITS) shift = unpack(qp_num[`QP_BITS-1:0]);
            rc_qps_active <= rc_qps_active | (one << shift);
        end else if (ctx.transport == Transport_UD) begin
            Bit#(`NUM_QPS) one = 1;
            UInt#(`QP_BITS) shift = unpack(qp_num[`QP_BITS-1:0]);
            ud_qps_active <= ud_qps_active | (one << shift);
        end
    endmethod

    method Action destroy_qp(Bit#(8) qp_num);
        qp_mgr.destroy_qp(qp_num);
        Bit#(`NUM_QPS) one = 1;
        UInt#(`QP_BITS) shift = unpack(qp_num[`QP_BITS-1:0]);
        rc_qps_active <= rc_qps_active & ~(one << shift);
        ud_qps_active <= ud_qps_active & ~(one << shift);
    endmethod

    method Action modify_qp(Bit#(8) qp_num, QPState state);
        qp_mgr.modify_qp(qp_num, state);
    endmethod

    method Bit#(32) get_cq_drops = qp_mgr.get_cq_drops;
    method Bit#(32) get_rq_count = zeroExtend(pack(rq_count));

    method ActionValue#(QPContext) get_qp(Bit#(8) qp_num);
        let ctx <- qp_mgr.get_qp(qp_num);
        return ctx;
    endmethod

    method ActionValue#(CompletionQueueEntry) get_cqe(Bit#(8) cq_num);
        let cqe <- qp_mgr.get_cqe(cq_num);
        return cqe;
    endmethod

    // --- DCQCN Control ---
    method Action set_dcqcn_rate(Bit#(8) qp_num, Bit#(32) rate);
        DCQCNRateUpdate update;
        update.qp_num = qp_num;
        update.rate   = rate;
        dcqcn_ifc.update_rate(update);
    endmethod

    method ActionValue#(Bit#(32)) get_dcqcn_rate(Bit#(8) qp_num);
        let rate <- dcqcn_ifc.get_rate(qp_num);
        return rate;
    endmethod

    method ActionValue#(Bit#(16)) get_dcqcn_cnp_count(Bit#(8) qp_num);
        let c <- dcqcn_ifc.get_cnp_count(qp_num);
        return c;
    endmethod

    method Action enable_dcqcn(Bit#(8) qp_num);
        dcqcn_ifc.enable_dcqcn(qp_num);
    endmethod

    method Action disable_dcqcn(Bit#(8) qp_num);
        dcqcn_ifc.disable_dcqcn(qp_num);
    endmethod

    // --- ESUN Control ---
    method Action set_esun_fragment_enable(Bool enable);
        esun_ifc.set_fragment_enable(enable);
    endmethod

    method Action set_esun_llr_enable(Bool enable);
        esun_ifc.set_llr_enable(enable);
    endmethod

    method Action set_llr_timeout(Bit#(16) cycles);
        esun_ifc.set_llr_timeout(cycles);
    endmethod

    method Bit#(32) get_llr_retry_count;
        return esun_ifc.get_llr_retry_count;
    endmethod

    method Bit#(32) get_llr_retry_dropped;
        return esun_ifc.get_llr_retry_dropped;
    endmethod

    method Bit#(8) get_llr_retx_base;
        return esun_ifc.get_llr_retx_base;
    endmethod

    method Bool get_llr_link_error;
        return esun_ifc.get_llr_link_error;
    endmethod

    method Action clear_llr_link_error;
        esun_ifc.clear_llr_link_error;
    endmethod

    method Action test_llr_nack(Bit#(8) ack_seq);
        // Inject an LLR NACK for the given sequence (testbench hook to verify
        // the retransmission mechanism)
        ESUNLLRAck nack;
        nack.frag_id = 0;
        nack.ack_seq = ack_seq;
        nack.is_nack = 1;
        nack.reserved = 0;
        esun_ifc.llr_receive_ack(nack);
    endmethod

    // --- RDMA Operation Control ---
    method Action set_tx_rdma_op(Bit#(8) opcode, Bit#(64) remote_addr, Bit#(32) r_key);
        tx_opcode <= opcode;
        tx_remote_addr <= remote_addr;
        tx_r_key <= r_key;
        // Set is_rdma flag based on opcode
        if (opcode >= `OPCODE_RDMA_WRITE_FIRST && opcode <= `OPCODE_FETCH_ADD)
            tx_is_rdma <= 1;
        else
            tx_is_rdma <= 0;
    endmethod

    // R10: configure the host SQ base address for a QP. Non-zero enables the
    // WQE-fetch TX path for that QP's doorbells.
    method Action set_wqe_sq_base(Bit#(8) qp_num, Bit#(64) addr);
        qp_sq_base[qp_num] <= addr;
    endmethod

    // --- Register Interface ---
    method Action reg_read(Bit#(32) addr);
        rg_read_addr <= addr;
        rg_op        <= 1;  // Read
        // Decode address and read from appropriate register block
        case (addr[31:24])
            8'h00: rg_read_data <= {16'h0000, zeroExtend(pack(qp_mgr.get_qp_state(addr[7:0])))};
            8'h01: rg_read_data <= zeroExtend(tx_qp_psn[addr[7:0]]); // LIVE per-QP TX PSN
            8'h02: rg_read_data <= zeroExtend(qp_mgr.get_recv_psn(addr[7:0]));
            8'h03: rg_read_data <= truncate(rc_retransmits);
            8'h0B: rg_read_data <= rc_retry_dropped;   // RTO give-ups
            8'h0D: rg_read_data <= qp_mgr.get_cq_drops;
            8'h0E: rg_read_data <= truncate(rx_packets); // decap rx packet count
            8'h0F: rg_read_data <= zeroExtend(pack(rd_ini_pending)); // initiator READ outstanding
            // Round-28 TX-stall diagnostic: encap FIFO occupancy flags plus
            // the retry-path latches, packed into [15:0] (read-only value
            // data, no scheduling perturbation).
            //   [7:0]   encap {req_ne, req_nf, pkt_ne, pkt_nf, pay_ne,
            //                  pay_nf, icrc_ne, out_ne}
            //   [8]     rc_retry_pend.notEmpty   [9]  rc_retry_buffer.notFull
            //   [10]    rc_rot_hold_v            [11] rc_retx_active
            //   [12]    rc_rto_active            [13] rc_ack_clr_busy
            //   [14]    rc_giveup_pending
            8'h12: rg_read_data <= zeroExtend({
                encap_ifc.get_encap_dbg,
                pack(rc_retry_pend.notEmpty), pack(rc_retry_buffer.notFull),
                pack(rc_rot_hold_v), pack(rc_retx_active), pack(rc_rto_active),
                pack(rc_ack_clr_busy), pack(rc_giveup_pending)});
            8'h21: rg_read_data <= zeroExtend(pack(rq_count)); // posted RQEs
            8'h0C: rg_read_data <= rc_retry_nocache;   // sent unprotected
            8'h04: rg_read_data <= truncate(rdma_read_resps);
            8'h05: rg_read_data <= truncate(wqe_fetched);
            8'h06: rg_read_data <= truncate(atomic_op_count);
            // iCRC verdicts (verifies the RTL CRC against an external reference)
            8'h07: rg_read_data <= decap_ifc.get_icrc_ok;
            8'h08: rg_read_data <= decap_ifc.get_icrc_bad;
            8'h10: rg_read_data <= zeroExtend(pack(dcqcn_ifc.get_ecn_marking));
            8'h80: begin
                // ESUN statistics
                ESUNStatistics stats = esun_ifc.get_statistics;
                case (addr[7:0])
                    8'h00: rg_read_data <= truncate(stats.tx_frames);
                    8'h04: rg_read_data <= truncate(stats.tx_bytes);
                    8'h08: rg_read_data <= truncate(stats.rx_frames);
                    8'h0C: rg_read_data <= truncate(stats.rx_bytes);
                    8'h10: rg_read_data <= truncate(stats.llr_retransmits);
                    8'h14: rg_read_data <= truncate(stats.llr_timeouts);
                    8'h18: rg_read_data <= zeroExtend(esun_ifc.get_llr_tx_seq);
                    8'h1C: rg_read_data <= esun_ifc.get_llr_retry_count;
                    8'h28: rg_read_data <= zeroExtend(esun_ifc.get_llr_retx_base);
                    8'h20: rg_read_data <= esun_ifc.get_llr_retry_dropped;
                    default: rg_read_data <= 0;
                endcase
            end
            default: rg_read_data <= 0;
        endcase
        rg_data_valid <= True;
    endmethod

    method Action reg_write(Bit#(32) addr, Bit#(32) data, Bit#(4) strb);
        rg_write_data <= data;
        rg_write_strb <= strb;
        rg_op         <= 2;  // Write
        // Decode address and write to appropriate register block
        case (addr[31:24])
            8'h10: dcqcn_ifc.set_parameters(addr[7:0],
                                               data[7:0],
                                               data[15:8]);
            8'h14: begin
                dcqcn_ifc.set_rto(addr[7:0], data);
                rc_rto_val_v[addr[7:0]] <= data;
            end
            8'h24: rx_dedup_en <= data[0] == 1;
            8'h02: begin
                // C: set the QP's EXPECTED RECEIVE PSN (testbench sync for
                // loopback delivery tests; in a real system the responder's
                // expected PSN tracks the initiator naturally).
                qp_mgr.update_expected_psn(addr[7:0], truncate(data));
            end
            8'h80: begin
                // ESUN configuration
                case (addr[7:0])
                    8'h00: esun_ifc.set_fragment_enable(data[0] == 1);
                    8'h04: esun_ifc.set_llr_enable(data[0] == 1);
                    8'h08: esun_ifc.set_max_frag_size(data[15:0]);
                    8'h0C: esun_ifc.set_llr_window(data[7:0]);
                    8'h20: esun_ifc.set_llr_timeout(data[15:0]);
                    8'h24: esun_ifc.clear_llr_link_error;
                endcase
            end
            default: begin end
        endcase
    endmethod

    method ActionValue#(Bit#(32)) reg_get_response;
        rg_data_valid <= False;
        return rg_read_data;
    endmethod

    // --- Status ---
    method Bit#(32) get_status;
        Bit#(8) active_count = 0;
        for (Integer i = 0; i < num_qps; i = i + 1) begin
            if (rc_qps_active[i] == 1 || ud_qps_active[i] == 1) begin
                active_count = active_count + 1;
            end
        end
        Bit#(3) tx_st = zeroExtend(pack(tx_state));
        Bit#(3) rx_st = zeroExtend(pack(rx_state));
        // bit[31]: sticky LLR link error (a message was dropped after the
        // retry limit). LLR is link-level and QP-agnostic, so this is a status
        // bit rather than a CQE.
        let link_err = esun_ifc.get_llr_link_error;
        return {(link_err ? 1'b1 : 1'b0), tx_st, 1'b0, rx_st, 16'h0000,
                active_count};
    endmethod

    method Action reset;
        tx_state <= NIC_TX_IDLE;
        rx_state <= NIC_RX_IDLE;
        tx_packets <= 0;
        tx_bytes   <= 0;
        tx_errors   <= 0;
        rx_packets <= 0;
        rx_bytes   <= 0;
        rx_errors   <= 0;
        rc_qps_active <= 0;
        ud_qps_active <= 0;
    endmethod

endmodule

endpackage