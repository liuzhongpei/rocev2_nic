// ============================================================================
// 100G RoCEv2 NIC - Encapsulation (TX) and Decapsulation (RX) Engine
// ============================================================================
// Functional header assembly (TX) and parsing (RX).
// 512-bit data path (64 bytes per beat).
//
// Header layout (first beat, MSB-first byte order in 512-bit word):
//   Bits [511:400] = Ethernet (14 bytes): {dst_mac(48), src_mac(48), type(16)}
//   Bits [399:240] = IPv4 (20 bytes)
//   Bits [239:176] = UDP (8 bytes)
//   Bits [175:80]  = BTH (12 bytes)
//   Bits [79:0]    = Extension header / payload start
//
// Beat-streaming model ("header beats + aligned payload"):
//   The first beat(s) carry only headers; `keep` marks the valid header bytes
//   (54 for SEND, 58 for ACK, 62 for UD, 64+6 for RDMA). Payload beats follow,
//   igned to beat boundaries. No byte-slip insertion is required.
// ============================================================================

`include "RoCEv2NICConfig.bh"
package EncDecapEngine;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import GetPut :: *;
import RoCEv2NICInterfaces :: *;
import CRC32Engine :: *;

// ============================================================================
// Encapsulation Engine (TX Path)
// ============================================================================

module mkEncapEngine(EncapEngineIfc);

    Reg#(Bit#(48)) local_mac <- mkReg(0);
    Reg#(Bit#(32)) local_ip  <- mkReg(0);
    Reg#(Bool)     ecn_enable <- mkReg(True);

    FIFOF#(EncapRequest) req_fifo <- mkFIFOF;
    // The TX protocol is payload-first: the top level streams every payload
    // beat into this FIFO and only submits the descriptor on the LAST beat,
    // while encap_payload cannot consume a single beat until the descriptor is
    // in pkt_fifo (its guard requires pkt_fifo.notEmpty). This FIFO therefore
    // has to hold one whole packet's beats. At depth 2 (mkFIFOF) any packet
    // larger than 128 bytes wedged the TX path permanently - the 3rd beat
    // could never be enqueued, so the last beat never arrived, so the
    // descriptor was never submitted. Sized for MAX_PKT_SIZE (9216 B = 144
    // beats) with margin - the NIC treats 144-beat packets as supported
    // (max_pkt_beats, retry-ring reservation), so 128 would wedge any
    // 8193..9216 B payload permanently. A production build should map this
    // to BRAM rather than flops (160 x 596 bits).
    FIFOF#(DMADataStream) payload_fifo <- mkSizedFIFOF(160);
    FIFOF#(EncapRequest) pkt_fifo <- mkFIFOF;   // descriptor handoff to payload stage
    // One flag per captured descriptor: EncapRequest.reserved2a[1] (host TX).
    // Enqueued at capture (before the frame's first beat reaches out_fifo),
    // consumed by the drain on the frame's LAST beat - FIFO order pairs
    // flags with frames 1:1. Lets the top level tell host frames from
    // RX-generated frames (ACK/NAK/CNP/READ RESPONSE) sharing the drain.
    FIFOF#(Bool) frame_host_fifo <- mkSizedFIFOF(16);
    FIFOF#(MACDataStream) out_fifo <- mkFIFOF;

    // RETH beat1 emitted flag (payload stage only writer)
    Reg#(Bool) reth_done <- mkReg(False);

    // iCRC (CRC32c) machinery: seed from header (capture writes), accumulation
    // in the payload stage, finalized value {pad,icrc} handed to the iCRC beat.
    Reg#(Bit#(32)) crc_seed <- mkReg(32'hFFFFFFFF);
    Reg#(Bit#(32)) crc_accum <- mkReg(32'hFFFFFFFF);
    Reg#(Bool)     payload_first <- mkReg(True);   // first payload beat of packet
    FIFOF#(Bit#(40)) icrc_fifo <- mkFIFOF;         // {pad(8), icrc(32)}

    Reg#(Bit#(64)) tx_packets <- mkReg(0);
    Reg#(Bit#(64)) tx_bytes   <- mkReg(0);

    // Count valid bytes in a keep mask
    function Bit#(7) count_keep(Bit#(64) keep);
        return pack(countOnes(keep));
    endfunction

    // -----------------------------------------------------------------------
    // Stage 1 - Capture: consume the descriptor, emit header beat(s), and hand
    // the descriptor to the payload stage via pkt_fifo. Gated on pkt_fifo being
    // empty so only one packet is in flight (mutually exclusive with stage 2).
    // -----------------------------------------------------------------------

    // Rule-level guard, NOT a body if: the previous packet's iCRC beat must be
    // emitted before the next packet's header beat. As a body-only guard this
    // rule still "fired" (as a no-op) whenever a descriptor was waiting in
    // req_fifo while icrc_fifo held the pending iCRC beat, and because
    // WILL_FIRE_encap_emit_icrc = CAN_FIRE && !WILL_FIRE_encap_capture it
    // blocked the iCRC beat forever - the encap wedged permanently.
    // All three terms are pure `notEmpty` methods, so they add no implicit
    // conditions of their own.
    rule encap_capture if (req_fifo.notEmpty && !pkt_fifo.notEmpty &&
                           !icrc_fifo.notEmpty);
        begin
            let req = req_fifo.first;
            req_fifo.deq;

            $display("  [ENCAP] Packet opcode=0x%02h len=%d qp=%d",
                     req.opcode, req.length, req.qp_num);

            Bool is_ack  = (req.is_ack == 1);
            Bool is_ud   = (req.transport == pack(Transport_UD));
            Bool is_rdma = (req.is_rdma == 1);
            Bool is_reth = is_rdma;   // RETH is 16 bytes -> spills 6 into beat1
            // no_payload (READ REQ): a header-only RETH packet. req.length
            // still goes into the RETH dma_len field, but contributes no
            // payload bytes to the UDP/IP length - the packet ends after
            // the RETH beat-1 with its iCRC beat.
            Bool no_payload = (req.reserved2a[0] == 1);

            // Extension header length (bytes)
            Bit#(7) ext_len = is_ack ? 4 : (is_ud ? 8 : (is_rdma ? 16 : 0));

            // --- Build header beat 0 (MSB-first) ---
            Bit#(512) b0 = 0;
            b0[511:464] = req.remote_mac;       // dst MAC
            b0[463:416] = local_mac;            // src MAC
            b0[415:400] = 16'h0800;             // IPv4

            // IPv4 header
            Bit#(16) len16 = truncate(req.length);
            Bit#(16) ext_len16 = zeroExtend(ext_len);
            // UDP payload = BTH(12) + ext + data + pad + iCRC(4)
            Bit#(16) plen16 = no_payload ? 0 : len16;
            Bit#(16) pad16 = (fromInteger(4) - (plen16 & 16'h3)) & 16'h3;
            Bit#(16) udp_len = fromInteger(20) + ext_len16 + plen16 + pad16 +
                               fromInteger(4);
            Bit#(16) ip_len  = fromInteger(40) + ext_len16 + plen16 + pad16 +
                               fromInteger(4);
            Bit#(8)  dscp_ecn = ecn_enable ? 8'h20 : 8'h00;

            b0[399:392] = 8'h45;                // version=4, IHL=5
            b0[391:384] = dscp_ecn;             // DSCP+ECN
            b0[383:368] = ip_len;
            b0[367:352] = 16'h0000;             // identification
            b0[351:336] = 16'h4000;             // DF flag
            b0[335:328] = 8'h40;                // TTL 64
            b0[327:320] = 8'h11;                // protocol UDP
            b0[319:304] = 16'h0000;             // checksum (0 for simplicity)
            b0[303:272] = local_ip;             // src IP
            b0[271:240] = req.dst_ip;           // dst IP

            // UDP header
            b0[239:224] = {req.qp_num, 8'h01};  // src port
            b0[223:208] = 16'h12B7;             // dst port 4791
            b0[207:192] = udp_len;
            b0[191:176] = 16'h0000;             // checksum 0

            // BTH
            b0[175:168] = req.opcode;
            b0[167:164] = truncate(pad16);      // BTH Pad Count (real value)
            b0[163:160] = {1'b0, 1'b0, 2'b00};  // SE, mig_req, reserved
            b0[159:152] = 8'h00;                // transport version
            b0[151:136] = 16'hFFFF;             // P_Key
            b0[135:134] = 2'b00;
            b0[133]     = req.is_last;   // B flag (last packet)
            b0[132]     = req.is_first;  // F flag (first packet)
            b0[131:108] = req.psn;
            b0[107:84]  = zeroExtend(req.qp_num);
            b0[83:80]   = 4'h0;

            // Extension header in bytes 54..63
            if (is_ack) begin
                // AETH (4 bytes): syndrome + MSN
                b0[79:72] = req.ack_syndrome;
                b0[71:48] = 24'h000001;
            end else if (is_ud) begin
                // DETH (8 bytes): qkey + src_qpn + reserved
                b0[79:48] = req.qkey;   // DETH QKey from the QP context
                b0[47:24] = zeroExtend(req.qp_num);
                b0[23:16] = 8'h00;
            end else if (is_reth) begin
                // RETH (16 bytes): first 10 bytes fit in beat0
                //   bytes 54..61 = va[63:0], bytes 62..63 = rkey[31:16]
                b0[79:16] = req.remote_addr;         // va[63:0]
                b0[15:0]  = req.r_key[31:16];        // rkey[31:16]
            end

            // Header keep for beat 0 (constant per ext type)
            Bit#(64) hdr_keep0 = 0;
            Bit#(64) crc_keep0 = 0;
            if (is_rdma) begin
                hdr_keep0 = 64'hFFFFFFFFFFFFFFFF;   // 64 bytes (54 hdr + 10 RETH)
                crc_keep0 = 64'hFFFFFC0000000000;   // bytes 42..63
            end else if (is_ud) begin
                hdr_keep0 = 64'h3FFFFFFFFFFFFFFF;   // 62 bytes
                crc_keep0 = 64'h3FFFFC0000000000;   // bytes 42..61
            end else if (is_ack) begin
                hdr_keep0 = 64'h03FFFFFFFFFFFFFF;   // 58 bytes
                crc_keep0 = 64'h03FFFC0000000000;   // bytes 42..57
            end else begin
                hdr_keep0 = 64'h003FFFFFFFFFFFFF;   // 54 bytes
                crc_keep0 = 64'h003FFC0000000000;   // bytes 42..53
            end

            // CRC32c seed: cover the UDP payload of the header beat(s) (byte 42+)
            Bit#(32) crc_seed_val = crc32c_beat(b0, crc_keep0, 32'hFFFFFFFF);
            crc_seed <= crc_seed_val;

            // Emit header beat 0
            MACDataStream h0;
            h0.data  = b0;
            h0.keep  = hdr_keep0;
            h0.valid = 1;
            h0.ready = 1;
            h0.error = 0;
            h0.first = 1;
            // Every normal frame is terminated by its iCRC beat, which always
            // follows (encap_emit_icrc). Length-0 frames (ACK/NAK/CNP) have no
            // payload stage, so that beat is emitted inline above - udp_len
            // already counts those 4 bytes, so they MUST be on the wire or the
            // receiver waits for bytes that never arrive.
            // The iCRC beat always follows and carries the frame's last flag.
            h0.last  = 0;

            // Length-0 frames (ACK/NAK/CNP) have no payload stage, so their
            // iCRC beat is emitted from here instead of by encap_payload:
            // udp_len already counts those 4 bytes, so they MUST be on the
            // wire or the receiver waits for bytes that never arrive.
            if (req.length == 0 && !is_reth) begin
                icrc_fifo.enq({8'h0, crc32c_finalize(crc_seed_val)});
            end

            out_fifo.enq(h0);

            tx_packets <= tx_packets + 1;
            tx_bytes   <= tx_bytes +
                          (req.reserved2a[0] == 1 ? 0 : zeroExtend(req.length));

            // Hand the descriptor to the payload stage: normal packets are
            // followed by their payload beats; an RETH-carrying packet always
            // needs the RETH beat-1 emitted there. A length-0 RETH has no
            // payload beats either - it is rerouted through the no_payload
            // path so it still gets its RETH beat-1 and iCRC beat (an
            // unterminated single-beat frame would wedge the receiver).
            // Frame ownership flag (also for the inline-iCRC length-0
            // frames, which never reach the payload stage).
            frame_host_fifo.enq(req.reserved2a[1] == 1);
            if (req.length != 0 || is_reth) begin
                if (is_reth && req.length == 0)
                    req.reserved2a[0] = 1;
                pkt_fifo.enq(req);
            end
        end
    endrule

    // -----------------------------------------------------------------------
    // Stage 2 - Payload: three MUTUALLY EXCLUSIVE rules over the shared
    // descriptor (pkt_fifo). They were once branches of one rule, but bsc
    // hoists the implicit conditions of methods used anywhere in a rule into
    // its fire condition - payload_fifo$EMPTY_N conjoined unconditionally
    // would make a header-only packet (empty payload FIFO) wedge the engine
    // forever. Separate rules keep each rule's hoisted conditions consistent
    // with its own purpose.
    // -----------------------------------------------------------------------
    // 2a - RETH beat-1: emitted once per RETH-carrying packet (before any
    // payload beat), never for header-only non-RETH packets.
    rule encap_reth_beat1 if (pkt_fifo.notEmpty && !reth_done &&
                              pkt_fifo.first.is_rdma == 1);
        let req = pkt_fifo.first;
        // RETH beat1 (bytes 64..69): rkey[15:0] + dma_len[31:0]
        MACDataStream h1;
        h1.data  = 0;
        h1.data[511:496] = req.r_key[15:0];
        h1.data[495:464] = req.length;   // dma_len
        h1.keep  = 64'h000000000000003F;   // 6 bytes
        h1.valid = 1;
        h1.ready = 1;
        h1.error = 0;
        h1.first = 0;
        h1.last  = 0;
        out_fifo.enq(h1);
        // Fold the 6 RETH spill bytes into the CRC domain: the decap
        // folds them from the skip beat (crc_hdr_keep covers bytes
        // 42..63 of beat 0, then 64..69 here), so they must be folded
        // on the send side too. payload_first drops so the first
        // payload beat continues from crc_accum rather than crc_seed.
        crc_accum     <= crc32c_beat(h1.data, 64'h000000000000003F,
                                     crc_seed);
        payload_first <= False;
        reth_done <= True;
    endrule

    // 2b - Payload beats: forward them and terminate (dequeue pkt_fifo) on
    // the last beat. Only for descriptors that DO expect payload beats
    // (after their RETH beat-1; non-RDMA packets skip 2a entirely).
    rule encap_payload_data if (pkt_fifo.notEmpty && payload_fifo.notEmpty &&
                                pkt_fifo.first.reserved2a[0] == 0 &&
                                (reth_done || pkt_fifo.first.is_rdma == 0));
        let req = pkt_fifo.first;
        let beat = payload_fifo.first;
        payload_fifo.deq;

        MACDataStream out;
        out.data  = beat.data;
        out.keep  = beat.keep;
        out.valid = 1;
        out.ready = 1;
        out.error = 0;
        out.first = 0;
        out.last  = 0;   // the iCRC beat carries the frame's last flag
        out_fifo.enq(out);

        // Accumulate CRC32c over the payload (from the header seed on
        // the first payload beat of the packet)
        Bit#(32) crc_new = payload_first ?
            crc32c_beat(beat.data, beat.keep, crc_seed) :
            crc32c_beat(beat.data, beat.keep, crc_accum);
        crc_accum <= crc_new;

        if (beat.last == 1) begin
            // Finalize: fold pad-to-4-alignment zero bytes, then append
            Bit#(32) plen = zeroExtend(req.length);
            Bit#(32) pad32 = (fromInteger(4) - (plen & 32'h3)) & 32'h3;
            Bit#(32) fcrc = crc_new;
            // Fold up to 3 pad zero-bytes into the CRC
            fcrc = (pad32 >= 1) ? crc32c_byte(8'h00, fcrc) : fcrc;
            fcrc = (pad32 >= 2) ? crc32c_byte(8'h00, fcrc) : fcrc;
            fcrc = (pad32 >= 3) ? crc32c_byte(8'h00, fcrc) : fcrc;
            // Hand {pad, icrc} to the iCRC beat (pad transmitted on wire)
            icrc_fifo.enq({truncate(pad32), crc32c_finalize(fcrc)});

            pkt_fifo.deq;
            reth_done <= False;
        end
        payload_first <= (beat.last == 1) ? True : False;
    endrule

    // 2c - Header-only completion (READ REQ, no_payload): no payload beats
    // follow. The iCRC covers h0 bytes 42..63 plus the 6 RETH spill bytes
    // (folded into crc_accum by 2a the previous cycle); a header-only packet
    // with no RETH never ran 2a, so its h0 fold still lives in crc_seed.
    // There is no payload, so pad is 0.
    rule encap_np_complete if (pkt_fifo.notEmpty &&
                               pkt_fifo.first.reserved2a[0] == 1 &&
                               (reth_done || pkt_fifo.first.is_rdma == 0));
        Bit#(32) fcrc = reth_done ? crc_accum : crc_seed;
        icrc_fifo.enq({8'h0, crc32c_finalize(fcrc)});
        pkt_fifo.deq;
        reth_done     <= False;
        payload_first <= True;
    endrule

    // keep mask with the low `n` bits set (n <= 64)
    function Bit#(64) keep_for_len(Bit#(7) n);
        Bit#(64) k = 0;
        for (Integer i = 0; i < 64; i = i + 1)
            if (fromInteger(i) < n) k[i] = 1;
        return k;
    endfunction

    // Emit the iCRC beat as the final beat of the packet: [pad bytes][iCRC]
    // keep = 4 + pad, so the pad is transmitted (receiver CRC domain matches).
    rule encap_emit_icrc;
        if (icrc_fifo.notEmpty) begin
            Bit#(7)  pd = truncate(icrc_fifo.first[39:32]);   // pad count (0..3)
            Bit#(32) icrc = icrc_fifo.first[31:0];
            icrc_fifo.deq;

            MACDataStream icrc_beat;
            icrc_beat.data = 0;
            // iCRC byte0 (icrc[31:24]) lands at frame byte `pd`
            Bit#(32) sh = 32'd480 - 8 * zeroExtend(pd);
            icrc_beat.data = zeroExtend(icrc) << sh;
            icrc_beat.keep  = keep_for_len(fromInteger(4) + pd);
            icrc_beat.valid = 1;
            icrc_beat.ready = 1;
            icrc_beat.error = 0;
            icrc_beat.first = 0;
            icrc_beat.last  = 1;
            out_fifo.enq(icrc_beat);
        end
    endrule

    // -----------------------------------------------------------------------
    // Interface
    // -----------------------------------------------------------------------

    method ActionValue#(Bool) get_frame_host;
        let f = frame_host_fifo.first;
        frame_host_fifo.deq;
        return f;
    endmethod

    // TRUE iff NO frame is anywhere in the encap pipeline (descriptor queue,
    // payload stage, iCRC pending, output). A frame in flight spans from
    // capture to its iCRC beat leaving out_fifo; every FIFO between them is
    // non-empty for at least one cycle of that span, so the conjunction of
    // their emptiness is an exact "idle" predicate. Frame producers that
    // stream multiple beats (RTO retx replay) must wait for this before
    // STARTing, or their beats splice into an in-flight RX-generated frame.
    method Bool encap_idle;
        return !req_fifo.notEmpty && !pkt_fifo.notEmpty &&
               !icrc_fifo.notEmpty && !payload_fifo.notEmpty &&
               !out_fifo.notEmpty;
    endmethod

    // Round-28 diagnostic: raw FIFO occupancy flags for the TX stall
    // investigation (PBIG wedge). Read-only value method - no scheduling
    // perturbation. {req_ne, req_nf, pkt_ne, pkt_nf, pay_ne, pay_nf,
    //                 icrc_ne, out_ne} in bits [7:0].
    method Bit#(8) get_encap_dbg;
        return {pack(req_fifo.notEmpty), pack(req_fifo.notFull),
                pack(pkt_fifo.notEmpty), pack(pkt_fifo.notFull),
                pack(payload_fifo.notEmpty), pack(payload_fifo.notFull),
                pack(icrc_fifo.notEmpty), pack(out_fifo.notEmpty)};
    endmethod

    method Action request(EncapRequest req) if (req_fifo.notFull);
        req_fifo.enq(req);
    endmethod

    method Action enq_payload(DMADataStream beat) if (payload_fifo.notFull);
        payload_fifo.enq(beat);
    endmethod

    method ActionValue#(MACDataStream) get_packet;
        let pkt = out_fifo.first;
        out_fifo.deq;
        return pkt;
    endmethod

    method Action set_local_mac(Bit#(48) mac);
        local_mac <= mac;
    endmethod

    method Action set_local_ip(Bit#(32) ip);
        local_ip <= ip;
    endmethod

    method Action set_ecn_enable(Bool enable);
        ecn_enable <= enable;
    endmethod

endmodule

// ============================================================================
// Decapsulation Engine (RX Path)
// ============================================================================

// Parsed packet info handed from the parse stage to the payload stage.
typedef struct {
    Bit#(8)  opcode;
    Bit#(24) psn;
    Bit#(24) qp;
    Bit#(48) src_mac;
    Bit#(32) src_ip;    // sender IP (for ACK/CNP replies)
    Bit#(2)  ecn;
    Bit#(1)  is_cnp;
    Bit#(1)  is_rdma;
    Bit#(1)  is_error;
    Bit#(1)  skip_hdr;   // RDMA: one more header beat to consume
    Bit#(2)  padcnt;     // BTH Pad Count: pad bytes between payload and iCRC
    Bit#(16) length;
    Bit#(64) va;
    Bit#(16) rkey_lo;   // RETH rkey[15:0], carried on the skip beat
    Bit#(32) rkey;
    Bit#(32) qkey;      // DETH QKey (UD)
    Bit#(24) src_qpn;   // DETH source QP (UD)
    Bit#(32) imm_data;  // immediate data (IMM opcodes)
    Bit#(32) dma_len;   // RETH dma_len (RDMA READ/WRITE length)
    Bit#(64) atomic_a;  // AtomicETH swap/addend (CMP_SWAP/FADD)
    Bit#(64) atomic_b;  // AtomicETH compare (CMP_SWAP)
    Bit#(8)  ack_syndrome; // AETH syndrome (ACK/NAK opcodes share 0x00)
} ParsedPkt deriving (Bits, Eq, FShow);

module mkDecapEngine(DecapEngineIfc);

    Reg#(Bit#(48)) local_mac <- mkReg(0);
    Reg#(Bit#(32)) local_ip  <- mkReg(0);

    // Per-QP transport (set from the QP-create path). Vector of Regs, not a
    // RegFile, so the reset value is a defined Transport_RC.
    Vector#(64, Reg#(TransportMode)) qp_transport <- replicateM(mkReg(Transport_RC));

    FIFOF#(MACDataStream) in_fifo <- mkFIFOF;
    FIFOF#(DecapResult)   out_fifo <- mkFIFOF;
    FIFOF#(CNPPacket)     cnp_fifo <- mkFIFOF;

    // Parse/payload stage state (single writer: decap_ingest)
    Reg#(Bool)     parsing <- mkReg(False);
    Reg#(ParsedPkt) parsed_pkt <- mkReg(unpack(0));
    Reg#(Bit#(32)) payload_left <- mkReg(0);
    // Payload bytes that shared the HEADER beat (forwarded by the header
    // parse itself - see the HDRPAY emit). Zero for every frame whose
    // payload starts after byte 63 (all encap-generated frames). Overloading
    // first_payload_beat for this broke the atomic DEFER path and the
    // is_first consumers, so it gets its own register.
    Reg#(Bit#(7))  rx_hdr_tail  <- mkReg(0);
    Reg#(Bool)     first_payload_beat <- mkReg(True);
    Reg#(Bool)     skip_done <- mkReg(False);
    Reg#(Bit#(32)) crc_accum <- mkReg(32'hFFFFFFFF);   // running CRC32c (RX iCRC)
    Reg#(Bit#(32)) rx_dma_len <- mkReg(0);             // RETH dma_len (RDMA)
    Reg#(Bit#(16)) rx_rkey_lo <- mkReg(0);             // RETH rkey[15:0] (skip beat)

    // keep mask with bits [lo..hi) set (byte lo..hi-1 valid)
    function Bit#(64) keep_range(Bit#(7) lo, Bit#(7) hi);
        Bit#(64) m = 0;
        for (Integer i = 0; i < 64; i = i + 1)
            if (fromInteger(i) >= lo && fromInteger(i) < hi) m[i] = 1;
        return m;
    endfunction

    // Stats
    Reg#(Bit#(64)) rx_packets   <- mkReg(0);
    Reg#(Bit#(64)) rx_bytes     <- mkReg(0);
    Reg#(Bit#(32)) rx_errors    <- mkReg(0);
    Reg#(Bit#(32)) cnp_detected <- mkReg(0);
    // iCRC verdicts, exposed so a test can prove the RTL's CRC matches an
    // external reference (the encap and decap are self-consistent even when
    // both are wrong, so a loopback check alone cannot catch a bad CRC).
    Reg#(Bit#(32)) icrc_ok_cnt  <- mkReg(0);
    Reg#(Bit#(32)) icrc_bad_cnt <- mkReg(0);

    function Bit#(7) count_keep(Bit#(64) keep);
        return pack(countOnes(keep));
    endfunction

    // Build a DecapResult from a parsed record + beat data
    function DecapResult build_result(ParsedPkt p, Bit#(512) data,
                                      Bit#(64) keep,
                                      Bit#(1) first, Bit#(1) last,
                                      Bit#(1) icrc_ok);
        DecapResult result;
        result.qp_num     = truncate(p.qp);
        result.opcode     = p.opcode;
        result.is_first   = first;
        result.is_last    = last;
        result.is_imm      = (p.opcode == `OPCODE_SEND_ONLY_IMM ||
                              p.opcode == `OPCODE_SEND_LAST_IMM ||
                              p.opcode == `OPCODE_RDMA_WRITE_IMM) ? 1 : 0;
        result.is_rdma     = p.is_rdma;
        result.is_error    = p.is_error;
        result.is_cnp      = p.is_cnp;
        result.i_crc_ok    = icrc_ok;
        result.reserved1   = 0;
        result.length      = zeroExtend(p.length);
        result.psn         = p.psn;
        result.error_code  = (p.is_error == 1) ? 8'h01 : 0;
        result.src_qp      = zeroExtend(p.src_qpn);
        result.qkey        = p.qkey;
        result.local_addr  = p.va;
        // rkey[31:16] comes from the header beat, rkey[15:0] from the skip beat
        result.r_key       = p.is_rdma == 1 ? {p.rkey[15:0], rx_rkey_lo} : 0;
        result.imm_data    = p.imm_data;
        result.src_mac     = p.src_mac;
        result.src_ip      = p.src_ip;
        result.ecn         = p.ecn;
        result.dma_len     = rx_dma_len;
        result.atomic_a    = p.atomic_a;
        result.atomic_b    = p.atomic_b;
        result.ack_syndrome = p.ack_syndrome;
        result.data        = data;
        result.byte_en     = keep;
        return result;
    endfunction

    // -----------------------------------------------------------------------
    // Parse the first header beat. Gated on pkt_fifo empty (one packet in
    // flight) so BSV can prove mutual exclusion with the payload stage.
    // -----------------------------------------------------------------------
    // Single ingest rule: parses the header beat (packet start) and streams
    // the payload beats. One rule owns in_fifo.deq and the parsed-packet
    // registers, avoiding the two-rule-deq scheduling conflict.
    // -----------------------------------------------------------------------
    rule decap_ingest;
        if (in_fifo.notEmpty) begin
            let stream = in_fifo.first;

            // A first=1 beat ALWAYS opens a frame parse - even mid-parse.
            // Previously a parse left incomplete by a lost frame tail (its
            // remaining beats never arrived) kept `parsing` stuck True and
            // consumed every later frame's header beat as payload,
            // corrupting the whole stream from that point on. Re-syncing on
            // the frame-start flag matches the ESUN RX behavior (a first=1
            // beat is a frame boundary; legitimate payload beats never
            // carry it).
            if (stream.first == 1) begin
                // --- Parse the first header beat ---
                in_fifo.deq;

                Bit#(512) d = stream.data;

                Bit#(48) dst_mac = d[511:464];
                Bit#(48) src_mac = d[463:416];
                Bit#(16) eth_type = d[415:400];
                Bit#(8)  dscp_ecn = d[391:384];
                Bit#(8)  protocol = d[327:320];
                Bit#(32) dst_ip = d[271:240];
                Bit#(16) udp_dst_port = d[223:208];
                Bit#(16) udp_len = d[207:192];
                Bit#(8)  opcode = d[175:168];
                Bit#(24) psn = d[131:108];
                Bit#(24) qp = d[107:84];
                Bit#(80) ext = d[79:0];

                Bool pkt_cnp  = (opcode == `OPCODE_CNP);
                // ACK (0x0E) and ATOMIC ACK (0x0F) both carry a 4-byte AETH:
                // the encap writes the AETH whenever is_ack=1, which covers
                // both opcodes - decap must classify them the same way or the
                // iCRC domain (42..57 vs 42..53) and p_len disagree by 4 and
                // every looped-back ATOMIC ACK fails iCRC validation.
                Bool pkt_ack  = (opcode == `OPCODE_ACK ||
                                 opcode == `OPCODE_ATOMIC_ACK);
                // RDMA READ RESPONSE carries an AETH (4B), not a RETH.
                Bool pkt_read_rsp = (opcode >= `OPCODE_RDMA_READ_RSP_FST &&
                                     opcode <= `OPCODE_RDMA_READ_RSP_LST);
                // RETH-carrying ops: RDMA WRITE (0x06-0x09) and READ REQ (0x0A)
                Bool pkt_rdma = (opcode >= `OPCODE_RDMA_WRITE_FIRST &&
                                 opcode <= `OPCODE_RDMA_READ_REQ) ||
                                (opcode == `OPCODE_COMPARE_SWAP) ||
                                (opcode == `OPCODE_FETCH_ADD);
                Bool pkt_imm  = (opcode == `OPCODE_SEND_LAST_IMM ||
                                 opcode == `OPCODE_SEND_ONLY_IMM ||
                                 opcode == `OPCODE_RDMA_WRITE_IMM);

                // Extension header size (AETH/IMM=4, RETH=16). A UD SEND
                // carries an 8-byte DETH; an RC SEND carries nothing - the two
                // share opcode 0x04, so only the QP's transport can tell them
                // apart. (SEND-with-IMM still assumes a bare 4-byte IMM: the
                // encap cannot emit one, so no UD+IMM sender exists.)
                Bool qp_is_ud = (qp_transport[qp[5:0]] == Transport_UD);
                Bit#(7) ext_len = pkt_ack ? 4 :
                                  (pkt_read_rsp ? 4 :
                                   (pkt_rdma ? 16 :
                                    (pkt_imm ? 4 :
                                     ((opcode <= `OPCODE_SEND_ONLY_IMM && qp_is_ud)
                                      ? 8 : 0))));

                // iCRC domain, beat 0 only: the BTH starts at byte 42 and the
                // extension headers end at byte 54+ext_len, but beat 0 only
                // carries up to byte 63 - for RETH (ext_len 16) the remaining 6
                // bytes live on the skip beat and are folded there.
                Bit#(7) hdr_end = (fromInteger(54) + ext_len > fromInteger(64)) ?
                                  fromInteger(64) : (fromInteger(54) + ext_len);

                // Packet validation: IPv4 / UDP / RoCEv2 port / dest match
                Bool addr_error = (eth_type != 16'h0800) ||
                                  (protocol != 8'h11) ||
                                  (udp_dst_port != `ROCEV2_UDP_PORT) ||
                                  (dst_mac != local_mac) ||
                                  (dst_ip != local_ip);

                Bool len_error = (udp_len < fromInteger(20)) ||
                                 (udp_len - fromInteger(20) < zeroExtend(ext_len)) ||
                                 addr_error;
                Bit#(16) after_bth = udp_len - fromInteger(20);
                Bit#(16) p_len = len_error ? 0 : (after_bth - zeroExtend(ext_len));

                ParsedPkt p;
                p.opcode   = opcode;
                p.psn      = psn;
                p.qp       = qp;
                p.atomic_a = 0;   // captured from the spill beat (atomics)
                p.atomic_b = 0;
                p.src_mac  = src_mac;
                p.src_ip   = d[303:272];          // sender IP (for ACK replies)
                p.ecn      = dscp_ecn[1:0];
                p.is_cnp   = pkt_cnp ? 1 : 0;
                p.is_rdma  = pkt_rdma ? 1 : 0;
                p.is_error = len_error ? 1 : 0;
                p.skip_hdr = (pkt_rdma && p_len != 0) ? 1 : 0;
                // BTH Pad Count is 2 bits. The encap writes truncate(pad16)
                // (4 bits) at b0[167:164]; the pad VALUE (0..3) lives in its
                // low 2 bits, i.e. b0[165:164] - reading [167:166] (the
                // always-zero high half of that 4-bit slice) made decap see
                // padcnt=0 for every non-4-aligned payload and leak the pad
                // bytes into the host stream / RX write length.
                p.padcnt   = d[165:164];   // BTH Pad Count is 2 bits
                p.rkey_lo  = 0;
                p.length   = p_len;
                p.va       = pkt_rdma ? ext[79:16] : 0;       // va[63:0]
                p.rkey     = pkt_rdma ? zeroExtend(ext[15:0]) : 0;  // rkey[31:16]
                // UD DETH (bytes 54..61): qkey + src_qpn; IMM data for IMM ops
                p.qkey     = (pkt_rdma || pkt_ack) ? 0 : ext[79:48];
                p.src_qpn  = (pkt_rdma || pkt_ack) ? 0 : ext[47:24];
                // AETH syndrome (byte 54): a NAK shares the ACK opcode 0x00
                // and is told apart ONLY by a non-zero syndrome.
                p.ack_syndrome = pkt_ack ? ext[79:72] : 0;
                p.imm_data = pkt_imm ? ext[79:48] : 0;
                p.dma_len  = 0;   // filled from the 2nd RETH beat (skip_hdr)

                // Seed the iCRC accumulator over the UDP payload (byte 42+)
                // INCLUDING the payload bytes that share this header beat:
                // a real RoCEv2 sender packs the payload right after the
                // headers, so for ext_len < 10 the first MAC beat carries
                // payload beyond hdr_end. The encap's own 64B-aligned layout
                // (header-beat keep stops at hdr_end) never produces those
                // bytes, which is why the drop went unnoticed - see the
                // forwarding fix below.
                Bit#(64) crc_hdr_keep = keep_range(fromInteger(42), hdr_end);
                Bit#(64) hdr_tail_keep = stream.keep &
                    ~keep_range(0, hdr_end);
                Bit#(7)  tail_cnt = count_keep(hdr_tail_keep);
                crc_accum <= crc32c_beat(d, crc_hdr_keep | hdr_tail_keep,
                                         32'hFFFFFFFF);

                $display("  [DECAP] RX opcode=0x%02h qp=%d psn=%d len=%d %s",
                         opcode, qp, psn, p_len,
                         len_error ? "LEN-ERR" : "");

                if (p_len == 0 || stream.last == 1) begin
                    // Control packet (ACK/CNP) or a single-beat frame. The
                    // `stream.last` term is essential, not defensive:
                    // length-0 frames (ACK/NAK/CNP) are emitted by the encap
                    // without an iCRC beat, while udp_len always adds the 4
                    // iCRC bytes, so p_len is 4 for every one of them.
                    // Without this term the parser waits forever for 4 bytes
                    // that never arrive and then swallows the next frame's
                    // header beat as this packet's payload.
                    Bit#(16) plen_pay = (p_len > 4 + zeroExtend(p.padcnt)) ?
                                        p_len - 4 - zeroExtend(p.padcnt) : 0;
                    if (tail_cnt > 0 && plen_pay > 0) begin
                        // Single-beat frame WITH in-beat payload: a real
                        // RoCEv2 sender packs the payload right after the
                        // headers, so small frames carry payload + pad +
                        // iCRC all in this beat. Forward the payload bytes
                        // and verify the iCRC IN PLACE - it is the last 4
                        // valid bytes of the beat. The old code dropped the
                        // payload entirely and reported i_crc_ok=1 without
                        // any check (silent data loss on external small
                        // SENDs, and a hollow atomic-execution guard).
                        Bit#(64) tk   = pack(hdr_tail_keep);
                        Bit#(7)  t7   = truncate(pack(countLeadingZeros(tk)));
                        Bit#(7)  lastb = 63 - t7;
                        Bit#(7)  icrc_lo = (lastb >= 3) ? lastb - 3 : 0;
                        // payload+pad = the tail bytes below the 4 iCRC bytes
                        Bit#(64) pay_mask = hdr_tail_keep &
                                            ~keep_range(icrc_lo, lastb + 1);
                        // shift the 4 iCRC bytes up to the top of the beat
                        Bit#(10) shamt = zeroExtend(63 - lastb) * 8;
                        Bit#(512) sh = d << shamt;
                        Bit#(32) icrc_be = sh[31:0];
                        Bit#(32) calc = crc32c_beat(d, crc_hdr_keep | pay_mask,
                                                    32'hFFFFFFFF) ^
                                        32'hFFFFFFFF;
                        Bit#(1) vok = (lastb >= 3 && calc == icrc_be) ? 1 : 0;
                        DecapResult r = build_result(p, stream.data,
                            hdr_tail_keep, 1, 1, vok);
                        r.length = zeroExtend(plen_pay);
                        $display("  [DECAP-SB] opcode=0x%02h tail=%0d %s",
                                 p.opcode, tail_cnt, (vok == 1) ? "OK" : "FAIL");
                        if (vok == 1) icrc_ok_cnt  <= icrc_ok_cnt  + 1;
                        else          icrc_bad_cnt <= icrc_bad_cnt + 1;
                        out_fifo.enq(r);
                        rx_packets <= rx_packets + 1;
                        rx_bytes   <= rx_bytes + zeroExtend(plen_pay);

                        if (pkt_cnp) begin
                            CNPPacket cnp;
                            cnp.qp_num   = truncate(qp);
                            cnp.psn      = psn;
                            cnp.qdepth   = 0;
                            cnp.prio     = 0;
                            cnp.reserved = 0;
                            cnp_fifo.enq(cnp);
                            cnp_detected <= cnp_detected + 1;
                        end
                    end else begin
                        // True control frame (no payload beyond the AETH/iCRC
                        // words): emit immediately with no payload.
                        DecapResult r = build_result(p, 0, 0, 1, 1, 1);
                        r.length = 0;   // this packet carries no payload beat
                        $display("  [DECAP-EMIT] ctrl opcode=0x%02h", p.opcode);
                        out_fifo.enq(r);
                        rx_packets <= rx_packets + 1;

                        if (pkt_cnp) begin
                            CNPPacket cnp;
                            cnp.qp_num   = truncate(qp);
                            cnp.psn      = psn;
                            cnp.qdepth   = 0;
                            cnp.prio     = 0;
                            cnp.reserved = 0;
                            cnp_fifo.enq(cnp);
                            cnp_detected <= cnp_detected + 1;
                        end
                    end
                end else begin
                    parsed_pkt <= p;
                    parsing <= True;
                    // Forward the header beat's trailing payload bytes (if
                    // any) - the payload stage only sees beats AFTER this
                    // one, so without this emit those bytes were silently
                    // dropped for every frame whose payload starts before
                    // byte 64 (RC SEND: bytes 54..63; AETH frames: 58..63).
                    // Encap-generated frames are unaffected (aligned layout,
                    // hdr_tail_keep = 0). i_crc_ok=0 here: the verdict only
                    // exists at the last beat.
                    if (tail_cnt > 0) begin
                        DecapResult r0 = build_result(p, stream.data,
                            hdr_tail_keep, 1, 0, 0);
                        // Match the payload-stage results' length semantics
                        // (payload only, pad+iCRC excluded) - the raw p_len
                        // made the READ-RSP write metadata and rx_bytes
                        // overcount by 4+padcnt.
                        r0.length = (p_len > 4 + zeroExtend(p.padcnt)) ?
                                    zeroExtend(p_len - 4 - zeroExtend(p.padcnt)) :
                                    0;
                        out_fifo.enq(r0);
                        $display("  [DECAP-HDRPAY] opcode=0x%02h tail=%0d",
                                 p.opcode, tail_cnt);
                    end
                    Bit#(32) t32 = zeroExtend(tail_cnt);
                    Bit#(32) p32 = zeroExtend(p_len);
                    payload_left <= (t32 >= p32) ? 0 : p32 - t32;
                    rx_hdr_tail <= tail_cnt;
                    first_payload_beat <= True;
                    skip_done <= False;
                end
            end else if (parsing) begin
                // --- Payload stage ---
                let p = parsed_pkt;

                if (p.skip_hdr == 1 && !skip_done) begin
                    // consume the 2nd RDMA header beat (6 RETH bytes in UDP
                    // payload, so they also feed the iCRC); capture dma_len
                    // (bytes 66..69 of the RETH = bits [495:464])
                    in_fifo.deq;
                    rx_dma_len   <= stream.data[495:464];
                    rx_rkey_lo   <= stream.data[511:496];   // rkey[15:0]
                    // Fold the spill beat's ACTUAL bytes (the beat's own
                    // keep): 6 for a RETH spill, 18 for an atomic spill. The
                    // old hardwired 6-byte keep silently left 12 atomic
                    // operand bytes out of the iCRC domain.
                    crc_accum <= crc32c_beat(stream.data, stream.keep,
                                             crc_accum);
                    $display("  [DECAP-SKIP] opcode=0x%02h dma_len=%d",
                             p.opcode, stream.data[495:464]);
                    // R9: atomic request - the 18-byte spill beat carries
                    // rkey[15:0] + swap/addend + compare. Atomics carry no
                    // data payload.
                    if (p.opcode == `OPCODE_COMPARE_SWAP ||
                        p.opcode == `OPCODE_FETCH_ADD) begin
                        ParsedPkt ap = p;
                        // AtomicETH layout: frame bytes 54..81 = va(8) +
                        // rkey(4) + swap(8) + compare(8). The skip beat
                        // carries frame bytes 64..81 = beat bytes 0..17, so
                        // swap is beat bytes 2..9 and compare bytes 10..17.
                        // The old [503:440]/[439:376] were one byte early
                        // (mixing rkey[15:8] into swap and swap[7:0] into
                        // compare) - the testbench mirrored the error, so it
                        // was invisible until the layout was re-derived.
                        ap.atomic_a = stream.data[495:432]; // swap/addend
                        ap.atomic_b = stream.data[431:368]; // compare
                        if (stream.last == 1) begin
                            // Frame ends at the spill beat: no iCRC beat
                            // follows, so nothing can be verified - the
                            // result must NOT claim i_crc_ok=1. Emit now,
                            // with the SAME-BEAT rkey/dma_len (the registers
                            // above are only written at the end of this
                            // cycle; reading them here would return the
                            // PREVIOUS packet's values).
                            DecapResult r = build_result(ap, 0, 0, 1, 1, 0);
                            r.length  = 0;   // no data payload: otherwise
                                             // the spilled operand bytes
                                             // would be forwarded to
                                             // rx_stream and block the
                                             // atomic write-back
                            r.r_key   = {p.rkey[15:0], stream.data[511:496]};
                            r.dma_len = stream.data[495:464];
                            out_fifo.enq(r);
                            rx_packets <= rx_packets + 1;
                            parsing   <= False;
                            skip_done <= False;
                            // No crc_accum reset here: this rule already
                            // wrote crc_accum once above (a second
                            // conditional write would be G0004), and the
                            // next frame re-seeds the accumulator explicitly
                            // at its header parse.
                            $display("  [DECAP-ATOMIC] opcode=0x%02h a=%h b=%h EMIT(no-icrc)",
                                     p.opcode, ap.atomic_a, ap.atomic_b);
                        end else begin
                            // An iCRC beat follows: persist the operands and
                            // let the payload stage's last-beat path perform
                            // the real iCRC verification and emit the
                            // deferred result. The iCRC beat's keep masks to
                            // zero payload bytes, so nothing spills into the
                            // host's rx_stream.
                            parsed_pkt <= ap;
                            skip_done  <= True;
                            $display("  [DECAP-ATOMIC] opcode=0x%02h a=%h b=%h DEFER",
                                     p.opcode, ap.atomic_a, ap.atomic_b);
                        end
                    end else begin
                        skip_done <= True;
                    end
                end else begin
                    in_fifo.deq;
                    $display("  [DECAP-PAY] opcode=0x%02h keep=0x%016h",
                             p.opcode, stream.keep);

                    Bit#(7) this_count = count_keep(stream.keep);
                    // First payload beat: the header path already subtracted
                    // the header-beat tail bytes from payload_left, so the
                    // accounting is uniform here (identical to the old
                    // p.length-based form when the tail is zero - which is
                    // every encap-generated frame).
                    Bit#(32) new_left = (zeroExtend(this_count) >= payload_left) ?
                                        0 : payload_left - zeroExtend(this_count);
                    // Terminate on the frame's own last flag as well as on the
                    // byte count. A frame whose declared UDP length over-counts
                    // the payload - a UD packet, whose 8-byte DETH the decap
                    // cannot know about without QP context - would otherwise
                    // leave the parser waiting for bytes that never arrive, and
                    // the next frame's header beat would be consumed as this
                    // packet's payload (silent corruption + a stuck parser).
                    Bool is_last_beat = (new_left == 0) || (stream.last == 1);

                    // iCRC check on the last beat: the last 4 valid bytes are
                    // the iCRC; the CRC covers the rest of the UDP payload.
                    Bit#(1) icrc_ok = 1;
                    if (is_last_beat) begin
                        // Initialised so the variable is assigned on every path
                        // (bsc P0042). The <4-byte case cannot verify anything:
                        // a well-formed final beat always carries the 4 iCRC
                        // bytes plus 0..3 pad bytes, so fewer than 4 valid
                        // bytes means the frame is truncated and carries no
                        // complete iCRC - fail it rather than pass vacuously.
                        Bit#(32) crc_check = crc_accum;
                        if (this_count >= 4) begin
                            Bit#(7) icrc_start = this_count - 4;
                            Bit#(32) icrc_shift = zeroExtend(icrc_start);
                            Bit#(64) icrc_mask = (64'h000000000000000F) <<
                                                 icrc_shift;
                            Bit#(64) crc_keep = stream.keep & ~icrc_mask;
                            crc_check = crc32c_beat(stream.data, crc_keep,
                                                    crc_accum);
                            Bit#(32) sh = 32'd480 -
                                          8 * zeroExtend(icrc_start);
                            Bit#(32) icrc_recv =
                                truncate(stream.data >> sh);
                            icrc_ok = (crc32c_finalize(crc_check) == icrc_recv)
                                      ? 1 : 0;
                        end else begin
                            icrc_ok = 0;
                        end
                        crc_accum <= 32'hFFFFFFFF;   // reset for next packet
                    end else begin
                        crc_accum <= crc32c_beat(stream.data, stream.keep,
                                                 crc_accum);
                    end

                    // The host must not receive the pad bytes or the iCRC.
                    // p.length counts payload + pad + 4 iCRC bytes, so the
                    // real payload length is p.length - 4 - padcnt; on the last
                    // beat those trailing bytes are masked out of byte_en.
                    Bit#(16) payload_len = p.length - fromInteger(4) -
                                           zeroExtend(p.padcnt);
                    Bit#(64) host_keep = stream.keep;
                    if (is_last_beat) begin
                        Bit#(7) tail = fromInteger(4) + zeroExtend(p.padcnt);
                        Bit#(7) tstart = (this_count >= tail) ?
                                         (this_count - tail) : 0;
                        host_keep = stream.keep &
                                    ~keep_range(tstart, tstart + tail);
                    end
                    ParsedPkt ph = p;
                    ph.length = payload_len;
                    DecapResult r = build_result(ph, stream.data, host_keep,
                                                 (first_payload_beat &&
                                                  rx_hdr_tail == 0) ? 1 : 0,
                                                 is_last_beat ? 1 : 0,
                                                 icrc_ok);
                    // A deferred atomic request emits its result here, on the
                    // frame's iCRC beat, with the iCRC verdict computed above
                    // (the operands were captured at the skip beat). The
                    // packet itself carries no payload: report length 0 so
                    // the host never sees the iCRC beat as data.
                    Bool is_atomic_req = (p.opcode == `OPCODE_COMPARE_SWAP ||
                                          p.opcode == `OPCODE_FETCH_ADD);
                    if (is_atomic_req) begin
                        r.length = 0;
                    end
                    if (is_last_beat) begin
                        $display("  [DECAP-ICRC] opcode=0x%02h %s",
                                 p.opcode, (icrc_ok == 1) ? "OK" : "FAIL");
                        if (icrc_ok == 1) icrc_ok_cnt  <= icrc_ok_cnt  + 1;
                        else              icrc_bad_cnt <= icrc_bad_cnt + 1;
                    end
                    out_fifo.enq(r);

                    // Per-PACKET counters (were per-beat: a multi-beat packet
                    // counted once per beat and multiplied the byte count by
                    // the beat count). Bytes = the payload bytes actually
                    // carried by this beat (host_keep masks pad + iCRC).
                    if (is_last_beat)
                        rx_packets <= rx_packets + 1;
                    rx_bytes   <= rx_bytes + (is_atomic_req ? 0 :
                        zeroExtend(pack(count_keep(host_keep))));

                    payload_left <= new_left;
                    first_payload_beat <= is_last_beat ? True : False;

                    if (is_last_beat) begin
                        parsing <= False;
                        skip_done <= False;
                    end
                end
            end else begin
                // Orphaned beat (no active parse and not a header): drop it so
                // the decap never stalls (e.g. the iCRC beat after an atomic
                // request, which was emitted at the skip beat).
                in_fifo.deq;
            end
        end
    endrule

    // The CNP is also reported to the top level through DecapResult.is_cnp, so
    // this per-engine CNP queue is a legacy side-channel that nothing drains.
    // Without this rule the depth-1 cnp_fifo stays full after the first CNP and
    // its notFull implicit condition - conjoined into decap_ingest's guard by
    // the branch that enqueues it - disables the entire RX decap engine.
    rule decap_cnp_drain if (cnp_fifo.notEmpty);
        cnp_fifo.deq;
    endrule

    // -----------------------------------------------------------------------
    // Interface
    // -----------------------------------------------------------------------

    method Action receive_packet(MACDataStream stream);
        in_fifo.enq(stream);
    endmethod

    method ActionValue#(DecapResult) get_result;
        let r = out_fifo.first;
        out_fifo.deq;
        return r;
    endmethod

    method Bit#(32) get_icrc_ok  = icrc_ok_cnt;
    method Bit#(32) get_icrc_bad = icrc_bad_cnt;

    method Bool result_available = out_fifo.notEmpty;

    method Action set_local_mac(Bit#(48) mac);
        local_mac <= mac;
    endmethod

    method Action set_local_ip(Bit#(32) ip);
        local_ip <= ip;
    endmethod

    method Action set_qp_transport(Bit#(8) qp_num, TransportMode mode);
        qp_transport[qp_num[5:0]] <= mode;
    endmethod

    method ActionValue#(CNPPacket) get_cnp;
        let cnp = cnp_fifo.first;
        cnp_fifo.deq;
        return cnp;
    endmethod

    method Bool cnp_available = cnp_fifo.notEmpty;

endmodule

endpackage
