// ============================================================================
// 100G RoCEv2 NIC - CRC Computation Module
// ============================================================================
// Implements CRC32 (Ethernet FCS) and CRC32c (RoCEv2 iCRC).
// Provides byte-at-a-time computation for streaming data.

`include "RoCEv2NICConfig.bh"
package CRC32Engine;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import GetPut :: *;

// ============================================================================
// CRC32 (Ethernet FCS) - Polynomial 0x04C11DB7
// ============================================================================

// CRC32 lookup table (256 entries, 32-bit each)
// Generated from polynomial 0x04C11DB7 (Ethernet standard)
function Bit#(32) crc32_table_entry(Integer idx);
    Bit#(32) crc = fromInteger(idx);
    for (Integer i = 0; i < 8; i = i + 1) begin
        if (crc[0] == 1)
            crc = (crc >> 1) ^ 32'hEDB88320;  // Reversed polynomial
        else
            crc = crc >> 1;
    end
    return crc;
endfunction

// Compute CRC32 for a single byte
function Bit#(32) crc32_byte(Bit#(8) data, Bit#(32) crc);
    // Reflected CRC byte update: the table is indexed by the low byte of the
    // running state XORed with the data byte. Indexing by `data` alone (the
    // previous form) drops the state contribution and makes the result depend
    // only on the last 4 bytes - not a CRC at all.
    Bit#(8) sel = crc[7:0] ^ data;
    Integer idx = 0;
    for (Integer b = 0; b < 8; b = b + 1) begin
        if (sel[b] == 1) idx = idx + (2 ** b);
    end
    Bit#(32) table_entry = crc32_table_entry(idx);
    return (crc >> 8) ^ table_entry;
endfunction

// Compute CRC32 for 64 bytes (one beat)
// Frame byte order is MSB-first: byte 0 is at bits [511:504], byte 63 at [7:0].
// CRC processes bytes in transmission order (byte 0 first). Uses an explicit
// bit slice (not a shift) because `data >> fromInteger(...)` resolves to a
// dynamic shift with an ambiguous width in BSV and produced wrong results.
function Bit#(32) crc32_beat(Bit#(512) data, Bit#(64) keep, Bit#(32) crc);
    Bit#(32) c = crc;
    for (Integer i = 0; i < 64; i = i + 1) begin
        if (keep[i] == 1) begin
            Bit#(8) byte_val = data[511 - 8 * i : 504 - 8 * i];
            c = crc32_byte(byte_val, c);
        end
    end
    return c;
endfunction

// Finalize CRC32 (XOR with 0xFFFFFFFF)
function Bit#(32) crc32_finalize(Bit#(32) crc);
    return crc ^ 32'hFFFFFFFF;
endfunction

// ============================================================================
// CRC32c (RoCEv2 iCRC) - Polynomial 0x1EDC6F41
// ============================================================================

// CRC32c lookup table (256 entries, 32-bit each)
// Generated from polynomial 0x1EDC6F41 (Castagnoli)
function Bit#(32) crc32c_table_entry(Integer idx);
    Bit#(32) crc = fromInteger(idx);
    for (Integer i = 0; i < 8; i = i + 1) begin
        if (crc[0] == 1)
            crc = (crc >> 1) ^ 32'h82F63B78;  // Reversed polynomial for CRC32c
        else
            crc = crc >> 1;
    end
    return crc;
endfunction

// Compute CRC32c for a single byte
function Bit#(32) crc32c_byte(Bit#(8) data, Bit#(32) crc);
    // Reflected CRC byte update: the table is indexed by the low byte of the
    // running state XORed with the data byte. Indexing by `data` alone (the
    // previous form) drops the state contribution and makes the result depend
    // only on the last 4 bytes - not a CRC at all.
    Bit#(8) sel = crc[7:0] ^ data;
    Integer idx = 0;
    for (Integer b = 0; b < 8; b = b + 1) begin
        if (sel[b] == 1) idx = idx + (2 ** b);
    end
    Bit#(32) table_entry = crc32c_table_entry(idx);
    return (crc >> 8) ^ table_entry;
endfunction

// Compute CRC32c for 64 bytes (one beat)
// Frame byte order is MSB-first (byte 0 at bits [511:504]). Explicit bit slice
// (see crc32_beat for why a shift was avoided).
function Bit#(32) crc32c_beat(Bit#(512) data, Bit#(64) keep, Bit#(32) crc);
    Bit#(32) c = crc;
    for (Integer i = 0; i < 64; i = i + 1) begin
        if (keep[i] == 1) begin
            Bit#(8) byte_val = data[511 - 8 * i : 504 - 8 * i];
            c = crc32c_byte(byte_val, c);
        end
    end
    return c;
endfunction

// Finalize CRC32c (XOR with 0xFFFFFFFF)
function Bit#(32) crc32c_finalize(Bit#(32) crc);
    return crc ^ 32'hFFFFFFFF;
endfunction

endpackage
