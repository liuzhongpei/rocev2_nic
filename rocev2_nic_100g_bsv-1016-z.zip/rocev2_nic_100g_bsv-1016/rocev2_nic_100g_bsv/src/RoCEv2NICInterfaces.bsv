// ============================================================================
// 100G RoCEv2 NIC - Common Interfaces and Type Definitions
// ============================================================================
// 64 Queue Pairs, DCQCN congestion control, ESUN link layer with
// fragmentation and Link-Level Retransmission (LLR).
// 512-bit data path at 156.25 MHz for 100G line rate.

`include "RoCEv2NICConfig.bh"
package RoCEv2NICInterfaces;

import Vector :: *;

// ============================================================================
// Enumerated Types
// ============================================================================

// Transport Mode
typedef enum {
    Transport_RC,   // Reliable Connection
    Transport_UD    // Unreliable Datagram
} TransportMode deriving (Bits, Eq, FShow);

// QP State Machine (InfiniBand)
typedef enum {
    QPState_RESET,
    QPState_INIT,
    QPState_RTR,
    QPState_RTS,
    QPState_SQD,
    QPState_SQE,
    QPState_ERROR
} QPState deriving (Bits, Eq, FShow);

// DCQCN State Machine
typedef enum {
    DCQCN_STATE_INCREASE,   // Additive Increase
    DCQCN_STATE_DECREASE,   // Multiplicative Decrease
    DCQCN_STATE_RECOVER     // Recovery after congestion
} DCQCNState deriving (Bits, Eq, FShow);

// Retry State Machine
typedef enum {
    RETRY_IDLE,
    RETRY_WAIT_ACK,
    RETRY_TIMER,
    RETRY_RETRANSMIT,
    RETRY_ERROR
} RetryState deriving (Bits, Eq, FShow);

// ESUN Fragment Type
typedef enum {
    ESUN_FRAG_FIRST,    // First fragment of a message
    ESUN_FRAG_MIDDLE,   // Middle fragment
    ESUN_FRAG_LAST,     // Last fragment
    ESUN_FRAG_SOLO,     // Single-fragment message (both first and last)
    ESUN_FRAG_CTRL      // LLR ACK/NACK control frame (on-wire, E15)
} ESUNFragType deriving (Bits, Eq, FShow);

// ESUN LLR State
typedef enum {
    ESUN_LLR_IDLE,          // No retransmission pending
    ESUN_LLR_WAIT_ACK,      // Waiting for LLR ACK
    ESUN_LLR_RETRANSMIT,    // Retransmitting
    ESUN_LLR_TIMEOUT        // Timeout, give up
} ESUNLLRState deriving (Bits, Eq, FShow);

// ECN Codepoints
typedef enum {
    ECN_NOT_ECT = 2'b00,    // Not ECN-Capable Transport
    ECN_ECT1    = 2'b01,    // ECN Capable Transport (ECT1)
    ECN_ECT0    = 2'b10,    // ECN Capable Transport (ECT0)
    ECN_CE      = 2'b11     // Congestion Experienced
} ECNCodepoint deriving (Bits, Eq, FShow);

// Completion Status Codes
typedef enum {
    CQE_SUCCESS         = 0,
    CQE_LOC_LEN_ERR     = 1,
    CQE_LOC_QP_OP_ERR   = 2,
    CQE_LOC_PROT_ERR    = 4,
    CQE_WR_FLUSH_ERR    = 5,
    CQE_REM_ACCESS_ERR  = 10,
    CQE_REM_OP_ERR      = 11,
    CQE_RETRY_EXC_ERR   = 12,
    CQE_RNR_RETRY_EXC   = 13
} CQEStatus deriving (Bits, Eq, FShow);

// ============================================================================
// Packet Header Structures
// ============================================================================

// Ethernet Header (14 bytes)
typedef struct {
    Bit#(48) dst_mac;
    Bit#(48) src_mac;
    Bit#(16) eth_type;           // 0x0800 for IPv4
} EthernetHeader deriving (Bits, Eq, FShow);

// IPv4 Header (20 bytes)
typedef struct {
    Bit#(8)  version_ihl;        // 0x45
    Bit#(8)  dscp_ecn;           // DSCP (6 bits) + ECN (2 bits)
    Bit#(16) total_length;
    Bit#(16) identification;
    Bit#(16) flags_fragment;
    Bit#(8)  ttl;
    Bit#(8)  protocol;           // 17 for UDP
    Bit#(16) header_checksum;
    Bit#(32) src_ip;
    Bit#(32) dst_ip;
} IPv4Header deriving (Bits, Eq, FShow);

// UDP Header (8 bytes)
typedef struct {
    Bit#(16) src_port;
    Bit#(16) dst_port;           // 4791 for RoCEv2
    Bit#(16) length;
    Bit#(16) checksum;          // 0 for RoCEv2
} UDPHeader deriving (Bits, Eq, FShow);

// BTH - Base Transport Header (12 bytes)
typedef struct {
    Bit#(8)  opcode;
    Bit#(4)  pad_count;
    Bit#(1)  se;                // Solicited Event
    Bit#(1)  mig_req;
    Bit#(2)  reserved1;
    Bit#(8)  transport_version;
    Bit#(16) pkey;
    Bit#(2)  reserved2;
    Bit#(1)  b;                 // Broadcast flag
    Bit#(1)  f;                 // First packet flag
    Bit#(24) psn;               // Packet Sequence Number
    Bit#(24) qp;                // Queue Pair number
} BTH deriving (Bits, Eq, FShow);

// REH - RDMA Extended Transport Header (16 bytes)
typedef struct {
    Bit#(64) va;                // Virtual Address
    Bit#(32) r_key;             // Remote Key
    Bit#(32) dma_len;           // DMA Length
} REH deriving (Bits, Eq, FShow);

// DETH - Datagram Extended Transport Header (8 bytes, for UD only)
typedef struct {
    Bit#(32) qkey;              // Queue Key
    Bit#(24) src_qpn;           // Source QP Number
    Bit#(8)  reserved;
} DETHHeader deriving (Bits, Eq, FShow);

// AETH - Ack Extended Transport Header (4 bytes, for RC ACKs)
typedef struct {
    Bit#(8)  syndrome;          // 0x00=ACK, 0x01-0x1F=NACK, 0x20+=RNR
    Bit#(24) msn;               // Message Sequence Number
} AETH deriving (Bits, Eq, FShow);

// CNP (Congestion Notification Packet) Header
typedef struct {
    Bit#(8)  qp_num;
    Bit#(24) psn;
    Bit#(16) qdepth;
    Bit#(8)  prio;
    Bit#(8)  reserved;
} CNPPacket deriving (Bits, Eq, FShow);

// ============================================================================
// QP Context Structure
// ============================================================================

typedef struct {
    // QP Identification
    Bit#(8)  qp_num;
    TransportMode transport;
    QPState  state;

    // Send Queue
    Bit#(64) send_queue_base;
    Bit#(32) send_queue_size;
    Bit#(32) send_head;
    Bit#(32) send_tail;
    Bit#(32) send_cons;

    // Receive Queue
    Bit#(64) recv_queue_base;
    Bit#(32) recv_queue_size;
    Bit#(32) recv_head;
    Bit#(32) recv_tail;
    Bit#(32) recv_cons;

    // Completion Queue
    Bit#(8)  send_cq;
    Bit#(8)  recv_cq;

    // PSN Tracking (for RC)
    Bit#(24) send_psn;
    Bit#(24) recv_psn;
    Bit#(24) expected_psn;     // Expected PSN for RC RX validation
    Bit#(24) last_acked_psn;   // Last acknowledged PSN for RC TX retransmission
    Bit#(24) min_psn;
    Bit#(24) max_psn;

    // MTU
    Bit#(16) path_mtu;
    Bit#(16) max_msg_sz;

    // Remote Addressing
    Bit#(48) remote_mac;
    Bit#(32) remote_ip;
    Bit#(32) remote_qpn;
    Bit#(32) r_key;
    Bit#(64) virtual_addr;

    // Local Addressing
    Bit#(48) local_mac;
    Bit#(32) qkey;

    // DCQCN Parameters
    Bit#(32) dcqcn_rate;
    Bit#(8)  dcqcn_alpha;
    Bit#(8)  dcqcn_beta;

    // Retry Parameters
    Bit#(8)  retry_count;
    Bit#(8)  rnr_retry;
    Bit#(16) timeout;
    Bit#(32) rto_value;        // DCQCN-aware retransmission timeout

    // Flags
    Bit#(1)  ack_enabled;
    Bit#(1)  dcqcn_enabled;
    Bit#(1)  ecn_enabled;
    Bit#(1)  is_initiator;
    Bit#(4)  sl;
    Bit#(8)  reserved;
} QPContext deriving (Bits, Eq, FShow);

// Fast-access remote addressing snapshot used by the TX path
typedef struct {
    Bit#(48) remote_mac;
    Bit#(32) remote_ip;
    Bit#(32) remote_qpn;
    Bit#(32) r_key;
    Bit#(64) virtual_addr;
} QPRemoteAddr deriving (Bits, Eq, FShow);

// ============================================================================
// Work Queue Element (WQE) Structures
// ============================================================================

typedef struct {
    Bit#(64) wr_id;
    Bit#(32) num_sge;
    Bit#(32) flags;
    Bit#(8)  opcode;
    Bit#(8)  qp_num;
    Bit#(32) length;
    Bit#(64) next_wr;
    Bit#(32) imm_data;
    Bit#(64) remote_addr;
    Bit#(32) r_key;
} SendQueueEntry deriving (Bits, Eq, FShow);

typedef struct {
    Bit#(64) wr_id;
    Bit#(32) num_sge;
    Bit#(32) flags;
    Bit#(64) next_wr;
} ReceiveQueueEntry deriving (Bits, Eq, FShow);

typedef struct {
    Bit#(64) addr;
    Bit#(32) length;
    Bit#(32) lkey;
} ScatterGatherElement deriving (Bits, Eq, FShow);

// Completion Queue Entry (CQE)
typedef struct {
    Bit#(64) wr_id;
    Bit#(32) status;
    Bit#(32) opcode;
    Bit#(32) length;
    Bit#(8)  qp_num;
    Bit#(8)  src_qp;
    Bit#(16) sl;
    Bit#(8)  is_send;
    Bit#(8)  reserved;
} CompletionQueueEntry deriving (Bits, Eq, FShow);

// ============================================================================
// DMA Interface Structures (512-bit AXI4-Stream)
// ============================================================================

typedef struct {
    Bit#(8)  qp_num;
    Bit#(2)  req_type;           // 0=Read, 1=Write, 2=Atomic
    Bit#(1)  is_doorbell;
    Bit#(5)  reserved;
    Bit#(64) addr;
    Bit#(32) length;
    Bit#(32) lkey;
    Bit#(64) wr_id;
} DMARequest deriving (Bits, Eq, FShow);

typedef struct {
    Bit#(8)  qp_num;
    Bit#(1)  success;
    Bit#(1)  is_read;
    Bit#(6)  reserved;
    Bit#(64) addr;
    Bit#(32) length;
    Bit#(64) wr_id;
    Bit#(`DATA_WIDTH) data;
    Bit#(`DATA_BYTES) byte_en;
} DMAResponse deriving (Bits, Eq, FShow);

typedef struct {
    Bit#(`DATA_WIDTH) data;
    Bit#(`DATA_BYTES) keep;
    Bit#(1) valid;
    Bit#(1) ready;
    Bit#(1) first;
    Bit#(1) last;
    Bit#(8) qp_num;
    Bit#(4) dest;
    Bit#(4) reserved;
} DMADataStream deriving (Bits, Eq, FShow);

// Doorbell entry: carries both the QP number and the ring value.
// The QP number is passed explicitly (not encoded in the value).
typedef struct {
    Bit#(8)  qp_num;
    Bit#(32) value;
} DoorbellEntry deriving (Bits, Eq, FShow);

// RC retry entry: the packet descriptor plus the location of its payload in
// the internal URAM retransmission cache (cache_ptr = first beat, cache_beats
// = beat count), so the payload can be replayed on RTO retransmission.
typedef struct {
    EncapRequest req;
    Bit#(10) cache_ptr;
    Bit#(9)  cache_beats;
} RetryEntry deriving (Bits, Eq, FShow);

// ============================================================================
// MAC Interface Structures (100G, 512-bit)
// ============================================================================

typedef struct {
    Bit#(`DATA_WIDTH) data;
    Bit#(`DATA_BYTES) keep;
    Bit#(1) valid;
    Bit#(1) ready;
    Bit#(1) first;
    Bit#(1) last;
    Bit#(2) error;
} MACDataStream deriving (Bits, Eq, FShow);

// ============================================================================
// ESUN Link Layer Structures
// ============================================================================

// ESUN Fragment Header (8 bytes)
typedef struct {
    Bit#(16) frag_id;            // Fragment identification number
    Bit#(3)  frag_type;          // ESUNFragType encoding
    Bit#(5)  frag_index;         // Fragment index within message
    Bit#(8)  total_frags;       // Total fragments in message
    Bit#(16) payload_length;    // Payload length in this fragment
    Bit#(8)  llr_seq;            // LLR sequence number
    Bit#(1)  llr_ack_req;       // LLR ACK request flag
    Bit#(7)  reserved;
} ESUNFragHeader deriving (Bits, Eq, FShow);

// ESUN Link Layer Frame (data + fragment header)
typedef struct {
    ESUNFragHeader frag_hdr;
    Bit#(`DATA_WIDTH) data;
    Bit#(`DATA_BYTES) keep;
    Bit#(1) first;
    Bit#(1) last;
    Bit#(8) qp_num;   // TX only: lets an LLR drop be reported as a QP-scoped CQE
} ESUNFrame deriving (Bits, Eq, FShow);

// ESUN LLR ACK/NACK
typedef struct {
    Bit#(16) frag_id;
    Bit#(8)  ack_seq;            // Highest successfully received sequence
    Bit#(1)  is_nack;           // NACK if set
    Bit#(7)  reserved;
} ESUNLLRAck deriving (Bits, Eq, FShow);

// ESUN retransmission request
typedef struct {
    Bit#(16) frag_id;
    Bit#(8)  retry_seq;
    Bit#(8)  retry_count;
} ESUNRetryReq deriving (Bits, Eq, FShow);

// ESUN Statistics
typedef struct {
    Bit#(64) tx_frames;
    Bit#(64) tx_bytes;
    Bit#(64) tx_fragments;
    Bit#(64) rx_frames;
    Bit#(64) rx_bytes;
    Bit#(64) rx_fragments;
    Bit#(64) llr_retransmits;
    Bit#(64) llr_timeouts;
    Bit#(64) frag_reassembled;
    Bit#(64) frag_errors;
    Bit#(64) llr_retry_dropped;   // messages given up after ESUN_LLR_RETRY_LIMIT
} ESUNStatistics deriving (Bits, Eq, FShow);

// ============================================================================
// Internal Engine Structures
// ============================================================================

// Encapsulation request (TX path) - packet descriptor only.
// Payload beats are supplied separately via EncapEngineIfc.enq_payload.
typedef struct {
    Bit#(8)  qp_num;
    Bit#(8)  opcode;
    Bit#(1)  is_first;
    Bit#(1)  is_last;
    Bit#(1)  is_imm;
    Bit#(1)  is_rdma;
    Bit#(1)  is_ack;              // 1 for RC ACK packets
    Bit#(3)  reserved1;
    Bit#(1)  transport;           // TransportMode: 0=RC, 1=UD
    Bit#(7)  reserved2a;
    Bit#(32) length;              // Payload length in bytes (excludes headers)
    Bit#(24) psn;
    Bit#(8)  ack_syndrome;        // AETH syndrome: 0x00=ACK, 0x01-0x1F=NACK
    Bit#(32) remote_qpn;
    Bit#(64) remote_addr;
    Bit#(32) r_key;
    Bit#(32) imm_data;
    Bit#(48) remote_mac;
    Bit#(32) dst_ip;              // Remote IP address
    Bit#(32) qkey;                // DETH QKey (UD TX; set by tx_pump_payload)
} EncapRequest deriving (Bits, Eq, FShow);

// Decapsulation result (RX path)
typedef struct {
    Bit#(8)  qp_num;
    Bit#(8)  opcode;
    Bit#(1)  is_first;
    Bit#(1)  is_last;
    Bit#(1)  is_imm;
    Bit#(1)  is_rdma;
    Bit#(1)  is_error;
    Bit#(1)  is_cnp;
    Bit#(1)  i_crc_ok;           // iCRC32c check passed (RX)
    Bit#(1)  reserved1;
    Bit#(32) length;
    Bit#(24) psn;
    Bit#(8)  error_code;
    Bit#(32) src_qp;
    Bit#(32) qkey;              // QKey from DETH (UD only)
    Bit#(64) local_addr;
    Bit#(32) r_key;
    Bit#(32) imm_data;
    Bit#(48) src_mac;
    Bit#(32) src_ip;             // sender IP (for ACK/CNP replies)
    Bit#(2)  ecn;                // ECN codepoint of the received packet
    Bit#(32) dma_len;            // RETH dma_len (RDMA READ/WRITE length)
    Bit#(64) atomic_a;           // AtomicETH swap/addend (CMP_SWAP/FADD)
    Bit#(64) atomic_b;           // AtomicETH compare (CMP_SWAP)
    Bit#(8)  ack_syndrome;       // AETH syndrome (ACK frames): 0=ACK, else NAK
    Bit#(`DATA_WIDTH) data;
    Bit#(`DATA_BYTES) byte_en;
} DecapResult deriving (Bits, Eq, FShow);

// ACK request for RC transport
typedef struct {
    Bit#(8)  qp_num;
    Bit#(1)  is_nack;
    Bit#(1)  is_rnr;
    Bit#(6)  reserved;
    Bit#(24) ack_psn;
    Bit#(24) nack_psn;
    Bit#(8)  rnr_time;
} ACKRequest deriving (Bits, Eq, FShow);

// Retry request
typedef struct {
    Bit#(8)  qp_num;
    Bit#(8)  retry_opcode;
    Bit#(24) retry_psn;
    Bit#(32) retry_length;
    Bit#(`DATA_WIDTH) retry_data;
    Bit#(`DATA_BYTES) retry_byte_en;
} RetryRequest deriving (Bits, Eq, FShow);

// DCQCN rate update
typedef struct {
    Bit#(8)  qp_num;
    Bit#(32) rate;               // Rate in Mbps
} DCQCNRateUpdate deriving (Bits, Eq, FShow);

// DCQCN state register
typedef struct {
    Bit#(8)  qp_num;
    Bit#(32) current_rate;
    Bit#(32) target_rate;
    Bit#(16) cnp_count;
    Bit#(16) timer_count;
    Bit#(1)  congested;
    Bit#(2)  state;
    Bit#(5)  reserved;
} DCQCNStateReg deriving (Bits, Eq, FShow);

// ============================================================================
// Register Bus (AXI4-Lite compatible)
// ============================================================================

typedef struct {
    Bit#(32) addr;
    Bit#(32) data;
    Bit#(4)  strb;
    Bit#(2)  cmd;                // 0=Read, 1=Write
    Bit#(2)  reserved;
} RegisterRequest deriving (Bits, Eq, FShow);

typedef struct {
    Bit#(32) data;
    Bit#(2)  resp;               // 0=OKAY, 1=EXOKAY, 2=SLVERR, 3=DECERR
    Bit#(1)  valid;
    Bit#(7)  reserved;
} RegisterResponse deriving (Bits, Eq, FShow);

// ============================================================================
// Interface Definitions
// ============================================================================

// DMA Engine Interface
// Direction semantics:
//   data_stream / get_data_stream      : Host TX data -> NIC TX path (outbound)
//   rx_data_stream / get_rx_data_stream: NIC RX data -> Host (inbound)
interface DMAEngineIfc;
    method Action request(DMARequest req);
    method Action response(DMAResponse resp);
    method Action data_stream(DMADataStream stream);            // Host TX data in
    method ActionValue#(DMADataStream) get_data_stream;         // NIC TX path reads host TX data
    method ActionValue#(DMADataStream) get_wqe_stream;     // WQE descriptor fetch (tag 1)
    method ActionValue#(DMADataStream) get_atomic_stream;  // atomic operand read (tag 2)
    method ActionValue#(DMADataStream) get_read_stream;    // RDMA READ local read (tag 3)
    method Action rx_data_stream(DMADataStream stream);         // NIC RX data out
    method ActionValue#(DMADataStream) get_rx_data_stream;      // Host reads RX data
    method Action doorbell(Bit#(8) qp_num, Bit#(32) value);
    method ActionValue#(DoorbellEntry) get_doorbell;
    method Bool doorbell_pending;
    method Bool dma_read_pending;          // a read is latched and awaiting data
    method Bit#(64) get_last_read_addr;    // host address of the last DMA read
    method Bit#(32) get_last_read_len;     // length of the last DMA read
endinterface

// MAC Interface (100G)
interface MAC100GIfc;
    method Action tx_request(MACDataStream stream);
    method ActionValue#(MACDataStream) rx_response;
    method Action rx_inject(MACDataStream stream);  // For RX data injection (sim/test)
    method ActionValue#(MACDataStream) tx_snoop;    // Mirror of the TX stream (test)
    method Action set_mac_addr(Bit#(48) mac);
    method Bit#(48) get_mac_addr;
    method Action set_ip_addr(Bit#(32) ip);
    method Bit#(32) get_ip_addr;
endinterface

// QP Manager Interface
interface QPManagerIfc;
    method Action create_qp(Bit#(8) qp_num, QPContext ctx);
    method Action destroy_qp(Bit#(8) qp_num);
    method Action modify_qp(Bit#(8) qp_num, QPState state);
    // Which CQ a QP's completions belong in (from the QP context).
    method Bit#(8) cq_for_qp(Bit#(8) qp_num, Bool is_send);
    method ActionValue#(QPContext) get_qp(Bit#(8) qp_num);
    method Bit#(32) get_cq_drops;   // completions dropped on CQ overflow
    method ActionValue#(QPContext) get_next_ready_qp;
    method Action update_psn(Bit#(8) qp_num, Bit#(24) send_psn, Bit#(24) recv_psn);
    method Bit#(24) get_send_psn(Bit#(8) qp_num);
    method Bit#(24) get_recv_psn(Bit#(8) qp_num);
    method Bit#(24) get_expected_psn(Bit#(8) qp_num);
    method Action update_expected_psn(Bit#(8) qp_num, Bit#(24) psn);
    method Action update_acked_psn(Bit#(8) qp_num, Bit#(24) acked_psn);
    method Bit#(24) get_last_acked_psn(Bit#(8) qp_num);
    method QPState get_qp_state(Bit#(8) qp_num);
    method Bool is_qp_ready_to_send(Bit#(8) qp_num);
    method Action update_doorbell(Bit#(8) qp_num, Bit#(1) is_send, Bit#(32) value);
    method QPRemoteAddr get_remote(Bit#(8) qp_num);
    method Bit#(32) get_qkey(Bit#(8) qp_num);
    method ActionValue#(CompletionQueueEntry) get_cqe(Bit#(8) cq_num);
    method Action post_cqe(Bit#(8) cq_num, CompletionQueueEntry cqe);
endinterface

// DCQCN Interface
interface DCQCNIfc;
    method Action update_rate(DCQCNRateUpdate update);
    method ActionValue#(DCQCNStateReg) get_state(Bit#(8) qp_num);
    method Action receive_cnp(CNPPacket cnp);
    method Action generate_cnp(Bit#(8) qp_num, Bit#(24) psn, Bit#(16) qdepth);
    method Bool tx_cnp_available;                    // a CNP is ready to send
    method ActionValue#(CNPPacket) get_tx_cnp;
    method Action tick;
    method ActionValue#(Bit#(32)) get_rate(Bit#(8) qp_num);
    method ActionValue#(Bit#(16)) get_cnp_count(Bit#(8) qp_num);
    method Action mark_ecn(Bit#(8) qp_num, ECNCodepoint ecn);
    method ECNCodepoint get_ecn_marking;
    method Action enable_dcqcn(Bit#(8) qp_num);
    method Action disable_dcqcn(Bit#(8) qp_num);
    method Action set_parameters(Bit#(8) qp_num, Bit#(8) alpha, Bit#(8) beta);
    method Bit#(32) get_rto(Bit#(8) qp_num);
    method Action set_rto(Bit#(8) qp_num, Bit#(32) val);   // test/config RTO
    method Action trigger_fast_retransmit(Bit#(8) qp_num);
endinterface

// Encapsulation Engine Interface
interface EncapEngineIfc;
    method ActionValue#(Bool) get_frame_host;   // frame ownership flag (consume per last beat)
    method Bool encap_idle;                     // TRUE when no frame is in flight
    method Bit#(8) get_encap_dbg;               // TX FIFO occupancy flags (diagnostic)
    method Action request(EncapRequest req);
    method Action enq_payload(DMADataStream beat);   // Payload beat stream (TX)
    method ActionValue#(MACDataStream) get_packet;
    method Action set_local_mac(Bit#(48) mac);
    method Action set_local_ip(Bit#(32) ip);
    method Action set_ecn_enable(Bool enable);
endinterface

// Decapsulation Engine Interface
interface DecapEngineIfc;
    method Action receive_packet(MACDataStream stream);
    method ActionValue#(DecapResult) get_result;
    method Bool result_available;
    method Action set_local_mac(Bit#(48) mac);
    method Action set_local_ip(Bit#(32) ip);
    // Per-QP transport, pushed from the QP-create path. The decap needs it to
    // know the BTH extension-header size (a UD SEND carries an 8-byte DETH, an
    // RC SEND carries nothing) - without it neither p_len nor the iCRC domain
    // can be right for UD, because the two are indistinguishable on the wire.
    method Action set_qp_transport(Bit#(8) qp_num, TransportMode mode);
    // iCRC verdict counters: the RTL CRC checked against an external reference.
    method Bit#(32) get_icrc_ok;
    method Bit#(32) get_icrc_bad;
    method ActionValue#(CNPPacket) get_cnp;
    method Bool cnp_available;
endinterface

// ESUN Link Layer Interface
interface ESUNLinkLayerIfc;
    // TX path: RoCEv2 -> ESUN -> MAC
    method Action tx_frame(ESUNFrame frame);
    method ActionValue#(MACDataStream) tx_get_mac_stream;
    // RX path: MAC -> ESUN -> RoCEv2
    method Action rx_mac_stream(MACDataStream stream);
    method ActionValue#(ESUNFrame) rx_get_frame;
    // LLR control
    method Action llr_receive_ack(ESUNLLRAck ack);
    // Requested retransmission by ESUN seq (RC RTO expiry / NAK). Requested
    // retx bypasses the llr_enable gate: with LLR disabled the receiver
    // ignores sequence numbers, so a replay is harmless, and the RTO must
    // work regardless of the LLR ACK-feedback configuration.
    method Action llr_request_retx(Bit#(8) esun_seq);
    method ActionValue#(ESUNRetryReq) llr_get_retry;
    method Bool llr_retry_available;
    // Configuration
    method Action set_fragment_enable(Bool enable);
    method Action set_llr_enable(Bool enable);
    method Action set_llr_timeout(Bit#(16) cycles);
    method Bit#(32) get_llr_retry_count;
    method Bit#(32) get_llr_retry_dropped;
    method Bool get_llr_link_error;
    method Action clear_llr_link_error;
    method Action set_max_frag_size(Bit#(16) size);
    method Action set_llr_window(Bit#(8) window);
    method Bit#(8) get_llr_retx_base;   // oldest unacked seq (for testing)
    method Bit#(8) get_llr_tx_seq;      // E14: current LLR TX seq (for testing)
    method ESUNStatistics get_statistics;
endinterface

// Register Space Interface
interface RegisterSpaceIfc;
    method Action read(Bit#(32) addr);
    method Action write(Bit#(32) addr, Bit#(32) data, Bit#(4) strb);
    method ActionValue#(Bit#(32)) get_read_data;
    method Bool read_data_available;
endinterface

// Top-Level NIC Interface
interface RoCEv2NICIfc;
    // PCIe DMA Interface
    method Action dma_request(DMARequest req);
    method Bool dma_read_pending;
    method Action dma_response(DMAResponse resp);
    method Action dma_data_stream(DMADataStream stream);
    method ActionValue#(DMADataStream) dma_get_data_stream;
    method Action doorbell(Bit#(8) qp_num, Bit#(32) value);

    // 100G MAC Interface
    method ActionValue#(MACDataStream) mac_rx;
    method Action mac_rx_inject(MACDataStream stream);  // RX data injection
    method ActionValue#(MACDataStream) mac_tx_snoop;    // TX stream mirror (test)
    method Action set_mac_address(Bit#(48) mac);
    method Action set_ip_address(Bit#(32) ip);

    // QP Management
    method Action create_qp(Bit#(8) qp_num, QPContext ctx);
    method Action destroy_qp(Bit#(8) qp_num);
    method Action modify_qp(Bit#(8) qp_num, QPState state);
    method ActionValue#(QPContext) get_qp(Bit#(8) qp_num);
    method ActionValue#(CompletionQueueEntry) get_cqe(Bit#(8) cq_num);
    method Bit#(32) get_cq_drops;   // CQ overflow drops (aggregated)
    method Bit#(32) get_rq_count;   // posted-but-unconsumed RQEs

    // DCQCN Control
    method Action set_dcqcn_rate(Bit#(8) qp_num, Bit#(32) rate);
    method ActionValue#(Bit#(32)) get_dcqcn_rate(Bit#(8) qp_num);
    method ActionValue#(Bit#(16)) get_dcqcn_cnp_count(Bit#(8) qp_num);
    method Action enable_dcqcn(Bit#(8) qp_num);
    method Action disable_dcqcn(Bit#(8) qp_num);

    // ESUN Control
    method Action set_esun_fragment_enable(Bool enable);
    method Action set_esun_llr_enable(Bool enable);
    method Bit#(8) get_llr_retx_base;   // oldest unacked LLR seq (for testing)
    method Action set_llr_timeout(Bit#(16) cycles);
    method Bit#(32) get_llr_retry_count;
    method Bit#(32) get_llr_retry_dropped;
    method Bool get_llr_link_error;
    method Action clear_llr_link_error;
    method Action test_llr_nack(Bit#(8) ack_seq);   // inject an LLR NACK (test)

    // RDMA Operation Control
    method Action set_tx_rdma_op(Bit#(8) opcode, Bit#(64) remote_addr, Bit#(32) r_key);
    method Action set_wqe_sq_base(Bit#(8) qp_num, Bit#(64) addr);   // R10 host SQ base

    // Register Interface (AXI4-Lite)
    method Action reg_read(Bit#(32) addr);
    method Action reg_write(Bit#(32) addr, Bit#(32) data, Bit#(4) strb);
    method ActionValue#(Bit#(32)) reg_get_response;

    // Status
    method Bit#(32) get_status;
    method Action reset;
endinterface

endpackage
