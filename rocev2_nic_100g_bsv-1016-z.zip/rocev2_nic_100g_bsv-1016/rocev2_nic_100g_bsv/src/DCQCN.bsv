// ============================================================================
// 100G RoCEv2 NIC - DCQCN Congestion Control Module
// ============================================================================
// Data Center Quantized Congestion Notification (DCQCN).
// Per-QP state machines for Additive Increase / Multiplicative Decrease /
// Recovery. ECN marking and CNP generation/reception. 64 QP support.

`include "RoCEv2NICConfig.bh"
package DCQCN;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import RegFile :: *;
import GetPut :: *;
import RoCEv2NICInterfaces :: *;

// ============================================================================
// DCQCN Top Module - 64 QP Support
// ============================================================================

module mkDCQCN(DCQCNIfc);

    Integer num_qps = `NUM_QPS;

    // ========================================================================
    // Global DCQCN Parameters
    // ========================================================================

    Reg#(Bool)  global_enable  <- mkReg(True);
    Reg#(Bit#(16)) timer_period    <- mkReg(`DCQCN_TIMER_PERIOD);
    Reg#(Bit#(16)) timer_prescaler <- mkReg(100);
    Reg#(Bit#(16)) timer_counter   <- mkReg(0);

    // Rate adjustment defaults
    Reg#(Bit#(8))  global_alpha   <- mkReg(100);  // AI: 0.1% per step
    Reg#(Bit#(8))  global_beta    <- mkReg(50);   // MD: 50%
    Reg#(Bit#(16)) cnp_threshold  <- mkReg(100);

    // Rate limits
    Reg#(Bit#(32)) min_rate <- mkReg(100);      // 100 Mbps
    Reg#(Bit#(32)) max_rate <- mkReg(100000);   // 100 Gbps

    // ========================================================================
    // Per-QP DCQCN State
    // ========================================================================

    Vector#(`NUM_QPS, Reg#(DCQCNStateReg)) qp_dcqcn_state <-
        replicateM(mkReg(unpack(0)));
    Vector#(`NUM_QPS, Reg#(Bool)) qp_dcqcn_enable <-
        replicateM(mkReg(False));
    Vector#(`NUM_QPS, Reg#(Bool)) qp_ecn_enable <-
        replicateM(mkReg(True));

    // Rate registers per QP
    Vector#(`NUM_QPS, Reg#(Bit#(32))) current_rate <-
        replicateM(mkReg(10000));  // 10 Gbps initial
    Vector#(`NUM_QPS, Reg#(Bit#(32))) target_rate <-
        replicateM(mkReg(10000));
    Vector#(`NUM_QPS, Reg#(Bit#(32))) qp_min_rate <-
        replicateM(mkReg(100));
    Vector#(`NUM_QPS, Reg#(Bit#(32))) qp_max_rate <-
        replicateM(mkReg(100000));

    // CNP tracking per QP
    Vector#(`NUM_QPS, Reg#(Bit#(16))) cnp_count <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(16))) cnp_timer <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(32))) bytes_sent <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(32))) bytes_since_cnp <-
        replicateM(mkReg(0));

    // DCQCN state machine per QP
    Vector#(`NUM_QPS, Reg#(DCQCNState)) qp_state <-
        replicateM(mkReg(DCQCN_STATE_INCREASE));

    // Rate adjustment timers per QP
    Vector#(`NUM_QPS, Reg#(Bit#(16))) rate_timer <-
        replicateM(mkReg(0));
    Vector#(`NUM_QPS, Reg#(Bit#(8))) alpha_param <-
        replicateM(mkReg(100));
    Vector#(`NUM_QPS, Reg#(Bit#(8))) beta_param <-
        replicateM(mkReg(50));

    // RC retransmission timeout (DCQCN-aware)
    Vector#(`NUM_QPS, Reg#(Bit#(32))) rto_value <-
        replicateM(mkReg(4096));   // Base RTO in clock cycles
    Vector#(`NUM_QPS, Reg#(Bit#(32))) rto_timer <-
        replicateM(mkReg(0));     // Countdown timer for RTO
    Vector#(`NUM_QPS, Reg#(Bool)) fast_retransmit_req <-
        replicateM(mkReg(False));  // Fast retransmit request flag

    // ========================================================================
    // ECN Marking State
    // ========================================================================

    Reg#(ECNCodepoint) global_ecn <- mkReg(ECN_ECT0);
    Vector#(`NUM_QPS, Reg#(ECNCodepoint)) qp_ecn <-
        replicateM(mkReg(ECN_ECT0));
    Vector#(`NUM_QPS, Reg#(Bool)) qp_ecn_ce_recv <-
        replicateM(mkReg(False));
    Vector#(`NUM_QPS, Reg#(Bit#(16))) ecn_ce_count <-
        replicateM(mkReg(0));

    // ========================================================================
    // CNP Generation
    // ========================================================================

    Reg#(Bool)   cnp_gen_enable  <- mkReg(True);
    Reg#(Bit#(16)) cnp_gen_delay  <- mkReg(1000);
    Reg#(Bit#(16)) cnp_rate_limit <- mkReg(100);

    // CNP FIFO for receiving (from the wire via decap)
    FIFOF#(CNPPacket) cnp_rx_fifo <- mkFIFOF;
    // CNP FIFO for transmitting (CNPs we generate go out on the wire)
    FIFOF#(CNPPacket) cnp_tx_fifo <- mkFIFOF;

    // ========================================================================
    // DCQCN Timer Tick Rule
    // ========================================================================

    rule dcqcn_tick;
        // CNP TX rate window: decremented EVERY cycle, unconditionally.
        // It used to sit inside BOTH the qp_dcqcn_enable gate and the
        // timer_period prescaler branch, which (a) froze CNP generation
        // permanently for any QP with DCQCN disabled - generate_cnp is
        // deliberately NOT gated by that enable (ECN feedback must work
        // regardless of the CC algorithm state) - and (b) stretched the
        // window to cnp_gen_delay x timer_period (~1.56M cycles for the
        // default 1000) instead of the documented cnp_gen_delay cycles.
        for (Integer i = 0; i < num_qps; i = i + 1) begin
            if (cnp_timer[i] > 0) begin
                cnp_timer[i] <= cnp_timer[i] - 1;
            end
        end

        if (timer_counter >= timer_period) begin
            timer_counter <= 0;
            // Update per-QP DCQCN state
            for (Integer i = 0; i < num_qps; i = i + 1) begin
                if (qp_dcqcn_enable[i]) begin
                    case (qp_state[i])
                        DCQCN_STATE_INCREASE: begin
                            // Additive Increase: rate += alpha, capped by both
                            // the max rate and the configured target rate.
                            Bit#(32) cap = (qp_max_rate[i] < target_rate[i]) ?
                                           qp_max_rate[i] : target_rate[i];
                            Bit#(32) new_rate = current_rate[i] +
                                zeroExtend(alpha_param[i]);
                            if (new_rate > cap) begin
                                new_rate = cap;
                            end
                            current_rate[i] <= new_rate;

                            // Update state register
                            DCQCNStateReg st = qp_dcqcn_state[i];
                            st.current_rate = new_rate;
                            st.state = pack(DCQCN_STATE_INCREASE);
                            qp_dcqcn_state[i] <= st;
                        end

                        DCQCN_STATE_DECREASE: begin
                            // Multiplicative Decrease: rate *= (1 - beta/256)
                            Bit#(32) cur = current_rate[i];
                            Bit#(32) dec = (cur *
                                zeroExtend(beta_param[i])) >> 8;
                            Bit#(32) new_rate = cur - dec;
                            if (new_rate < qp_min_rate[i]) begin
                                new_rate = qp_min_rate[i];
                            end
                            current_rate[i] <= new_rate;

                            // Transition to recovery
                            qp_state[i] <= DCQCN_STATE_RECOVER;

                            // Increase RTO during congestion (conservative)
                            rto_value[i] <= 16384;  // 4x base RTO

                            DCQCNStateReg st = qp_dcqcn_state[i];
                            st.current_rate = new_rate;
                            st.state = pack(DCQCN_STATE_RECOVER);
                            qp_dcqcn_state[i] <= st;
                        end

                        DCQCN_STATE_RECOVER: begin
                            // Recovery: gradually increase rate
                            Bit#(32) tgt = target_rate[i];
                            Bit#(32) cur = current_rate[i];
                            if (cur < tgt) begin
                                Bit#(32) inc = (tgt - cur) >> 4;
                                cur = cur + inc;
                                if (cur > tgt) cur = tgt;
                                current_rate[i] <= cur;
                                // RTO in recovery: 2x base
                                rto_value[i] <= 8192;
                            end else begin
                                qp_state[i] <= DCQCN_STATE_INCREASE;
                                // RTO back to base
                                rto_value[i] <= 4096;
                            end

                            DCQCNStateReg st = qp_dcqcn_state[i];
                            st.current_rate = cur;
                            st.state = pack(DCQCN_STATE_RECOVER);
                            qp_dcqcn_state[i] <= st;
                        end
                    endcase

                    // RTO countdown timer
                    if (rto_timer[i] > 0) begin
                        rto_timer[i] <= rto_timer[i] - 1;
                    end

                    // Rate adjustment timer
                    rate_timer[i] <= rate_timer[i] + 1;
                end
            end
        end else begin
            timer_counter <= timer_counter + 1;
        end
    endrule

    // ========================================================================
    // CNP Reception Rule
    // ========================================================================

    // Urgency: this rule is scheduled AFTER dcqcn_tick so its DECREASE
    // state write wins when a CNP lands on a state-transition tick (both
    // rules read cycle-start state; the later writer must be the one whose
    // transition survives - losing a DECREASE means losing a congestion
    // event, the opposite priority of the tick's housekeeping).
    (* descending_urgency = "dcqcn_tick, process_cnp" *)
    rule process_cnp;
        if (cnp_rx_fifo.notEmpty) begin
            CNPPacket cnp = cnp_rx_fifo.first;
            Bit#(6) qp_idx = cnp.qp_num[`QP_BITS-1:0];

            // Increment CNP count for this QP
            cnp_count[qp_idx] <= cnp_count[qp_idx] + 1;

            // Trigger multiplicative decrease. NOTE: cnp_timer is the TX
            // side's CNP rate window (per generate_cnp) - a RECEIVED CNP
            // must not write it: the RX (reactor) and TX (reaction point)
            // roles used to share the timer, so a received CNP suppressed
            // this QP's own CNP generation as a side effect.
            if (qp_dcqcn_enable[qp_idx]) begin
                qp_state[qp_idx] <= DCQCN_STATE_DECREASE;
            end

            cnp_rx_fifo.deq;
        end
    endrule

    // ========================================================================
    // Interface Methods
    // ========================================================================

    method Action update_rate(DCQCNRateUpdate update);
        Bit#(6) qp_idx = update.qp_num[`QP_BITS-1:0];
        target_rate[qp_idx] <= update.rate;

        DCQCNStateReg st = qp_dcqcn_state[qp_idx];
        st.target_rate = update.rate;
        qp_dcqcn_state[qp_idx] <= st;
    endmethod

    method ActionValue#(DCQCNStateReg) get_state(Bit#(8) qp_num);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        return qp_dcqcn_state[qp_idx];
    endmethod

    method Action receive_cnp(CNPPacket cnp);
        cnp_rx_fifo.enq(cnp);
    endmethod

    method Action generate_cnp(Bit#(8) qp_num, Bit#(24) psn,
                                Bit#(16) qdepth);
        // CNP generation triggered by ECN-CE detection on RX: the CNP is
        // transmitted to the sender (via the TX path). RATE LIMITED: one
        // CNP per cnp_gen_delay cycles per QP (cnp_timer, decremented by
        // dcqcn_tick) - without this window a sustained-congestion flow
        // emits a CNP per data packet. A suppressed CNP is DROPPED here
        // (never backpressures the caller, whose rule guard would
        // otherwise be poisoned).
        Bit#(6) gen_idx = qp_num[`QP_BITS-1:0];
        if (cnp_gen_enable && cnp_timer[gen_idx] == 0) begin
            CNPPacket cnp;
            cnp.qp_num   = qp_num;
            cnp.psn      = psn;
            cnp.qdepth   = qdepth;
            cnp.prio = 0;
            cnp.reserved = 0;
            cnp_tx_fifo.enq(cnp);
            cnp_timer[gen_idx] <= cnp_gen_delay;
        end
    endmethod

    method Bool tx_cnp_available;
        return cnp_tx_fifo.notEmpty;
    endmethod

    method ActionValue#(CNPPacket) get_tx_cnp;
        let cnp = cnp_tx_fifo.first;
        cnp_tx_fifo.deq;
        return cnp;
    endmethod

    method Action tick;
        // External tick - normally handled by internal rule
    endmethod

    method ActionValue#(Bit#(32)) get_rate(Bit#(8) qp_num);
        // Return the configured target rate (the value set by update_rate),
        // so "set rate X" is directly observable. The actual instantaneous
        // rate is available via get_state().current_rate.
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        return target_rate[qp_idx];
    endmethod

    // CNPs received for this QP (test/diagnostic observability: proves an
    // incoming CNP frame actually reached the congestion controller).
    method ActionValue#(Bit#(16)) get_cnp_count(Bit#(8) qp_num);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        return cnp_count[qp_idx];
    endmethod

    method Action mark_ecn(Bit#(8) qp_num, ECNCodepoint ecn);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        qp_ecn[qp_idx] <= ecn;
        if (ecn == ECN_CE) begin
            qp_ecn_ce_recv[qp_idx] <= True;
            ecn_ce_count[qp_idx] <= ecn_ce_count[qp_idx] + 1;
        end
    endmethod

    method ECNCodepoint get_ecn_marking;
        return global_ecn;
    endmethod

    method Action enable_dcqcn(Bit#(8) qp_num);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        qp_dcqcn_enable[qp_idx] <= True;
    endmethod

    method Action disable_dcqcn(Bit#(8) qp_num);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        qp_dcqcn_enable[qp_idx] <= False;
    endmethod

    method Action set_parameters(Bit#(8) qp_num, Bit#(8) alpha,
                                  Bit#(8) beta);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        alpha_param[qp_idx] <= alpha;
        beta_param[qp_idx] <= beta;
    endmethod

    method Bit#(32) get_rto(Bit#(8) qp_num);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        return rto_value[qp_idx];
    endmethod

    method Action set_rto(Bit#(8) qp_num, Bit#(32) val);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        rto_value[qp_idx] <= val;
    endmethod

    method Action trigger_fast_retransmit(Bit#(8) qp_num);
        Bit#(6) qp_idx = qp_num[`QP_BITS-1:0];
        fast_retransmit_req[qp_idx] <= True;
    endmethod

endmodule

endpackage
