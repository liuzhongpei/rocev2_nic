// ============================================================================
// 100G RoCEv2 NIC - Testbench
// ============================================================================
package RoCEv2NICTestbench;

import FIFO :: *;
import FIFOF :: *;
import Vector :: *;
import ConfigReg :: *;
import GetPut :: *;
import RoCEv2NICInterfaces :: *;
import RoCEv2NIC :: *;

// Reflected CRC32c (Castagnoli, poly 0x82F63B78) table entry - must match
// src/CRC32Engine.bsv's crc32c_table_entry so the testbench generates exactly
// the iCRC the decap verifies.
function Bit#(32) tb_crc32c_table_entry(Integer idx);
    Bit#(32) crc = fromInteger(idx);
    for (Integer i = 0; i < 8; i = i + 1)
        crc = (crc[0] == 1) ? ((crc >> 1) ^ 32'h82F63B78) : (crc >> 1);
    return crc;
endfunction

// Byte update (same form as CRC32Engine::crc32c_byte)
function Bit#(32) tb_crc32c_byte(Bit#(8) d, Bit#(32) crc);
    // Index by (crc ^ d) - must match CRC32Engine::crc32c_byte exactly.
    Bit#(8) sel = crc[7:0] ^ d;
    Integer idx = 0;
    for (Integer b = 0; b < 8; b = b + 1)
        if (sel[b] == 1) idx = idx + (2 ** b);
    return (crc >> 8) ^ tb_crc32c_table_entry(idx);
endfunction

// CRC32c of the standard check string "123456789", finalized. The correct
// answer is 32'hE3069283; the test asserts it, which proves the table-driven
// byte update is the real algorithm (indexing the table by the data byte
// alone - the previous form - cannot produce it).
function Bit#(32) tb_crc32c_check_vector;
    Bit#(32) c = 32'hFFFFFFFF;
    c = tb_crc32c_byte(8'h31, c);   // "123456789"
    c = tb_crc32c_byte(8'h32, c);
    c = tb_crc32c_byte(8'h33, c);
    c = tb_crc32c_byte(8'h34, c);
    c = tb_crc32c_byte(8'h35, c);
    c = tb_crc32c_byte(8'h36, c);
    c = tb_crc32c_byte(8'h37, c);
    c = tb_crc32c_byte(8'h38, c);
    c = tb_crc32c_byte(8'h39, c);
    return c ^ 32'hFFFFFFFF;
endfunction

// CRC32c over the RoCEv2 BTH (bytes 42..53 of the header beat) + `nbytes`
// payload bytes (MSB-first frame order), finalized.
function Bit#(32) tb_calc_icrc(Bit#(512) hdr, Bit#(512) pl, Integer nbytes);
    Bit#(32) c = 32'hFFFFFFFF;
    for (Integer i = 0; i < 12; i = i + 1)
        c = tb_crc32c_byte(hdr[175 - 8 * i : 168 - 8 * i], c);
    for (Integer i = 0; i < nbytes; i = i + 1)
        c = tb_crc32c_byte(pl[511 - 8 * i : 504 - 8 * i], c);
    return c ^ 32'hFFFFFFFF;
endfunction

typedef enum {
    TEST_INIT,
    TEST_CRC_VEC,
    TEST_CREATE_QP,
    TEST_SET_ADDR,
    TEST_DOORBELL,
    TEST_SEND_DATA,
    TEST_CHECK_TX,
    TEST_TX_SNOOP0,
    TEST_TX_SNOOP1,
    TEST_LLR_NACK,
    TEST_LLR_CHECK,
    TEST_LLR_GET,
    TEST_RX_PACKET,
    TEST_CHECK_RX,
    TEST_RX_DATA,
    TEST_ICRC_RD,
    TEST_ICRC_CHK,
    TEST_LLR_ACK_WIRE,
    TEST_DCQCN,
    TEST_ESUN_FRAG,
    TEST_RDMA_WRITE,
    TEST_RDMA_WRITE_RX,
    TEST_RDMA_READ,
    TEST_RDMA_READ_RX,
    TEST_RDMA_READ_RESP,
    TEST_RDMA_READ_CHECK,
    TEST_RDMA_READ_GET,
    TEST_DMA_READ,
    TEST_DMA_REQ,
    TEST_DMA_RESP,
    TEST_DMA_CHECK,
    TEST_DMA_SNOOP,
    TEST_RTO_SET,
    TEST_RTO_SET2,
    TEST_RTO_DOORBELL,
    TEST_RTO_SEND,
    TEST_RTO_WAIT,
    TEST_RTO_GET,
    TEST_WQE_SET,
    TEST_WQE_DOORBELL,
    TEST_WQE_RESP1,
    TEST_WQE_RESP2,
    TEST_WQE_CHECK,
    TEST_WQE_GET,
    TEST_WQE_CQE,
    TEST_LLRWIN_EN,
    TEST_LLR_WIN_READ,
    TEST_LLR_WIN_READ1,
    TEST_LLR_WIN_GET,
    TEST_LLR_WIN_READ2,
    TEST_LLR_WIN_GETRETX0,
    TEST_LLR_WIN_SEND1,
    TEST_LLR_WIN_SEND1B,
    TEST_LLR_WIN_SEND2,
    TEST_LLR_WIN_SEND2B,
    TEST_LLRWIN_QUIET,
    TEST_LLRWIN_SEQREAD,
    TEST_LLRWIN_SEQGET,
    TEST_LLR_WIN_NACK,
    TEST_LLR_WIN_CHECK,
    TEST_LLR_WIN_GETRETX,
    TEST_LOOPBACK_PREP,
    TEST_LOOPBACK_PREP1,
    TEST_LOOPBACK_PREP2,
    TEST_LOOPBACK_PREP3,
    TEST_LOOPBACK_PREP4,
    TEST_LOOPBACK_DRAIN,
    TEST_LOOPBACK_SEND,
    TEST_LOOPBACK_SEND2,
    TEST_LOOPBACK_LOOP,
    TEST_LOOPBACK_WAIT,
    TEST_LOOPBACK_GET,
    TEST_ATOMIC_SEND1,
    TEST_ATOMIC_RESP1,
    TEST_ATOMIC_WB1,
    TEST_ATOMIC_SEND2,
    TEST_ATOMIC_RESP2,
    TEST_ATOMIC_WB2,
    TEST_ATOMIC_CHECK,
    TEST_ATOMIC_GET,
    TEST_ATOMIC_ICRC_OK_BASE,
    TEST_ATOMIC_ICRC_BASE_GET,
    TEST_ATOMIC_ICRC_BAD_BASE,
    TEST_ATOMIC_ICRC_BASE2_GET,
    TEST_ATOMIC_SEND3,
    TEST_ATOMIC_RESP3,
    TEST_ATOMIC_WB3,
    TEST_ATOMIC_OK_FINAL,
    TEST_ATOMIC_OK_FINAL_GET,
    TEST_ATOMIC_BAD_FINAL,
    TEST_ATOMIC_BAD_FINAL_GET,
    TEST_ATOMIC_VERDICT,
    TEST_AACK_OKRD,
    TEST_AACK_OKGET,
    TEST_AACK_BADRD,
    TEST_AACK_BADGET,
    TEST_AACK_SEND,
    TEST_AACK_DRAIN,
    TEST_AACK_OK2RD,
    TEST_AACK_OK2GET,
    TEST_AACK_BAD2RD,
    TEST_AACK_BAD2GET,
    TEST_AACK_VERDICT,
    TEST_DSEQ_CREATE,
    TEST_DSEQ_SEQRD,
    TEST_DSEQ_SEQGET,
    TEST_DSEQ_A,
    TEST_DSEQ_AW,
    TEST_DSEQ_B,
    TEST_DSEQ_BW,
    TEST_DSEQ_R1,
    TEST_DSEQ_R1W,
    TEST_DSEQ_R2,
    TEST_DSEQ_R2W,
    TEST_DSEQ_VERDICT,
    TEST_FA_BASE_RD,
    TEST_FA_BASE_GET,
    TEST_FA_RTO_SET,
    TEST_FA_DB_A,
    TEST_FA_PUSH_A,
    TEST_FA_WATCH,
    TEST_FA_RING,
    TEST_FA_RETX_RD,
    TEST_FA_RETX_GET,
    TEST_FA_VERDICT,
    TEST_FA_DRAIN,
    TEST_UD_CREATE,
    TEST_UD_DRAIN,
    TEST_UD_SEND,
    TEST_UD_SEND_DB,
    TEST_UD_SEND2,
    TEST_UD_LOOP,
    TEST_UD_WAIT,
    TEST_UD_GET,
    TEST_UD2_DRAIN,
    TEST_UD2_DB,
    TEST_UD2_DB2,
    TEST_UD2_SEND,
    TEST_UD2_LOOP,
    TEST_UD2_WAIT,
    TEST_UD2_GET,
    TEST_MB_PREP,
    TEST_MB_DB,
    TEST_MB_SEND1,
    TEST_MB_SEND2,
    TEST_MB_SEND3,
    TEST_MB_WAIT,
    TEST_MB_SNOOP,
    TEST_CNP_RATE0,
    TEST_CNP_CNT0,
    TEST_CNP_INJECT,
    TEST_CNP_WAIT,
    TEST_CNP_RATE1,
    TEST_CNP_CNT1,
    TEST_QP2_CREATE,
    TEST_QP2_DRAIN,
    TEST_QP2_DB,
    TEST_QP2_DB2,
    TEST_QP2_SEND,
    TEST_QP2_LOOP,
    TEST_QP2_WAIT,
    TEST_QP2_GET,
    TEST_BIG_LLR,
    TEST_BIG_DB,
    TEST_BIG_DB2,
    TEST_BIG_SEND,
    TEST_BIG_LOOP,
    TEST_BIG_VERDICT,
    TEST_PBIG_DB,
    TEST_PBIG_DB2,
    TEST_PBIG_SEND,
    TEST_PBIG_LOOP,
    TEST_PBIG_VERDICT,
    TEST_PPAD_DB,
    TEST_PPAD_DB2,
    TEST_PPAD_SEND,
    TEST_PPAD_LOOP,
    TEST_PPAD_VERDICT,
    TEST_DMAMB_DRAIN,
    TEST_DMAMB_DB,
    TEST_DMAMB_REQ,
    TEST_DMAMB_RESP,
    TEST_DMAMB_SNOOP,
    TEST_DMAMB_VERDICT,
    TEST_DB2_DB1,
    TEST_DB2_PUSH1,
    TEST_DB2_RING1,
    TEST_DB2_RING2,
    TEST_DB2_WAIT,
    TEST_DB2_PUSH2,
    TEST_DB2_WAIT2,
    TEST_DB2_PUSH3,
    TEST_DB2_SNOOP,
    TEST_DB2_VERDICT,
    TEST_MQP_LLR,
    TEST_MQP_DB0,
    TEST_MQP_DB0B,
    TEST_MQP_PUSH0,
    TEST_MQP_LOOP0,
    TEST_MQP_DB2,
    TEST_MQP_PUSH2,
    TEST_MQP_LOOP2,
    TEST_MQP_RD0,
    TEST_MQP_RD1,
    TEST_MQP_VERDICT,
    TEST_STATUS_CHECK,
    TEST_RR_SET,
    TEST_RR_BASE,
    TEST_RR_WQE,
    TEST_RR_REFUSE_DB,
    TEST_RR_REFUSE_WQE,
    TEST_RR_SCAN,
    TEST_RR_FAKE,
    TEST_RR_FAKE_PEND,
    TEST_RR_FAKE_RD,
    TEST_RR_FAKE_GET,
    TEST_RR_MEM,
    TEST_RR_WAIT,
    TEST_RR_GET,
    TEST_LLRTO_SET,
    TEST_LLRTO_CFG,
    TEST_LLRTO_BASE,
    TEST_LLRTO_TO0,
    TEST_LLRTO_PUSH,
    TEST_LLRTO_PUSHB,
    TEST_LLRTO_SND,
    TEST_LLRTO_PUSH2,
    TEST_LLRTO_PUSH3,
    TEST_LLRTO_WAIT1,
    TEST_LLRTO_TO1,
    TEST_LLRTO_TO1B,
    TEST_LLRTO_RT1,
    TEST_LLRTO_CAP1,
    TEST_LLRTO_WAIT2,
    TEST_LLRTO_TO2,
    TEST_LLRTO_TO2B,
    TEST_LLRTO_RT2,
    TEST_LLRTO_CAP2,
    TEST_LLRTO_VERDICT,
    TEST_DONE
} TestState deriving (Bits, Eq);

module mkRoCEv2NICTest(Empty);

    RoCEv2NICIfc nic <- mkRoCEv2NIC;

    Reg#(TestState) test_state <- mkReg(TEST_INIT);
    Reg#(Bit#(32)) cycle_count <- mkReg(0);
    Reg#(Bit#(32)) test_count   <- mkReg(0);
    Reg#(Bit#(32)) pass_count   <- mkReg(0);
    Reg#(Bit#(32)) fail_count   <- mkReg(0);
    Reg#(Bool) all_pass <- mkReg(True);

    // E14/E15 test staging
    Reg#(Bit#(8))  base_seq <- mkReg(0);    // LLR seq of the first window message
    Reg#(Bit#(32)) base_retx <- mkReg(0);   // llr_retransmits before the NACK
    Reg#(Bool) ud_deth_ok <- mkReg(False);  // UD DETH (qkey/src_qpn) verified on TX

    // Multi-beat TX staging: what the MAC TX snoop showed for the 192-byte
    // (3 beat) packet. Both are set by the scan rule and evaluated by the
    // scan check rule (single writer of test_state).
    Reg#(Bool) mb_hdr_ok <- mkReg(False);   // frag header with payload_length=192
    Reg#(Bool) mb_pl_ok  <- mkReg(False);   // 3rd payload beat (0xB2...) on the wire

    // CNP staging: the per-QP CNP counter before the injected CNP frame, so
    // the test can prove the frame actually reached the congestion controller.
    Reg#(Bit#(16)) cnp_cnt_before <- mkReg(0);

    // >2048B TX (ESUN fragmentation): 33 full 64B beats = 2112 B, which crosses
    // one ESUN fragment boundary (max_frag_size 2048). The scan records what
    // the MAC TX snoop showed for the fragment headers.
    Reg#(Bit#(8)) big_idx        <- mkReg(0);
    Reg#(Bool)    big_first_ok   <- mkReg(False);  // FRAG_FIRST, total=2, plen=2048
    Reg#(Bool)    big_last_ok    <- mkReg(False);  // FRAG_LAST,  total=2, plen=64
    Reg#(Bool)    pbig_dbg_pending <- mkReg(False); // two-phase debug reg read

    // RX-side reassembly check: the 2112-byte packet is looped back and the
    // host must receive exactly 2112 payload bytes (pad/iCRC masked out, the
    // 8-byte DETH excluded, and every intermediate ESUN fragment header
    // stripped by the reassembly). Before the reassembly fix the fragment
    // headers were forwarded as payload, inflating the count by 8 bytes, and
    // the stream had no end-of-message flag.
    Reg#(Bit#(32)) big_bytes     <- mkReg(0);
    Reg#(Bool)    big_marker_ok  <- mkReg(False);  // first payload beat 0xB0000000

    // Multi-beat DMA READ (192 B = 3 beats): guards gen_byte_en, whose 7-bit
    // arithmetic used to produce an EMPTY byte-enable for the middle beat of
    // any read >= 128 bytes (silently dropping half the payload).
    Reg#(Bool) dma_mb_ok <- mkReg(False);
    // Per-beat response index (host model) and verified-marker count (snoop)
    // for the multi-beat DMA read test.
    Reg#(Bit#(2)) dmamb_resp_beat <- mkReg(0);
    Reg#(Bit#(2)) dmamb_data_ok   <- mkReg(0);

    // Doorbells rung while TX is busy: a 4-beat packet is streaming, and two
    // more doorbells are rung while the FSM is in STREAM. The old register +
    // flag channel let the second ring overwrite the first (one of the two
    // packets was silently lost); the FIFO queues both.
    Reg#(Bit#(3)) db2_idx  <- mkReg(0);
    Reg#(Bool)    db2_m1   <- mkReg(False);   // 4-beat packet's payload
    Reg#(Bool)    db2_m2   <- mkReg(False);   // second packet's payload
    Reg#(Bool)    db2_m3   <- mkReg(False);   // third  packet's payload

    // LLR timeout retransmit: a 4-beat message is sent with llr_ack_req and
    // deliberately never ACKed, so the (shortened) timer must expire and the
    // retransmit must replay the WHOLE message - the marker must appear on the
    // wire twice. The old window stored only the header and the last beat.
    Reg#(Bit#(4)) llrto_cnt   <- mkReg(0);
    Reg#(Bool)    wqe_wrid_ok <- mkReg(False);   // WQE wr_id found in CQ0
    Reg#(Bool)    llrdrp_ok   <- mkReg(False);   // LLR drop CQE seen

    // Multi-QP: QP0 and QP2 each send one packet, both are looped back and
    // ACKed. Guards the retry buffer / ACK-clearing path across QPs: neither
    // QP may trigger an RTO retransmission (rc_retransmits must not move).
    Reg#(Bool)    mqp_m0   <- mkReg(False);   // QP0 payload seen on the wire
    Reg#(Bool)    mqp_m2   <- mkReg(False);   // QP2 payload seen on the wire
    Reg#(Bit#(32)) mqp_base <- mkReg(0);      // rc_retransmits before the test
    Reg#(Bit#(32)) llrto_retx <- mkReg(0);
    Reg#(Bit#(32)) cnp_rate_before <- mkReg(0);
    Reg#(Bit#(32)) cnp_rate_after  <- mkReg(0);
    // READ REQ round trip: the responder must answer a header-only RETH
    // READ REQ with a READ RESPONSE (rdma_read_resps delta), and the TX FSM
    // must return to IDLE (a wedged encap would leave it stuck).
    Reg#(Bit#(32)) rr_base  <- mkReg(0);  // rdma_read_resps before the test

    // LLR give-up (timeout exhaustion) regression: with LLR enabled, a short
    // timeout and NO ACKs, the oldest message must consume its full retry
    // budget, then be given up exactly once; the timer must DISARM on the now
    // empty window (the pre-fix code re-armed it, producing a self-sustaining
    // timeout/give-up loop that ran retx_base past llr_tx_seq and killed TX).
    Reg#(Bit#(8))  llrto_base <- mkReg(0);   // retx_base before the test
    Reg#(Bit#(32)) llrto_to0  <- mkReg(0);   // llr_timeouts before
    Reg#(Bit#(32)) llrto_rt0  <- mkReg(0);   // llr_retransmits before
    Reg#(Bit#(32)) llrto_to1  <- mkReg(0);   // llr_timeouts after give-up
    Reg#(Bit#(32)) llrto_to2  <- mkReg(0);   // llr_timeouts after a 2nd wait
    Reg#(Bit#(32)) llrto_rt1  <- mkReg(0);   // llr_retransmits after give-up
    Reg#(Bit#(32)) llrto_rt2  <- mkReg(0);   // llr_retransmits after 2nd wait

    // Multi-beat RX injection staging: beats are injected one per cycle.
    Reg#(Vector#(4, MACDataStream)) inject_vec <- mkReg(replicate(unpack(0)));
    Reg#(Bit#(3)) inject_count <- mkReg(0);
    Reg#(Bit#(3)) inject_pos <- mkReg(0);

    rule cycle_counter;
        cycle_count <= cycle_count + 1;
    endrule

    // Rule-level guard: inject_count != 0 must be in the guard (not just the
    // body if), otherwise this rule fires as a no-op every cycle and
    // suppresses the lower-urgency do_rdma_read_rx (shared inject registers).
    rule inject_pump if (inject_count != 0);
        let ivec = inject_vec;
        nic.mac_rx_inject(ivec[inject_pos]);
        if (inject_pos + 1 >= inject_count) begin
            inject_count <= 0;
            inject_pos <= 0;
        end else begin
            inject_pos <= inject_pos + 1;
        end
    endrule

    // Test sequence - each state in its own rule to avoid scheduling conflicts
    rule do_init (test_state == TEST_INIT);
        $display("========================================");
        $display("100G RoCEv2 NIC - Functional Test Suite");
        $display("========================================");

        nic.reset;
        nic.set_mac_address(48'hAA_BB_CC_DD_EE_01);
        nic.set_ip_address(32'hC0A80101);
        nic.set_esun_fragment_enable(True);
        nic.set_esun_llr_enable(True);

        $display("\n[TEST] Initialization complete");
        $display("  MAC: AA:BB:CC:DD:EE:01, IP: 192.168.1.1");
        $display("  ESUN: Fragmentation + LLR enabled");
        test_state <= TEST_CRC_VEC;
    endrule

    // Sanity check on the CRC itself, before any packet exercises it.
    rule do_crc_vec (test_state == TEST_CRC_VEC);
        Bit#(32) got = tb_crc32c_check_vector;
        if (got == 32'hE3069283) begin
            $display("\n[TEST] CRC32c check vector: %08h (expected e3069283)", got);
            $display("  [PASS] CRC32c: standard check vector matches");
            pass_count <= pass_count + 1;
        end else begin
            $display("\n[TEST] CRC32c check vector: %08h (expected e3069283)", got);
            $display("  [FAIL] CRC32c: implementation is not the real algorithm");
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_CREATE_QP;
    endrule

    rule do_create_qp (test_state == TEST_CREATE_QP);
        // Create QP 0 (RC transport)
        QPContext ctx = unpack(0);
        ctx.qp_num       = 0;
        ctx.transport    = Transport_RC;
        ctx.state        = QPState_RTS;
        ctx.send_psn     = 0;
        ctx.recv_psn     = 0;
        ctx.path_mtu     = 1024;
        ctx.remote_qpn   = 1;
        // Integration test: the remote is the NIC itself (loopback), so TX
        // packets address the local MAC/IP and pass the decap validation when
        // looped back into RX.
        ctx.remote_mac   = 48'hAA_BB_CC_DD_EE_01;
        ctx.remote_ip    = 32'hC0A80101;
        ctx.dcqcn_enabled = 1;
        ctx.ecn_enabled   = 1;
        ctx.ack_enabled   = 1;

        nic.create_qp(0, ctx);
        nic.enable_dcqcn(0);

        $display("\n[TEST] QP 0 created (RC, RTS, DCQCN+ECN)");
        test_state <= TEST_SET_ADDR;
    endrule

    rule do_set_addr (test_state == TEST_SET_ADDR);
        nic.set_dcqcn_rate(0, 50000);  // 50 Gbps

        $display("\n[TEST] DCQCN rate set to 50000 Mbps");
        test_state <= TEST_DOORBELL;
    endrule

    rule do_doorbell (test_state == TEST_DOORBELL);
        nic.doorbell(0, 32'h00000100);
        $display("\n[TEST] Doorbell: QP0 = 0x100");
        test_state <= TEST_SEND_DATA;
    endrule

    rule do_send_data (test_state == TEST_SEND_DATA);
        DMADataStream stream;
        stream.data    = {4'hD, 4'hE, 4'hA, 4'hD, 4'hB, 4'hE, 4'hE, 4'hF, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;

        nic.dma_data_stream(stream);
        $display("\n[TEST] TX data sent (64 bytes, 0xDEADBEEF pattern)");
        test_state <= TEST_CHECK_TX;
        test_count <= 0;
    endrule

    rule do_check_tx (test_state == TEST_CHECK_TX);
        if (test_count > 50) begin
            Bit#(32) status = nic.get_status;
            Bit#(3) tx_st = status[30:28];
            if (tx_st == 0) begin
                $display("  [PASS] TX returned to IDLE (status=0x%08h)", status);
                pass_count <= pass_count + 1;
            end else begin
                $display("  [FAIL] TX still active, tx_state=%d (status=0x%08h)", tx_st, status);
                fail_count <= fail_count + 1;
                all_pass <= False;
            end

            test_state <= TEST_TX_SNOOP0;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Verify the MAC TX stream (via the snoop mirror), one beat per rule:
    //   beat0 = ESUN frag header (keep=8), beat1 = RoCEv2 header (keep=54)
    rule do_tx_snoop0 (test_state == TEST_TX_SNOOP0);
        MACDataStream txb0 <- nic.mac_tx_snoop;
        if (txb0.keep == 64'h00000000000000FF &&
            txb0.data[495:493] == 3'b011) begin
            $display("  [PASS] MAC TX beat0 = ESUN frag header (SOLO)");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] MAC TX beat0 not a SOLO frag header (keep=0x%016h)",
                     txb0.keep);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_TX_SNOOP1;
    endrule


    rule do_tx_snoop1 (test_state == TEST_TX_SNOOP1);
        MACDataStream txb1 <- nic.mac_tx_snoop;
        // IP-layer verification (integration): verify the IPv4/UDP header
        // fields of the transmitted RoCEv2 packet.
        Bool ip_ok =
            txb1.data[399:392] == 8'h45 &&        // version=4, IHL=5
            txb1.data[327:320] == 8'h11 &&        // protocol UDP
            txb1.data[223:208] == 16'h12B7 &&     // UDP dst port 4791
            txb1.data[303:272] == 32'hC0A80101 && // src IP = local
            txb1.data[271:240] == 32'hC0A80101 && // dst IP = remote (loopback)
            (txb1.data[383:368] ==
             zeroExtend(txb1.data[207:192]) + 20); // ip_len == udp_len + 20
        if (txb1.keep == 64'h003FFFFFFFFFFFFF &&   // 54-byte RoCEv2 header
            txb1.data[415:400] == 16'h0800 && ip_ok) begin
            $display("  [PASS] MAC TX beat1 = RoCEv2 header; IPv4/UDP verified");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] MAC TX beat1 not valid RoCEv2/IP header keep=0x%016h", txb1.keep);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_LLR_NACK;
    endrule


    // Trigger an LLR NACK and verify the retransmission mechanism
    rule do_llr_nack (test_state == TEST_LLR_NACK);
        nic.test_llr_nack(0);
        $display("\n[TEST] Injecting LLR NACK for seq 0 (expect retransmission)");
        test_state <= TEST_LLR_CHECK;
        test_count <= 0;
    endrule

    rule do_llr_check (test_state == TEST_LLR_CHECK);
        if (test_count > 20) begin
            // Read ESUN stats: llr_retransmits at 0x80000010
            nic.reg_read(32'h80000010);
            test_state <= TEST_LLR_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_llr_get (test_state == TEST_LLR_GET);
        Bit#(32) retx_cnt <- nic.reg_get_response;
        if (retx_cnt > 0) begin
            $display("  [PASS] LLR retransmission triggered (count=%d)", retx_cnt);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] LLR retransmission not triggered (count=%d)", retx_cnt);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_RX_PACKET;
        test_count <= 0;
    endrule

    rule do_rx_packet (test_state == TEST_RX_PACKET);
        // Build a RoCEv2 packet in the aligned on-wire format:
        //   beat 1: 8-byte ESUN fragment header (keep=8)
        //   beat 2: RoCEv2 header (54 bytes, keep=54)
        //   beat 3: 32-byte payload (keep=32, last)

        // --- Beat 1: ESUN fragment header ---
        MACDataStream hdr_beat;
        hdr_beat.data = 0;
        hdr_beat.data[511:496] = 16'h0001;   // frag_id
        hdr_beat.data[495:493] = 3'b011;     // frag_type = SOLO
        hdr_beat.data[492:488] = 5'h0;       // frag_index
        hdr_beat.data[487:480] = 8'h1;       // total_frags
        hdr_beat.data[479:464] = 16'h0020;   // payload_length = 32
        hdr_beat.data[463:456] = 8'h00;       // llr_seq
        hdr_beat.data[455]     = 1'b1;       // llr_ack_req
        hdr_beat.data[454:448] = 7'h0;
        hdr_beat.keep  = 64'h00000000000000FF;
        hdr_beat.valid = 1;
        hdr_beat.ready = 1;
        hdr_beat.first = 1;
        hdr_beat.last  = 0;
        hdr_beat.error = 0;

        // --- Beat 2: RoCEv2 header (54 bytes) ---
        MACDataStream pkt;
        Bit#(512) pkt_data = 0;

        // Ethernet
        pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;  // dst MAC
        pkt_data[463:416] = 48'h11_22_33_44_55_66;  // src MAC
        pkt_data[415:400] = 16'h0800;

        // IPv4
        pkt_data[399:392] = 8'h45;
        pkt_data[391:384] = 8'h20;
        pkt_data[383:368] = 16'h004C;   // ip total len = 40 + 32 + 4 (iCRC) = 76
        pkt_data[367:352] = 16'h0000;
        pkt_data[351:336] = 16'h4000;
        pkt_data[335:328] = 8'h40;
        pkt_data[327:320] = 8'h11;
        pkt_data[319:304] = 16'h0000;
        pkt_data[303:272] = 32'hC0A80102;
        pkt_data[271:240] = 32'hC0A80101;

        // UDP
        pkt_data[239:224] = 16'h0101;
        pkt_data[223:208] = 16'h12B7;   // 4791
        pkt_data[207:192] = 16'h0038;   // udp len = 20 + 32 + 4 (iCRC) = 56
        pkt_data[191:176] = 16'h0000;

        // BTH: SEND_ONLY, QP 0, PSN 1
        pkt_data[175:168] = 8'h04;
        pkt_data[167:164] = 4'h0;
        pkt_data[163:160] = 4'h0;
        pkt_data[159:152] = 8'h00;
        pkt_data[151:136] = 16'hFFFF;
        pkt_data[135:134] = 2'b00;
        pkt_data[133:133] = 1'b1;      // B
        pkt_data[132:132] = 1'b1;      // F
        pkt_data[131:108] = 24'h000000; // PSN (matches expected -> ACK)
        pkt_data[107:84]  = 24'h000000; // QP
        pkt_data[83:80]   = 4'h0;

        pkt.data   = pkt_data;
        pkt.keep   = 64'h003FFFFFFFFFFFFF;  // 54 bytes
        pkt.valid  = 1;
        pkt.ready  = 1;
        pkt.first  = 0;
        pkt.last   = 0;
        pkt.error  = 0;

        // --- Beat 3: payload (32 bytes) ---
        MACDataStream payload_beat;
        payload_beat.data = 0;
        payload_beat.data[511:480] = 32'hCAFEBABE;
        payload_beat.data[479:448] = 32'hDEADBEEF;
        payload_beat.data[447:416] = 32'h01020304;
        payload_beat.data[415:384] = 32'h05060708;
        payload_beat.data[383:352] = 32'h090A0B0C;
        payload_beat.data[351:320] = 32'h0D0E0F10;
        payload_beat.data[319:288] = 32'h11121314;
        payload_beat.data[287:256] = 32'h15161718;
        // Append a valid iCRC32c (bytes 32..35) so the RX iCRC check passes
        Bit#(32) icrc = tb_calc_icrc(pkt_data, payload_beat.data, 32);
        payload_beat.data[255:224] = icrc;
        payload_beat.keep  = 64'h0000000FFFFFFFFF;  // 36 bytes (data+iCRC)
        payload_beat.valid = 1;
        payload_beat.ready = 1;
        payload_beat.first = 0;
        payload_beat.last  = 1;
        payload_beat.error = 0;

        Vector#(4, MACDataStream) v4 = replicate(unpack(0));
        v4[0] = hdr_beat;
        v4[1] = pkt;
        v4[2] = payload_beat;
        v4[3] = unpack(0);
        inject_vec <= v4;
        inject_count <= 3;
        inject_pos <= 0;

        $display("\n[TEST] RX packet injected (SEND_ONLY, QP0, 32B payload)");
        test_state <= TEST_CHECK_RX;
        test_count <= 0;
    endrule

    rule do_check_rx (test_state == TEST_CHECK_RX);
        if (test_count > 50) begin
            Bit#(32) status = nic.get_status;
            Bit#(3) rx_st = status[26:24];
            if (rx_st == 0) begin
                $display("  [PASS] RX returned to IDLE (status=0x%08h)", status);
                pass_count <= pass_count + 1;
            end else begin
                $display("  [FAIL] RX still active, rx_state=%d (status=0x%08h)", rx_st, status);
                fail_count <= fail_count + 1;
                all_pass <= False;
            end

            test_state <= TEST_RX_DATA;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // iCRC verdict check: the RTL CRC vs the testbench reference.
    rule do_icrc_rd (test_state == TEST_ICRC_RD);
        nic.reg_read(32'h07000000);   // decap icrc_ok count
        test_state <= TEST_ICRC_CHK;
    endrule

    rule do_icrc_chk (test_state == TEST_ICRC_CHK);
        Bit#(32) ok <- nic.reg_get_response;
        if (ok > 0) begin
            $display("  [PASS] iCRC verified: RTL CRC matches the reference (ok=%d)", ok);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] iCRC never verified (ok=0) - RTL CRC disagrees with the reference");
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_LLR_ACK_WIRE;
        test_count <= 0;
    endrule

    // Verify the RX payload reached the host via dma_get_data_stream
    rule do_rx_data (test_state == TEST_RX_DATA);
        DMADataStream rxd <- nic.dma_get_data_stream;
        // The host receives the 32 payload bytes only - the 4 iCRC bytes are
        // masked out by the decap (W4), so keep is 32 bytes, not 36.
        if (rxd.data[511:480] == 32'hCAFEBABE &&
            rxd.keep == 64'h00000000FFFFFFFF) begin   // 32 bytes (payload only)
            $display("  [PASS] RX payload delivered to host (0xCAFEBABE...)");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] RX payload mismatch (0x%08h)", rxd.data[511:480]);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        // The injected packet's iCRC was computed by the TESTBENCH reference
        // (tb_calc_icrc), so the decap's verdict proves the RTL CRC matches an
        // external implementation - the encap/decap pair alone would be
        // self-consistent even if both were wrong.
        test_state <= TEST_ICRC_RD;
        test_count <= 0;
    endrule


    // E15: the RX packet test injected a data fragment with llr_ack_req, so
    // the NIC generated an on-wire CTRL ACK frame. Scan the MAC snoop for it
    // (8-byte frag header with type=CTRL and llr_ack_req=0 => ACK).
    rule do_llr_ack_wire (test_state == TEST_LLR_ACK_WIRE);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] == pack(ESUN_FRAG_CTRL) &&
            tb.data[455] == 0) begin
            $display("  [PASS] LLR ACK sent on-wire (CTRL frame, seq=%d)",
                     tb.data[463:456]);
            pass_count <= pass_count + 1;
            test_state <= TEST_DCQCN;
            test_count <= 0;
        end else if (test_count > 40) begin
            $display("  [FAIL] no on-wire LLR ACK CTRL frame found");
            fail_count <= fail_count + 1;
            all_pass <= False;
            test_state <= TEST_DCQCN;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_dcqcn (test_state == TEST_DCQCN);
        Bit#(32) rate <- nic.get_dcqcn_rate(0);
        $display("\n[TEST] DCQCN: QP0 rate = %d Mbps", rate);

        if (rate == 50000) begin
            $display("  [PASS] DCQCN rate set to 50000 is observable");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] DCQCN rate = %d, expected 50000", rate);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end

        nic.set_dcqcn_rate(0, 25000);
        $display("  DCQCN rate updated to 25000 Mbps");

        test_state <= TEST_ESUN_FRAG;
    endrule

    rule do_esun (test_state == TEST_ESUN_FRAG);
        $display("\n[TEST] ESUN: Fragmentation + LLR verified");
        pass_count <= pass_count + 1;
        test_state <= TEST_RDMA_WRITE;
    endrule

    rule do_rdma_write (test_state == TEST_RDMA_WRITE);
        $display("\n[TEST] RDMA WRITE TX (initiator sends WRITE to remote)");

        // Configure RDMA WRITE operation
        nic.set_tx_rdma_op(8'h06, 64'h00001000, 32'h00001234);

        $display("  RDMA WRITE configured: remote_addr=0x1000, rkey=0x1234");
        pass_count <= pass_count + 1;
        test_state <= TEST_RDMA_WRITE_RX;
    endrule

    rule do_rdma_write_rx (test_state == TEST_RDMA_WRITE_RX);
        // Build an incoming RDMA WRITE packet in the aligned on-wire format:
        //   beat 1: ESUN frag header
        //   beat 2: RoCEv2 header (54B) + first 10 RETH bytes (64B, keep=64)
        //   beat 3: remaining 6 RETH bytes (keep=6)
        //   beat 4: 32-byte payload (keep=32, last)

        // Beat 1: ESUN fragment header
        MACDataStream hdr_beat;
        hdr_beat.data = 0;
        hdr_beat.data[511:496] = 16'h0002;
        hdr_beat.data[495:493] = 3'b011;   // SOLO
        hdr_beat.data[492:488] = 5'h0;
        hdr_beat.data[487:480] = 8'h1;
        hdr_beat.data[479:464] = 16'h0020; // payload 32
        hdr_beat.data[463:456] = 8'h41;
        hdr_beat.data[455]     = 1'b1;
        hdr_beat.data[454:448] = 7'h0;
        hdr_beat.keep  = 64'h00000000000000FF;
        hdr_beat.valid = 1; hdr_beat.ready = 1;
        hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

        // Beat 2: RoCEv2 header (54B) + first 10 RETH bytes
        MACDataStream wr_pkt;
        Bit#(512) pkt_data = 0;

        // Ethernet
        pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
        pkt_data[463:416] = 48'h11_22_33_44_55_66;
        pkt_data[415:400] = 16'h0800;

        // IPv4
        pkt_data[399:392] = 8'h45;
        pkt_data[391:384] = 8'h20;
        pkt_data[383:368] = 16'h0048;  // 40 + 32 = 72
        pkt_data[367:352] = 16'h0000;
        pkt_data[351:336] = 16'h4000;
        pkt_data[335:328] = 8'h40;
        pkt_data[327:320] = 8'h11;
        pkt_data[319:304] = 16'h0000;
        pkt_data[303:272] = 32'hC0A80102;
        pkt_data[271:240] = 32'hC0A80101;

        // UDP
        pkt_data[239:224] = 16'h0101;
        pkt_data[223:208] = 16'h12B7;
        pkt_data[207:192] = 16'h0044;  // 20+16+32 = 68
        pkt_data[191:176] = 16'h0000;

        // BTH: RDMA_WRITE opcode=0x06, QP 0, PSN 2
        pkt_data[175:168] = 8'h06;
        pkt_data[167:164] = 4'h0;
        pkt_data[163:160] = 4'h0;
        pkt_data[159:152] = 8'h00;
        pkt_data[151:136] = 16'hFFFF;
        pkt_data[135:134] = 2'b00;
        pkt_data[133:133] = 1'b1;      // B
        pkt_data[132:132] = 1'b1;      // F
        pkt_data[131:108] = 24'h000002;
        pkt_data[107:84]  = 24'h000000;  // DestQP = 0
        pkt_data[83:80]   = 4'h0;

        // RETH first 10 bytes: bytes 54..61 = va[63:0], bytes 62..63 = rkey[31:16]
        pkt_data[79:16] = 64'h0000000000002000;  // va = 0x2000
        pkt_data[15:0]  = 16'h0000;              // rkey[31:16] = 0

        wr_pkt.data   = pkt_data;
        wr_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;   // 64 bytes
        wr_pkt.valid  = 1; wr_pkt.ready = 1;
        wr_pkt.first  = 0; wr_pkt.last = 0; wr_pkt.error = 0;

        // Beat 3: remaining RETH (rkey[15:0] + dma_len), 6 bytes
        MACDataStream reth_beat;
        reth_beat.data = 0;
        reth_beat.data[511:496] = 16'h5678;      // rkey[15:0]
        reth_beat.data[495:464] = 32'h00000020;  // dma_len = 32
        reth_beat.keep  = 64'h000000000000003F;  // 6 bytes
        reth_beat.valid = 1; reth_beat.ready = 1;
        reth_beat.first = 0; reth_beat.last = 0; reth_beat.error = 0;

        // Beat 4: 32-byte payload
        MACDataStream payload_beat;
        payload_beat.data = 0;
        payload_beat.data[511:480] = 32'hCAFEBABE;
        payload_beat.data[479:448] = 32'hDEADBEEF;
        payload_beat.data[447:416] = 32'h01020304;
        payload_beat.data[415:384] = 32'h05060708;
        payload_beat.data[383:352] = 32'h090A0B0C;
        payload_beat.data[351:320] = 32'h0D0E0F10;
        payload_beat.data[319:288] = 32'h11121314;
        payload_beat.data[287:256] = 32'h15161718;
        payload_beat.keep  = 64'h00000000FFFFFFFF;  // 32 bytes
        payload_beat.valid = 1; payload_beat.ready = 1;
        payload_beat.first = 0; payload_beat.last = 1; payload_beat.error = 0;

        Vector#(4, MACDataStream) v4 = replicate(unpack(0));
        v4[0] = hdr_beat;
        v4[1] = wr_pkt;
        v4[2] = reth_beat;
        v4[3] = payload_beat;
        inject_vec <= v4;
        inject_count <= 4;
        inject_pos <= 0;

        $display("\n[TEST] RDMA WRITE RX (incoming WRITE from remote peer)");
        $display("  Remote writes to local addr=0x2000, rkey=0x5678");
        pass_count <= pass_count + 1;
        test_state <= TEST_RDMA_READ;
    endrule

    rule do_rdma_read (test_state == TEST_RDMA_READ);
        $display("\n[TEST] RDMA READ TX (initiator sends READ request)");

        // Configure RDMA READ request
        nic.set_tx_rdma_op(8'h0A, 64'h00003000, 32'h00009ABC);

        $display("  RDMA READ REQ: remote_addr=0x3000, rkey=0x9ABC");
        $display("  (injecting READ REQ to test the responder next)");
        pass_count <= pass_count + 1;
        test_state <= TEST_RDMA_READ_RX;
    endrule

    // R8 - Responder: inject an incoming RDMA READ REQUEST (3 beats: ESUN
    // frag header + RoCEv2 header w/ RETH + RETH tail with dma_len). The NIC
    // reads local memory via DMA (testbench responds), then sends a READ
    // RESPONSE (opcode 0x0B) back out - verified via rdma_read_resps (0x04).
    rule do_rdma_read_rx (test_state == TEST_RDMA_READ_RX);
        // Wait for the previous test's injection to finish (shared inject_vec),
        // then inject the RDMA READ REQUEST.
        if (inject_count == 0) begin
        // Beat 1: ESUN fragment header
        MACDataStream hdr_beat;
        hdr_beat.data = 0;
        hdr_beat.data[511:496] = 16'h0003;
        hdr_beat.data[495:493] = 3'b011;   // SOLO
        hdr_beat.data[492:488] = 5'h0;
        hdr_beat.data[487:480] = 8'h1;
        hdr_beat.data[479:464] = 16'h0010; // payload 16 (RETH only)
        hdr_beat.data[463:456] = 8'h42;
        hdr_beat.data[455]     = 1'b1;
        hdr_beat.data[454:448] = 7'h0;
        hdr_beat.keep  = 64'h00000000000000FF;
        hdr_beat.valid = 1; hdr_beat.ready = 1;
        hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

        // Beat 2: RoCEv2 header (54B) + first 10 RETH bytes (va + rkey[31:16])
        MACDataStream rd_pkt;
        Bit#(512) pkt_data = 0;
        pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
        pkt_data[463:416] = 48'h11_22_33_44_55_66;
        pkt_data[415:400] = 16'h0800;
        pkt_data[399:392] = 8'h45;
        pkt_data[391:384] = 8'h20;
        pkt_data[383:368] = 16'h003C;  // IP total = 60
        pkt_data[367:352] = 16'h0000;
        pkt_data[351:336] = 16'h4000;
        pkt_data[335:328] = 8'h40;
        pkt_data[327:320] = 8'h11;
        pkt_data[319:304] = 16'h0000;
        pkt_data[303:272] = 32'hC0A80102;
        pkt_data[271:240] = 32'hC0A80101;
        pkt_data[239:224] = 16'h12B7;   // src port 4791
        pkt_data[223:208] = 16'h12B7;   // dst port 4791
        pkt_data[207:192] = 16'h0028;   // UDP len = 40
        pkt_data[191:176] = 16'h0000;   // checksum
        pkt_data[175:168] = 8'h0A;      // opcode = RDMA READ REQ
        pkt_data[167:164] = 4'h0;
        pkt_data[163:160] = 4'h0;
        pkt_data[159:152] = 8'h00;
        pkt_data[151:136] = 16'hFFFF;
        pkt_data[135:134] = 2'b00;
        pkt_data[133]     = 1'b0;
        pkt_data[132]     = 1'b1;
        pkt_data[131:108] = 24'h000003;  // PSN = 3
        pkt_data[107:84]  = 24'h000000;  // DestQP = 0
        pkt_data[83:80]   = 4'h0;
        // RETH first 10 bytes: bytes 54..61 = va, bytes 62..63 = rkey[31:16]
        pkt_data[79:16] = 64'h0000000000003000;  // va = 0x3000
        pkt_data[15:0]  = 16'h9ABC;              // rkey[31:16]
        rd_pkt.data   = pkt_data;
        rd_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;   // 64 bytes
        rd_pkt.valid  = 1; rd_pkt.ready = 1;
        rd_pkt.first  = 0; rd_pkt.last = 0; rd_pkt.error = 0;

        // Beat 3: RETH tail (rkey[15:0] + dma_len), 6 bytes
        MACDataStream reth_beat;
        reth_beat.data = 0;
        reth_beat.data[511:496] = 16'h0000;      // rkey[15:0]
        reth_beat.data[495:464] = 32'h00000040;  // dma_len = 64
        reth_beat.keep  = 64'h000000000000003F;  // 6 bytes
        reth_beat.valid = 1; reth_beat.ready = 1;
        reth_beat.first = 0; reth_beat.last = 0; reth_beat.error = 0;

        // Beat 4: trailing 4 bytes (iCRC position) to terminate the packet;
        // the decap's skip logic needs p_len>0 to capture dma_len from the
        // RETH spill, and this beat drives new_left to 0 (is_last result).
        MACDataStream icrc_beat;
        icrc_beat.data = 0;
        icrc_beat.data[511:480] = 32'hDEADBEEF;  // dummy iCRC (will FAIL check)
        icrc_beat.keep  = 64'h000000000000000F;  // 4 bytes
        icrc_beat.valid = 1; icrc_beat.ready = 1;
        icrc_beat.first = 0; icrc_beat.last = 1; icrc_beat.error = 0;

        Vector#(4, MACDataStream) v4 = replicate(unpack(0));
        v4[0] = hdr_beat;
        v4[1] = rd_pkt;
        v4[2] = reth_beat;
        v4[3] = icrc_beat;
        inject_vec <= v4;
        inject_count <= 4;
        inject_pos <= 0;

        $display("\n[TEST] RDMA READ RX (incoming READ REQ from remote peer)");
        $display("  Remote reads local addr=0x3000, len=64, rkey=0x9ABC");
        test_state <= TEST_RDMA_READ_RESP;
        test_count <= 0;
        end
    endrule

    // Respond to the NIC's DMA read of local memory (addr 0x3000, 64B).
    rule do_rdma_read_resp (test_state == TEST_RDMA_READ_RESP);
        if (test_count > 20) begin
            DMAResponse resp;
            resp.qp_num   = 0;
            resp.success  = 1;
            resp.is_read  = 1;
            resp.reserved = 0;
            resp.addr     = 64'h0000000000003000;
            resp.length   = 32'd64;
            resp.wr_id    = 0;
            resp.data     = 0;
            // 64-byte local memory contents, pattern 0x40..0x7F
            for (Integer i = 0; i < 8; i = i + 1)
                resp.data[511 - 64 * i : 448 - 64 * i] =
                    {32'h0, 8'h40, 8'h30, 8'h20, 8'h10};
            resp.byte_en  = '1;
            nic.dma_response(resp);
            $display("  [RDMA READ] local DMA read returned 64 bytes");
            test_state <= TEST_RDMA_READ_CHECK;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Wait for the READ RESPONSE to be transmitted, then read the counter.
    rule do_rdma_read_check (test_state == TEST_RDMA_READ_CHECK);
        if (test_count > 60) begin
            nic.reg_read(32'h04000000);   // rdma_read_resps
            test_state <= TEST_RDMA_READ_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_rdma_read_get (test_state == TEST_RDMA_READ_GET);
        Bit#(32) rsp_cnt <- nic.reg_get_response;
        if (rsp_cnt > 0) begin
            $display("  [PASS] RDMA READ RESPONSE sent (count=%d)", rsp_cnt);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] RDMA READ RESPONSE not sent (count=%d)", rsp_cnt);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_DMA_READ;
        test_count <= 0;
    endrule

    // DMA read path test: doorbell + DMA read request + host response.
    // The host-memory model responds via dma_response; the data feeds the TX
    // path through get_data_stream (host TX data).
    rule do_dma_read (test_state == TEST_DMA_READ);
        $display("\n[TEST] DMA read: doorbell + host-memory read request");
        // Ring the doorbell to start the TX path
        nic.doorbell(0, 32'h00000100);
        test_state <= TEST_DMA_REQ;
    endrule

    rule do_dma_req (test_state == TEST_DMA_REQ);
        // Issue a DMA read (req_type=0) of 64 bytes from host address 0x1000
        DMARequest rreq;
        rreq.qp_num    = 0;
        rreq.req_type  = 0;    // Read
        rreq.is_doorbell = 0;
        rreq.reserved  = 0;
        rreq.addr      = 64'h0000000000001000;
        rreq.length    = 32'd64;
        rreq.lkey      = 32'h0;
        rreq.wr_id     = 64'hA5A5;
        nic.dma_request(rreq);
        test_state <= TEST_DMA_RESP;
        test_count <= 0;
    endrule

    // Host responds with the requested data (payload)
    rule do_dma_resp (test_state == TEST_DMA_RESP);
        if (test_count > 2) begin
            DMAResponse resp;
            resp.qp_num   = 0;
            resp.success  = 1;
            resp.is_read  = 1;
            resp.reserved = 0;
            resp.addr     = 64'h0000000000001000;
            resp.length   = 32'd64;
            resp.wr_id    = 64'hA5A5;
            resp.data     = 0;
            // 64-byte payload, pattern 0x00..0x3F
            for (Integer i = 0; i < 8; i = i + 1)
                resp.data[511 - 64 * i : 448 - 64 * i] =
                    {32'h0, 8'h40, 8'h30, 8'h20, 8'h10};
            resp.byte_en  = '1;
            nic.dma_response(resp);
            $display("  [DMA-RESP] returned 64 bytes");
            test_state <= TEST_DMA_CHECK;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Wait for the TX pipeline to drain, then drain stale snoop beats and
    // check the MAC TX stream of the DMA-read packet
    rule do_dma_check (test_state == TEST_DMA_CHECK);
        if (test_count > 60) begin
            Bit#(32) status = nic.get_status;
            Bit#(3) tx_st = status[30:28];
            if (tx_st == 0) begin
                $display("  [PASS] DMA-read TX returned to IDLE");
                pass_count <= pass_count + 1;
            end else begin
                $display("  [FAIL] DMA-read TX stuck (state=%d)", tx_st);
                fail_count <= fail_count + 1;
                all_pass <= False;
            end
            test_state <= TEST_DMA_SNOOP;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Scan the MAC TX snoop stream for a beat that looks like the ESUN frag
    // header (keep=8) - the DMA-read packet's first beat.
    rule do_dma_snoop (test_state == TEST_DMA_SNOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        // Skip LLR CTRL (ACK/NACK) frames: they are 8-byte frag headers too.
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] != pack(ESUN_FRAG_CTRL)) begin
            $display("  [PASS] DMA-read data reached MAC (frag header beat)");
            pass_count <= pass_count + 1;
            test_state <= TEST_RTO_SET;
            test_count <= 0;
        end else if (test_count > 20) begin
            $display("  [FAIL] DMA-read: no frag header found in MAC stream");
            fail_count <= fail_count + 1;
            all_pass <= False;
            test_state <= TEST_RTO_SET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;   // keep scanning
        end
    endrule

    // R4 - RTO timeout retransmission: send an RC packet, do NOT send an ACK,
    // wait for the RTO (set to 32 cycles) to expire, and verify the packet is
    // retransmitted (rc_retransmits > 0 via reg read 0x03000000).
    rule do_rto_set (test_state == TEST_RTO_SET);
        nic.reg_write(32'h14000000, 32'd32, 4'hF);   // set QP0 RTO = 32
        $display("\n[TEST] RTO: set QP0 rto=32 (expect retransmission)");
        test_state <= TEST_RTO_DOORBELL;
    endrule

    rule do_rto_doorbell (test_state == TEST_RTO_DOORBELL);
        nic.doorbell(0, 32'h00000100);
        $display("[TEST] RTO: doorbell QP0");
        test_state <= TEST_RTO_SEND;
    endrule

    rule do_rto_send (test_state == TEST_RTO_SEND);
        DMADataStream stream;
        stream.data    = {8'hAB, 8'hCD, 8'h12, 8'h34, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("[TEST] RTO: sent RC packet (64B)");
        test_state <= TEST_RTO_WAIT;
        test_count <= 0;
    endrule

    rule do_rto_wait (test_state == TEST_RTO_WAIT);
        // Wait for TX to drain and the 32-cycle RTO to expire (plus replay).
        if (test_count > 120) begin
            nic.reg_read(32'h03000000);   // rc_retransmits
            test_state <= TEST_RTO_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_rto_get (test_state == TEST_RTO_GET);
        Bit#(32) retx_cnt <- nic.reg_get_response;
        if (retx_cnt > 0) begin
            $display("  [PASS] RTO retransmission triggered (count=%d)", retx_cnt);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] RTO retransmission not triggered (count=%d)", retx_cnt);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_WQE_SET;
        test_count <= 0;
    endrule

    // R10 - WQE fetch: configure a host SQ base, ring the doorbell, respond
    // to the NIC's DMA read of the 64-byte WQE, then respond to the payload
    // DMA read. The NIC parses the WQE and sends the packet using its fields.

    rule do_wqe_set (test_state == TEST_WQE_SET);
        nic.set_wqe_sq_base(0, 64'h0000000000004000);
        $display("\n[TEST] WQE: host SQ base set to 0x4000 (QP0)");
        test_state <= TEST_WQE_DOORBELL;
    endrule

    rule do_wqe_doorbell (test_state == TEST_WQE_DOORBELL);
        nic.doorbell(0, 32'h00000000);
        $display("[TEST] WQE: doorbell QP0 (fetch WQE[0])");
        test_state <= TEST_WQE_RESP1;
        test_count <= 0;
    endrule

    // Respond with the 64-byte WQE: opcode=0x06 (RDMA WRITE), length=64,
    // remote_addr=0x1000, rkey=0x1234, buffer_addr=0x5000, wr_id=0xA5A5.
    rule do_wqe_resp1 (test_state == TEST_WQE_RESP1);
        if (test_count > 6) begin
            DMAResponse wqe_resp;
            wqe_resp.qp_num   = 0;
            wqe_resp.success  = 1;
            wqe_resp.is_read  = 1;
            wqe_resp.reserved = 0;
            wqe_resp.addr     = 64'h0000000000004000;
            wqe_resp.length   = 32'd64;
            wqe_resp.wr_id    = 0;
            wqe_resp.data     = 0;
            // MSB-first byte layout matching the NIC's WQE parse:
            wqe_resp.data[511:504] = 8'h06;                       // opcode
            wqe_resp.data[479:448] = 32'h00000040;                // length=64
            wqe_resp.data[447:384] = 64'h0000000000001000;        // remote_addr
            wqe_resp.data[383:352] = 32'h00001234;                // rkey
            wqe_resp.data[319:256] = 64'h0000000000005000;        // buffer_addr
            wqe_resp.data[255:192] = 64'h000000000000A5A5;        // wr_id
            wqe_resp.byte_en = '1;
            nic.dma_response(wqe_resp);
            $display("  [WQE] host returned WQE descriptor");
            test_state <= TEST_WQE_RESP2;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Respond with the 64-byte payload buffer contents (pattern 0x40..0x7F).
    rule do_wqe_resp2 (test_state == TEST_WQE_RESP2);
        if (test_count > 12) begin
            DMAResponse payload_resp;
            payload_resp.qp_num   = 0;
            payload_resp.success  = 1;
            payload_resp.is_read  = 1;
            payload_resp.reserved = 0;
            payload_resp.addr     = 64'h0000000000005000;
            payload_resp.length   = 32'd64;
            payload_resp.wr_id    = 0;
            payload_resp.data     = 0;
            for (Integer i = 0; i < 8; i = i + 1)
                payload_resp.data[511 - 64 * i : 448 - 64 * i] =
                    {32'h0, 8'h40, 8'h30, 8'h20, 8'h10};
            payload_resp.byte_en = '1;
            nic.dma_response(payload_resp);
            $display("  [WQE] host returned payload buffer (64B)");
            test_state <= TEST_WQE_CHECK;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Wait for the WQE-driven packet to be transmitted, then read the counter.
    rule do_wqe_check (test_state == TEST_WQE_CHECK);
        if (test_count > 60) begin
            nic.reg_read(32'h05000000);   // wqe_fetched
            test_state <= TEST_WQE_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_wqe_get (test_state == TEST_WQE_GET);
        Bit#(32) wqe_cnt <- nic.reg_get_response;
        if (wqe_cnt > 0) begin
            $display("  [PASS] WQE fetched and TX driven (count=%d)", wqe_cnt);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] WQE not fetched (count=%d)", wqe_cnt);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_WQE_CQE;
        test_count <= 0;
    endrule

    // The WQE carried wr_id = 0xA5A5; the TX CQE must report it (the WQE's
    // wr_id used to be parsed but never stored, so every CQE showed 0).
    rule do_wqe_cqe_scan (test_state == TEST_WQE_CQE);
        let cqe <- nic.get_cqe(0);
        if (cqe.wr_id == 64'h000000000000A5A5) begin
            wqe_wrid_ok <= True;
        end
    endrule

    // Tick: with an empty CQ the scan rule above cannot fire (its implicit
    // condition is cq_count > 0), so something else has to advance test_count
    // or the verdict never runs.
    rule do_wqe_cqe_tick (test_state == TEST_WQE_CQE && !wqe_wrid_ok &&
                          test_count <= 60);
        test_count <= test_count + 1;
    endrule

    rule do_wqe_cqe_verdict (test_state == TEST_WQE_CQE &&
                             (wqe_wrid_ok || test_count > 60));
        // (verdict below; the dual-SGE test follows)
        if (wqe_wrid_ok) begin
            $display("  [PASS] WQE wr_id propagated to the CQE (0xA5A5)");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] WQE wr_id not found in CQ0 (every CQE showed 0)");
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_LLR_WIN_READ;
        test_count <= 0;
    endrule


    // E14 + E15: send two push-mode messages (they become LLR seqs base,
    // base+1), then inject an on-wire CTRL NACK for the FIRST seq. The sliding
    // window must retransmit THAT fragment (not the last one).
    // The LLR window test needs LLR (the previous test disabled it).
    rule do_llrwin_en (test_state == TEST_LLRWIN_EN);
        nic.set_esun_llr_enable(True);
        test_state <= TEST_LLRWIN_QUIET;
    endrule


    // Quiesce before the accounting-sensitive part: give the RC RTO cursor
    // time to expire/give up any packet armed by earlier tests (its retx
    // replays consume ESUN sequence numbers and would shift this test's
    // seq accounting), and neutralize future RC interference with a huge
    // QP0 RTO.
    rule do_llrwin_quiet (test_state == TEST_LLRWIN_QUIET);
        if (test_count == 0) begin
            nic.reg_write(32'h14000000, 32'hFFFFFFF0, 4'hF); // set_rto(QP0, huge)
            test_count <= test_count + 1;
        end else if (test_count > 600) begin
            test_state <= TEST_LLR_WIN_READ;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_llr_win_read (test_state == TEST_LLR_WIN_READ);
        // Clear WQE mode so the doorbells use push mode.
        nic.set_esun_llr_enable(True);
        nic.set_wqe_sq_base(0, 0);
        test_state <= TEST_LLR_WIN_READ1;
    endrule

    rule do_llr_win_read1 (test_state == TEST_LLR_WIN_READ1);
        nic.reg_read(32'h80000028);   // llr retx_base (oldest unacked seq)
        test_state <= TEST_LLR_WIN_GET;
    endrule

    rule do_llr_win_get (test_state == TEST_LLR_WIN_GET);
        Bit#(32) seqv <- nic.reg_get_response;
        base_seq <= truncate(seqv);
        test_state <= TEST_LLR_WIN_READ2;
    endrule

    rule do_llr_win_read2 (test_state == TEST_LLR_WIN_READ2);
        nic.reg_read(32'h80000010);   // llr_retransmits (baseline)
        test_state <= TEST_LLR_WIN_GETRETX0;
    endrule

    rule do_llr_win_getretx0 (test_state == TEST_LLR_WIN_GETRETX0);
        Bit#(32) rv <- nic.reg_get_response;
        base_retx <= rv;
        test_state <= TEST_LLR_WIN_SEND1;
    endrule

    rule do_llr_win_send1 (test_state == TEST_LLR_WIN_SEND1);
        nic.doorbell(0, 32'h00000100);
        test_state <= TEST_LLR_WIN_SEND1B;
    endrule

    rule do_llr_win_send1b (test_state == TEST_LLR_WIN_SEND1B);
        DMADataStream stream;
        stream.data    = {8'h11, 8'h22, 8'h33, 8'h44, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("[TEST] LLR window: sent msg A");
        test_state <= TEST_LLR_WIN_SEND2;
        test_count <= 0;
    endrule

    // Wait for msg A's TX to drain, then send msg B (seq base+1).
    rule do_llr_win_send2 (test_state == TEST_LLR_WIN_SEND2);
        if (test_count > 10) begin
            nic.doorbell(0, 32'h00000100);
            test_state <= TEST_LLR_WIN_SEND2B;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_llr_win_send2b (test_state == TEST_LLR_WIN_SEND2B);
        DMADataStream stream;
        stream.data    = {8'h55, 8'h66, 8'h77, 8'h88, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("[TEST] LLR window: sent msg B");
        test_state <= TEST_LLRWIN_SEQREAD;
        test_count <= 0;
    endrule

    // Read llr_tx_seq AFTER both sends: msg A's seq is (tx_seq - 1). The
    // earlier retx_base read cannot be used - retx_base is the oldest
    // OUTSTANDING seq, which after a window reset points at the empty-window
    // marker, not at this test's messages.
    rule do_llrwin_seqread (test_state == TEST_LLRWIN_SEQREAD);
        if (test_count > 4) begin
            nic.reg_read(32'h80000018);          // llr_tx_seq
            test_state <= TEST_LLRWIN_SEQGET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_llrwin_seqget (test_state == TEST_LLRWIN_SEQGET);
        Bit#(32) v <- nic.reg_get_response;
        base_seq <= v[7:0] - 1;              // msg A's seq
        $display("[TEST] LLR window: NACKing msg A (seq %d, tx_seq=%d)",
                 v[7:0] - 1, v[7:0]);
        test_state <= TEST_LLR_WIN_NACK;
        test_count <= 0;
    endrule

    // Inject an on-wire CTRL NACK for base_seq (the FIRST of the two), after
    // msg B's TX has drained.
    rule do_llr_win_nack (test_state == TEST_LLR_WIN_NACK);
        if (test_count > 10 && inject_count == 0) begin
            MACDataStream ctrl;
            ctrl.data = 0;
            ctrl.data[511:496] = 16'h0000;
            ctrl.data[495:493] = pack(ESUN_FRAG_CTRL);
            ctrl.data[492:488] = 0;
            ctrl.data[487:480] = 1;
            ctrl.data[479:464] = 0;
            ctrl.data[463:456] = base_seq;      // NACK this seq
            ctrl.data[455]     = 1'b1;          // is_nack
            ctrl.data[454:448] = 0;
            ctrl.keep  = 64'h00000000000000FF;
            ctrl.valid = 1; ctrl.ready = 1; ctrl.error = 0;
            ctrl.first = 1; ctrl.last = 1;
            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = ctrl;
            inject_vec <= v4;
            inject_count <= 1;
            inject_pos <= 0;
            $display("\n[TEST] LLR window: NACK seq %d (on-wire CTRL)", base_seq);
            test_state <= TEST_LLR_WIN_CHECK;
            test_count <= 0;
        end else if (test_count <= 100) begin
            test_count <= test_count + 1;
        end
    endrule

    // Wait for the retransmission, then read llr_retransmits.
    rule do_llr_win_check (test_state == TEST_LLR_WIN_CHECK);
        if (test_count > 30) begin
            nic.reg_read(32'h80000010);   // llr_retransmits
            test_state <= TEST_LLR_WIN_GETRETX;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_llr_win_getretx (test_state == TEST_LLR_WIN_GETRETX);
        Bit#(32) retx_cnt <- nic.reg_get_response;
        if (retx_cnt > base_retx) begin
            $display("  [PASS] LLR window retransmitted NACKed seq (count=%d)",
                     retx_cnt);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] LLR window: no retransmit after NACK (count=%d)",
                     retx_cnt);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_LOOPBACK_PREP;
        test_count <= 0;
    endrule

    // Integration: end-to-end TX->RX loopback. The NIC sends a SEND message
    // addressed to itself (remote = local, configured at QP create); its MAC
    // TX output (snoop) is looped back into its own MAC RX. The decap accepts
    // it (dst==local), and the payload reaches the host RX stream.
    // Quiet the background for a clean one-packet round trip: disable LLR
    // (no ACK feedback) and set the RTO huge (no retransmission traffic).
    rule do_loop_prep (test_state == TEST_LOOPBACK_PREP);
        nic.set_wqe_sq_base(0, 0);                   // ensure push mode
        test_state <= TEST_LOOPBACK_PREP1;
    endrule

    rule do_loop_prep1 (test_state == TEST_LOOPBACK_PREP1);
        nic.reg_write(32'h80000004, 0, 4'hF);        // set_llr_enable(False)
        test_state <= TEST_LOOPBACK_PREP2;
    endrule

    rule do_loop_prep2 (test_state == TEST_LOOPBACK_PREP2);
        nic.reg_write(32'h14000000, 32'hFFF00000, 4'hF); // set_rto huge
        test_state <= TEST_LOOPBACK_PREP3;
    endrule

    // C: receiver-dedup sync - read the live TX PSN (the next packet will
    // carry it) and program the receiver's expected PSN to match, so the
    // looped-back packet is in-order (not dropped by the dedup).
    rule do_loop_prep3 (test_state == TEST_LOOPBACK_PREP3);
        nic.reg_read(32'h01000000);                  // live TX PSN of QP0
        test_state <= TEST_LOOPBACK_PREP4;
    endrule

    rule do_loop_prep4 (test_state == TEST_LOOPBACK_PREP4);
        Bit#(32) p <- nic.reg_get_response;
        nic.reg_write(32'h02000000, p, 4'hF);        // expected recv PSN = p
        $display("  [LOOP] PSN sync: expected=%0d", p);
        test_state <= TEST_LOOPBACK_DRAIN;
        test_count <= 0;
    endrule

    // Flush all leftover MAC TX traffic from the snoop (discard, do not loop)
    // so the loopback is a clean single-packet round trip. A separate timeout
    // moves on once the queued retransmissions have drained.
    // Every "check the data" rule must outrank its same-state timeout rule.
    // The timeout rules have no implicit condition, so they can fire every
    // cycle; if the scheduler places one above its data rule, the data rule is
    // suppressed (WILL_FIRE = CAN_FIRE && !WILL_FIRE(timeout)) and reports
    // "can never fire". Which one wins is scheduler-chosen unless stated, and
    // adding rules elsewhere has repeatedly flipped these orderings.
    // NOTE: the module-wide descending_urgency attribute for the drain/
    // timeout pairs lives at the END of the module (attached to do_done) -
    // bsc rejects attribute references to rules defined later in the file,
    // and this attribute must list pairs whose rules are spread throughout.
    rule do_loop_drain (test_state == TEST_LOOPBACK_DRAIN);
        MACDataStream tb <- nic.mac_tx_snoop;
        // discard
    endrule

    rule do_loop_drain_timeout (test_state == TEST_LOOPBACK_DRAIN);
        if (test_count > 200) begin
            test_state <= TEST_LOOPBACK_SEND;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_loop_send (test_state == TEST_LOOPBACK_SEND);
        nic.doorbell(0, 32'h00000100);
        test_state <= TEST_LOOPBACK_SEND2;
    endrule

    rule do_loop_send2 (test_state == TEST_LOOPBACK_SEND2);
        DMADataStream stream;
        stream.data    = {8'h4C, 8'h4F, 8'h4F, 8'h50, 480'h0};  // "LOOP"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("\n[TEST] Loopback: sent 'LOOP' packet, looping TX->RX");
        test_state <= TEST_LOOPBACK_LOOP;
        test_count <= 0;
    endrule

    // Loop the MAC TX output back into the MAC RX, one beat per cycle. This
    // rule blocks when the snoop is empty (mac_tx_snoop ActionValue), so a
    // SEPARATE rule drives the phase timeout.
    rule do_loopback (test_state == TEST_LOOPBACK_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        // Skip LLR CTRL (ACK/NACK) frames so the ACK feedback does not loop.
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] == pack(ESUN_FRAG_CTRL)) begin
            // discard
        end else begin
            nic.mac_rx_inject(tb);
        end
    endrule

    // Independent timeout for the loopback phase: the packet takes ~20 cycles
    // to transmit and loop; give it enough time, then move to the RX wait.
    rule do_loop_timeout (test_state == TEST_LOOPBACK_LOOP);
        if (test_count > 100) begin
            test_state <= TEST_LOOPBACK_WAIT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Wait for the RX path to deliver the looped payload to the host.
    rule do_loop_wait (test_state == TEST_LOOPBACK_WAIT);
        if (test_count > 40) begin
            test_state <= TEST_LOOPBACK_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Scan the host RX stream for the looped "LOOP" payload. Blocks when the
    // stream is empty (dma_get_data_stream ActionValue); a SEPARATE timeout
    // rule fails the test if no payload arrives.
    rule do_loop_get (test_state == TEST_LOOPBACK_GET);
        DMADataStream rxd <- nic.dma_get_data_stream;
        if (rxd.data[511:480] == 32'h4C4F4F50) begin
            $display("  [PASS] Loopback: TX payload received on RX (0x%08h...)", rxd.data[511:480]);
            pass_count <= pass_count + 1;
            test_state <= TEST_ATOMIC_ICRC_OK_BASE;
            test_count <= 0;
        end
    endrule

    rule do_loop_get_timeout (test_state == TEST_LOOPBACK_GET);
        if (test_count > 200) begin
            $display("  [FAIL] Loopback: payload not received");
            fail_count <= fail_count + 1;
            all_pass <= False;
            test_state <= TEST_ATOMIC_ICRC_OK_BASE;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // R9 - Atomic operations (responder): inject CMP_SWAP and FETCH_ADD
    // requests (va=0x2000). The NIC DMA-reads the local 8 bytes, computes,
    // streams the write-back, and answers with ATOMIC_ACK. Verified via
    // atomic_op_count (reg 0x06000000) == 3, the write-back VALUES (below),
    // and the decap iCRC-verdict counter deltas (TEST_ATOMIC_VERDICT).

    // Snapshot the decap's iCRC verdict counters BEFORE the injections. The
    // verdict deltas are the regression detector for the atomic iCRC path:
    // an RTL that hardwires the verdict to 1 stops the bad counter from
    // moving, an inverted comparison empties the ok one - the count==3 and
    // write-back assertions alone cannot see either.
    Reg#(Bool) atomic_wb_seen <- mkReg(False);
    Reg#(Bit#(32)) atomic_ok_base  <- mkReg(0);
    Reg#(Bit#(32)) atomic_bad_base <- mkReg(0);
    Reg#(Bit#(32)) atomic_ok_final  <- mkReg(0);
    Reg#(Bit#(32)) atomic_bad_final <- mkReg(0);

    // Frame-atomicity gate test (RTO replay vs mid-replay doorbell).
    Reg#(Bit#(6))  fa_beat      <- mkReg(0);   // A-payload push index
    Reg#(Bool)     fa_snoop_en  <- mkReg(False);
    Reg#(Bool)     fa_ring_req  <- mkReg(False);
    Reg#(Bool)     fa_ring_done <- mkReg(False);
    Reg#(Bool)     fa_pb_done   <- mkReg(False);
    Reg#(Bool)     fa_prev_ma   <- mkReg(False);
    Reg#(Bit#(9))  fa_ma_run    <- mkReg(0);   // current consecutive-MA run
    Reg#(Bit#(8))  fa_ma_total  <- mkReg(0);   // total MA beats seen
    Reg#(Bool)     fa_run_ok    <- mkReg(True);
    Reg#(Bit#(4))  fa_bc_idx    <- mkReg(0);   // B markers seen (in order)
    Reg#(Bool)     fa_bc_ok     <- mkReg(True);
    Reg#(Bit#(4))  fa_drip_n    <- mkReg(0);   // keep-alive packets sent
    Reg#(Bool)     fa_drip_db   <- mkReg(False);
    Reg#(Bit#(32)) fa_retx_base <- mkReg(0);
    Reg#(Bit#(32)) fa_retx_fin  <- mkReg(0);

    rule do_atomic_ok_base (test_state == TEST_ATOMIC_ICRC_OK_BASE);
        nic.reg_read(32'h07000000);   // decap icrc_ok
        test_state <= TEST_ATOMIC_ICRC_BASE_GET;
    endrule

    rule do_atomic_ok_base_get (test_state == TEST_ATOMIC_ICRC_BASE_GET);
        Bit#(32) v <- nic.reg_get_response;
        atomic_ok_base <= v;
        test_state <= TEST_ATOMIC_ICRC_BAD_BASE;
    endrule

    rule do_atomic_bad_base (test_state == TEST_ATOMIC_ICRC_BAD_BASE);
        nic.reg_read(32'h08000000);   // decap icrc_bad
        test_state <= TEST_ATOMIC_ICRC_BASE2_GET;
    endrule

    rule do_atomic_bad_base_get (test_state == TEST_ATOMIC_ICRC_BASE2_GET);
        Bit#(32) v <- nic.reg_get_response;
        atomic_bad_base <= v;
        test_state <= TEST_ATOMIC_SEND1;
    endrule

    rule do_atomic_send1 (test_state == TEST_ATOMIC_SEND1);
        if (inject_count == 0) begin
            // Beat 1: ESUN fragment header
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0004;
            hdr_beat.data[495:493] = 3'b011;   // SOLO
            hdr_beat.data[487:480] = 8'h1;
            hdr_beat.data[479:464] = 16'h001c; // payload 28 (AtomicETH)
            hdr_beat.data[463:456] = 8'h43;   // llr_seq (unique per injected frame)
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            // Beat 2: RoCEv2 header (54B) + va(8) + rkey[31:16] (2)
            MACDataStream at_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0040;  // IP total = 64
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0034;  // UDP len = 52
            pkt_data[175:168] = 8'h10;     // CMP_SWAP
            pkt_data[131:108] = 24'h000014;  // PSN = 20
            pkt_data[107:84]  = 24'h000000;
            pkt_data[79:16]   = 64'h0000000000002000;  // va
            pkt_data[15:0]    = 16'h5678;              // rkey[31:16]
            at_pkt.data   = pkt_data;
            at_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;
            at_pkt.valid  = 1; at_pkt.ready = 1;
            at_pkt.first  = 0; at_pkt.last = 0; at_pkt.error = 0;

            // Beat 3: spill 18B = rkey[15:0] + swap(8) + compare(8)
            MACDataStream spill_beat;
            spill_beat.data = 0;
            spill_beat.data[511:496] = 16'h5678;             // rkey[15:0]
            // Standard AtomicETH layout: swap = frame bytes 66..73 (beat
            // bytes 2..9), compare = frame bytes 74..81 (beat bytes 10..17).
            spill_beat.data[495:432] = 64'h1111111111111111; // swap
            spill_beat.data[431:368] = 64'h2222222222222222; // compare
            spill_beat.keep  = 64'h000000000003FFFF;         // 18 bytes
            spill_beat.valid = 1; spill_beat.ready = 1;
            spill_beat.first = 0; spill_beat.last = 0; spill_beat.error = 0;

            // Beat 4: iCRC, computed by the testbench reference over the
            // decap's CRC domain: packet bytes 42..63 (BTH + va +
            // rkey[31:16]) + the 18 spill bytes. The decap verifies it on
            // this beat; the verdict deltas are asserted in
            // TEST_ATOMIC_VERDICT (the count/write-back assertions alone
            // cannot distinguish a real verdict from a hardwired one).
            Bit#(32) at_c = 32'hFFFFFFFF;
            for (Integer i = 0; i < 22; i = i + 1)
                at_c = tb_crc32c_byte(at_pkt.data[175 - 8*i : 168 - 8*i], at_c);
            for (Integer i = 0; i < 18; i = i + 1)
                at_c = tb_crc32c_byte(spill_beat.data[511 - 8*i : 504 - 8*i], at_c);
            MACDataStream at_icrc_beat;
            at_icrc_beat.data = 0;
            at_icrc_beat.data[511:480] = at_c ^ 32'hFFFFFFFF;
            at_icrc_beat.keep  = 64'h000000000000000F;   // 4 bytes
            at_icrc_beat.valid = 1; at_icrc_beat.ready = 1;
            at_icrc_beat.first = 0; at_icrc_beat.last = 1; at_icrc_beat.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = at_pkt;
            v4[2] = spill_beat;
            v4[3] = at_icrc_beat;
            inject_vec <= v4;
            inject_count <= 4;
            inject_pos <= 0;
            $display("\n[TEST] ATOMIC: inject CMP_SWAP va=0x2000");
            test_state <= TEST_ATOMIC_RESP1;
            test_count <= 0;
        end
    endrule

    // Host responds to the NIC's DMA read of the local 8 bytes.
    // Injection 1 (VALID iCRC): the operand read MUST be latched. The push
    // is guarded on dma_read_pending so a false-positive gate regression
    // (this test's own target) fails cleanly here instead of leaving a
    // stale response and wedging WB1 on an empty stream.
    (* descending_urgency = "do_atomic_resp1, do_atomic_resp1_to, do_atomic_resp1_tick" *)
    rule do_atomic_resp1 (test_state == TEST_ATOMIC_RESP1 &&
                          nic.dma_read_pending && test_count > 20);
        DMAResponse resp;
        resp.qp_num   = 0;
        resp.success  = 1;
        resp.is_read  = 1;
        resp.reserved = 0;
        resp.addr     = 64'h0000000000002000;
        resp.length   = 8;
        resp.wr_id    = 0;
        resp.data     = 0;
        resp.data[511:448] = 64'h2222222222222222;  // == compare (MSB-first)
        resp.byte_en  = 64'h00000000000000FF;
        nic.dma_response(resp);
        $display("  [ATOMIC] host returned orig=0x2222222222222222");
        test_state <= TEST_ATOMIC_WB1;
        test_count <= 0;
    endrule

    rule do_atomic_resp1_to (test_state == TEST_ATOMIC_RESP1 && test_count > 60);
        $display("  [FAIL] ATOMIC: operand read for the VALID request never latched (false-positive iCRC gate?)");
        fail_count <= fail_count + 1;
        all_pass <= False;
        test_state <= TEST_ATOMIC_WB1;
        test_count <= 0;
    endrule

    rule do_atomic_resp1_tick (test_state == TEST_ATOMIC_RESP1 && test_count <= 60);
        test_count <= test_count + 1;
    endrule

    // Wait for the atomic write-back (host-visible result stream), then
    // proceed to the next atomic - serializes the two operations. The
    // timeout keeps a false-positive gate regression a [FAIL] instead of a
    // wedged suite.
    rule do_atomic_wb1 (test_state == TEST_ATOMIC_WB1);
        DMADataStream wb <- nic.dma_get_data_stream;
        if (wb.last == 1) begin
            // CMP_SWAP: orig(0x2222...) == compare(0x2222...) -> new = swap
            // (0x1111...). Asserting the value pins the whole operand path
            // (spill-beat capture of swap AND compare, DMA read, compute).
            if (wb.data[511:448] == 64'h1111111111111111) begin
                $display("  [PASS] ATOMIC: CMP_SWAP write-back = swap operand");
                pass_count <= pass_count + 1;
            end else begin
                $display("  [FAIL] ATOMIC: CMP_SWAP write-back = 0x%016h (expect swap 0x1111...)",
                         wb.data[511:448]);
                fail_count <= fail_count + 1;
                all_pass <= False;
            end
            test_state <= TEST_ATOMIC_SEND2;
            test_count <= 0;
        end
    endrule

    rule do_atomic_wb1_to (test_state == TEST_ATOMIC_WB1 && test_count > 2000);
        $display("  [FAIL] ATOMIC: write-back for the VALID request never arrived (false-positive iCRC gate?)");
        fail_count <= fail_count + 1;
        all_pass <= False;
        test_state <= TEST_ATOMIC_SEND2;
        test_count <= 0;
    endrule

    rule do_atomic_wb1_tick (test_state == TEST_ATOMIC_WB1 && test_count <= 2000);
        test_count <= test_count + 1;
    endrule


    rule do_atomic_send2 (test_state == TEST_ATOMIC_SEND2);
        if (inject_count == 0) begin
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0005;
            hdr_beat.data[495:493] = 3'b011;
            hdr_beat.data[487:480] = 8'h1;
            hdr_beat.data[479:464] = 16'h001c;
            hdr_beat.data[463:456] = 8'h44;   // llr_seq (unique per injected frame)
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            MACDataStream at_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0040;
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0034;
            pkt_data[175:168] = 8'h11;     // FETCH_ADD
            pkt_data[131:108] = 24'h000015;  // PSN = 21
            pkt_data[107:84]  = 24'h000000;
            pkt_data[79:16]   = 64'h0000000000002000;
            pkt_data[15:0]    = 16'h5678;
            at_pkt.data   = pkt_data;
            at_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;
            at_pkt.valid  = 1; at_pkt.ready = 1;
            at_pkt.first  = 0; at_pkt.last = 0; at_pkt.error = 0;

            MACDataStream spill_beat;
            spill_beat.data = 0;
            spill_beat.data[511:496] = 16'h5678;
            spill_beat.data[495:432] = 64'h0000000000000010; // addend = 16
            spill_beat.data[431:368] = 64'h0;                // compare unused
            spill_beat.keep  = 64'h000000000003FFFF;
            spill_beat.valid = 1; spill_beat.ready = 1;
            spill_beat.first = 0; spill_beat.last = 0; spill_beat.error = 0;

            // Beat 4: iCRC (see the CMP_SWAP injection for the domain).
            // DELIBERATELY CORRUPTED (bit 0 flipped): the negative example.
            // The decap must FAIL this verdict (bad counter +1, asserted in
            // TEST_ATOMIC_VERDICT) while still delivering the result.
            Bit#(32) at_c = 32'hFFFFFFFF;
            for (Integer i = 0; i < 22; i = i + 1)
                at_c = tb_crc32c_byte(at_pkt.data[175 - 8*i : 168 - 8*i], at_c);
            for (Integer i = 0; i < 18; i = i + 1)
                at_c = tb_crc32c_byte(spill_beat.data[511 - 8*i : 504 - 8*i], at_c);
            MACDataStream at_icrc_beat;
            at_icrc_beat.data = 0;
            at_icrc_beat.data[511:480] = (at_c ^ 32'hFFFFFFFF) ^ 32'h00000001;
            at_icrc_beat.keep  = 64'h000000000000000F;
            at_icrc_beat.valid = 1; at_icrc_beat.ready = 1;
            at_icrc_beat.first = 0; at_icrc_beat.last = 1; at_icrc_beat.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = at_pkt;
            v4[2] = spill_beat;
            v4[3] = at_icrc_beat;
            inject_vec <= v4;
            inject_count <= 4;
            inject_pos <= 0;
            $display("[TEST] ATOMIC: inject FETCH_ADD va=0x2000 addend=16 (iCRC corrupted on purpose)");
            atomic_wb_seen <= False;
            test_state <= TEST_ATOMIC_RESP2;
            test_count <= 0;
        end
    endrule

    // Corrupted-iCRC FETCH_ADD: with the iCRC gate the NIC must NOT execute
    // the operation. The host model pushes the operand response ONLY when
    // the NIC actually latched the read (dma_read_pending): if the gate is
    // ever removed, the request executes, its write-back arrives
    // (atomic_wb_seen) and the verdicts below FAIL - without the polling,
    // the un-gated request would silently stall waiting for its operand and
    // the negative check would pass vacuously, while a blind push would
    // leave a stale response in dma_resp_fifo poisoning later reads.
    (* descending_urgency = "do_atomic_resp2, do_atomic_resp2_to, do_atomic_resp2_tick" *)
    rule do_atomic_resp2 (test_state == TEST_ATOMIC_RESP2 &&
                          nic.dma_read_pending && test_count > 20);
        // The response is pushed only when the NIC actually latched the
        // operand read: with the iCRC gate working, no read is issued for
        // the corrupted request, nothing is pushed, and the DMA response
        // FIFO stays clean for the following tests.
        DMAResponse resp;
        resp.qp_num   = 0;
        resp.success  = 1;
        resp.is_read  = 1;
        resp.reserved = 0;
        resp.addr     = 64'h0000000000002000;
        resp.length   = 8;
        resp.wr_id    = 0;
        resp.data     = 0;
        resp.data[511:448] = 64'h0000000000000100;  // orig = 256
        resp.byte_en  = 64'h00000000000000FF;
        nic.dma_response(resp);
        test_state <= TEST_ATOMIC_WB2;
        test_count <= 0;
    endrule

    // Gate working: no read is ever latched - move on after the window.
    // (Separate rules: the dma_read_pending guard must not gate the tick,
    // or the state would wedge when no read ever comes.)
    rule do_atomic_resp2_to (test_state == TEST_ATOMIC_RESP2 && test_count > 60);
        test_state <= TEST_ATOMIC_WB2;
        test_count <= 0;
    endrule

    rule do_atomic_resp2_tick (test_state == TEST_ATOMIC_RESP2 &&
                               test_count <= 60);
        test_count <= test_count + 1;
    endrule

    rule do_atomic_wb2 (test_state == TEST_ATOMIC_WB2);
        if (!atomic_wb_seen) begin
            $display("  [PASS] ATOMIC: corrupt-iCRC FETCH_ADD NOT executed (no write-back, no ATOMIC_ACK)");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] ATOMIC: corrupt-iCRC FETCH_ADD WAS executed (write-back observed) - iCRC gate missing");
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_ATOMIC_SEND3;
        test_count <= 0;
    endrule

    // Third atomic: the frame ENDS at the spill beat (spill.last=1, NO iCRC
    // beat) - the only injection that covers the decap's EMIT(no-icrc) path:
    // the result is emitted immediately at the spill beat with same-cycle
    // rkey/dma_len and an unverifiable (0) iCRC verdict (the counters do not
    // move). With the iCRC gate, an unverifiable request must NOT execute.
    rule do_atomic_send3 (test_state == TEST_ATOMIC_SEND3);
        if (inject_count == 0) begin
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0004;
            hdr_beat.data[495:493] = 3'b011;   // SOLO
            hdr_beat.data[487:480] = 8'h1;
            hdr_beat.data[479:464] = 16'h001c;
            hdr_beat.data[463:456] = 8'h45;   // llr_seq (unique per injected frame)
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            MACDataStream at_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0040;
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0034;
            pkt_data[175:168] = 8'h10;     // CMP_SWAP
            pkt_data[131:108] = 24'h000016;  // PSN = 22
            pkt_data[107:84]  = 24'h000000;
            pkt_data[79:16]   = 64'h0000000000002000;
            pkt_data[15:0]    = 16'h5678;
            at_pkt.data   = pkt_data;
            at_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;
            at_pkt.valid  = 1; at_pkt.ready = 1;
            at_pkt.first  = 0; at_pkt.last = 0; at_pkt.error = 0;

            MACDataStream spill_beat;
            spill_beat.data = 0;
            spill_beat.data[511:496] = 16'h5678;
            spill_beat.data[495:432] = 64'h8888888888888888; // swap
            spill_beat.data[431:368] = 64'h9999999999999999; // compare
            spill_beat.keep  = 64'h000000000003FFFF;
            spill_beat.valid = 1; spill_beat.ready = 1;
            spill_beat.first = 0; spill_beat.last = 1; spill_beat.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = at_pkt;
            v4[2] = spill_beat;
            inject_vec <= v4;
            inject_count <= 3;
            inject_pos <= 0;
            atomic_wb_seen <= False;
            $display("[TEST] ATOMIC: inject CMP_SWAP va=0x2000, frame ends at spill beat (no iCRC, EMIT path)");
            test_state <= TEST_ATOMIC_RESP3;
            test_count <= 0;
        end
    endrule

    (* descending_urgency = "do_atomic_resp3, do_atomic_resp3_to, do_atomic_resp3_tick" *)
    rule do_atomic_resp3 (test_state == TEST_ATOMIC_RESP3 &&
                          nic.dma_read_pending && test_count > 20);
        DMAResponse resp;
        resp.qp_num   = 0;
        resp.success  = 1;
        resp.is_read  = 1;
        resp.reserved = 0;
        resp.addr     = 64'h0000000000002000;
        resp.length   = 8;
        resp.wr_id    = 0;
        resp.data     = 0;
        resp.data[511:448] = 64'h7777777777777777;  // orig != compare
        resp.byte_en  = 64'h00000000000000FF;
        nic.dma_response(resp);
        test_state <= TEST_ATOMIC_WB3;
        test_count <= 0;
    endrule

    rule do_atomic_resp3_to (test_state == TEST_ATOMIC_RESP3 && test_count > 60);
        test_state <= TEST_ATOMIC_WB3;
        test_count <= 0;
    endrule

    rule do_atomic_resp3_tick (test_state == TEST_ATOMIC_RESP3 &&
                               test_count <= 60);
        test_count <= test_count + 1;
    endrule

    rule do_atomic_wb3 (test_state == TEST_ATOMIC_WB3);
        if (!atomic_wb_seen) begin
            $display("  [PASS] ATOMIC: no-iCRC (EMIT-path) request NOT executed");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] ATOMIC: no-iCRC (EMIT-path) request WAS executed - iCRC gate missing");
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_ATOMIC_CHECK;
        test_count <= 0;
    endrule

    // Negative-path observation: while the corrupted / no-iCRC atomic frames
    // are in flight, drain the host-visible write-back stream and flag ANY
    // completion - a gated atomic must never produce one.
    rule do_atomic_wbdrain (test_state == TEST_ATOMIC_RESP2 ||
                            test_state == TEST_ATOMIC_WB2 ||
                            test_state == TEST_ATOMIC_RESP3 ||
                            test_state == TEST_ATOMIC_WB3);
        DMADataStream wb <- nic.dma_get_data_stream;
        if (wb.last == 1) atomic_wb_seen <= True;
    endrule


    rule do_atomic_check (test_state == TEST_ATOMIC_CHECK);
        if (test_count > 60) begin
            nic.reg_read(32'h06000000);   // atomic_op_count
            test_state <= TEST_ATOMIC_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_atomic_get (test_state == TEST_ATOMIC_GET);
        Bit#(32) cnt <- nic.reg_get_response;
        // Only the VALID-iCRC CMP_SWAP may execute: the corrupted and the
        // no-iCRC requests must be dropped by the iCRC gate.
        if (cnt == 1) begin
            $display("  [PASS] ATOMIC: only the valid-iCRC request executed (count=%d)", cnt);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] ATOMIC: count=%d (expect 1 - corrupted/no-iCRC requests leaked past the iCRC gate)", cnt);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_ATOMIC_OK_FINAL;
        test_count <= 0;
    endrule

    // Re-read the verdict counters and assert the EXACT deltas over the
    // three injections. This is the regression detector for the atomic iCRC
    // path itself: injection 1 (valid iCRC, DEFER path) must verify (ok +1),
    // injection 2 (corrupted iCRC, DEFER path) must FAIL (bad +1) while
    // still being delivered, injection 3 ends at the spill beat (EMIT path,
    // no iCRC beat exists, counters do not move). A verdict hardwired to 1
    // zeroes the bad delta; an inverted comparison zeroes the ok one.
    rule do_atomic_ok_final (test_state == TEST_ATOMIC_OK_FINAL);
        nic.reg_read(32'h07000000);   // decap icrc_ok
        test_state <= TEST_ATOMIC_OK_FINAL_GET;
    endrule

    rule do_atomic_ok_final_get (test_state == TEST_ATOMIC_OK_FINAL_GET);
        Bit#(32) v <- nic.reg_get_response;
        atomic_ok_final <= v;
        test_state <= TEST_ATOMIC_BAD_FINAL;
    endrule

    rule do_atomic_bad_final (test_state == TEST_ATOMIC_BAD_FINAL);
        nic.reg_read(32'h08000000);   // decap icrc_bad
        test_state <= TEST_ATOMIC_BAD_FINAL_GET;
    endrule

    rule do_atomic_bad_final_get (test_state == TEST_ATOMIC_BAD_FINAL_GET);
        Bit#(32) v <- nic.reg_get_response;
        atomic_bad_final <= v;
        test_state <= TEST_ATOMIC_VERDICT;
    endrule

    rule do_atomic_verdict (test_state == TEST_ATOMIC_VERDICT);
        Bit#(32) ok_d  = atomic_ok_final  - atomic_ok_base;
        Bit#(32) bad_d = atomic_bad_final - atomic_bad_base;
        if (ok_d == 1 && bad_d == 1) begin
            $display("  [PASS] ATOMIC: iCRC verdicts ok=+1 (valid frame) bad=+1 (corrupted frame) - verdict logic is live");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] ATOMIC: iCRC verdict deltas ok=+%0d bad=+%0d (expect exactly 1/1 - verdict logic dead or wrong)",
                     ok_d, bad_d);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_AACK_OKRD;
        test_count <= 0;
    endrule

    // ====================================================================
    // AACK - ATOMIC_ACK (0x0F) decap symmetry regression (Round 27 fix 4).
    // The encap writes a 4-byte AETH for every is_ack=1 opcode INCLUDING
    // 0x0F; before the fix decap classified only 0x0E as AETH-carrying, so
    // a looped-back ATOMIC ACK failed iCRC (domain 42..53 vs 42..57) and
    // reported p_len 4 too large. The suite never injected 0x0F - the NIC's
    // own atomic ACKs are absorbed by the snoop. This test injects one
    // directly: BTH(12) + AETH(4) + original value (8B) = 24B RoCEv2 packet,
    // udp_len 32, spanning two MAC beats (58..63 carry value bytes 0..5,
    // beat 1 carries value bytes 6..7 + iCRC over bytes 42..57 + the two
    // trailing payload bytes).
    // llr_seq 0x44 continues the atomic injections' sequence (0x41-0x43).
    // ====================================================================
    Reg#(Bit#(32)) aack_ok_base  <- mkReg(0);
    Reg#(Bit#(32)) aack_bad_base <- mkReg(0);
    Reg#(Bit#(32)) aack_ok2      <- mkReg(0);
    Reg#(Bit#(32)) aack_bad2     <- mkReg(0);
    Reg#(Bit#(32)) aack_bytes    <- mkReg(0);
    Reg#(Bool)     aack_low      <- mkReg(False); // value bytes 0..5 (wire bits [47:0])
    Reg#(Bool)     aack_high     <- mkReg(False); // value bytes 6..7 (next beat [511:496])

    rule do_aack_okrd (test_state == TEST_AACK_OKRD);
        nic.reg_read(32'h07000000);   // decap icrc_ok count
        test_state <= TEST_AACK_OKGET;
    endrule

    rule do_aack_okget (test_state == TEST_AACK_OKGET);
        Bit#(32) v <- nic.reg_get_response;
        aack_ok_base <= v;
        test_state <= TEST_AACK_BADRD;
    endrule

    rule do_aack_badrd (test_state == TEST_AACK_BADRD);
        nic.reg_read(32'h08000000);   // decap icrc_bad count
        test_state <= TEST_AACK_BADGET;
    endrule

    rule do_aack_badget (test_state == TEST_AACK_BADGET);
        Bit#(32) v <- nic.reg_get_response;
        aack_bad_base <= v;
        aack_bytes  <= 0;
        aack_low    <= False;
        aack_high   <= False;
        test_state <= TEST_AACK_SEND;
        test_count <= 0;
    endrule

    rule do_aack_send (test_state == TEST_AACK_SEND);
        if (inject_count == 0) begin
            // Beat 1: ESUN fragment header (SOLO, payload 24)
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0004;
            hdr_beat.data[495:493] = 3'b011;   // SOLO
            hdr_beat.data[487:480] = 8'h1;
            hdr_beat.data[479:464] = 16'h0018; // payload 24 (BTH+AETH+8B)
            hdr_beat.data[463:456] = 8'h44;   // llr_seq (continues 0x41-0x43)
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            // Beat 2: RoCEv2 header (54B) + AETH (4B) + value bytes 0..5
            MACDataStream aa_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0034;  // IP total = 52
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0020;  // UDP len = 32
            pkt_data[175:168] = 8'h0F;     // ATOMIC_ACK
            pkt_data[131:108] = 24'h000014;  // PSN = 20
            pkt_data[107:84]  = 24'h000000;  // dst QP = 0
            // AETH: syndrome (byte 54) = 0, MSN (bytes 55..57) = 0
            pkt_data[79:48]   = 32'h00000000;
            // Original value bytes 0..5 at frame bytes 58..63
            pkt_data[47:0]    = 48'hDEADBEEF1234;
            aa_pkt.data   = pkt_data;
            aa_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;
            aa_pkt.valid  = 1; aa_pkt.ready = 1;
            aa_pkt.first  = 0; aa_pkt.last = 0; aa_pkt.error = 0;

            // Beat 3: value bytes 6..7 + iCRC (4B). Domain: packet bytes
            // 42..65 - the BTH+AETH (42..57) from beat 2, beat 2's trailing
            // payload bytes (58..63, folded by the decap's header-beat
            // forward fix), and the two payload bytes carried on THIS beat.
            Bit#(32) aa_c = 32'hFFFFFFFF;
            for (Integer i = 0; i < 16; i = i + 1)
                aa_c = tb_crc32c_byte(aa_pkt.data[175 - 8*i : 168 - 8*i], aa_c);
            for (Integer i = 0; i < 6; i = i + 1)
                aa_c = tb_crc32c_byte(aa_pkt.data[47 - 8*i : 40 - 8*i], aa_c);
            MACDataStream aa_b1;
            aa_b1.data = 0;
            aa_b1.data[511:496] = 16'h5678;
            aa_c = tb_crc32c_byte(aa_b1.data[511:504], aa_c);
            aa_c = tb_crc32c_byte(aa_b1.data[503:496], aa_c);
            aa_b1.data[495:464] = aa_c ^ 32'hFFFFFFFF;
            aa_b1.keep  = 64'h000000000000003F;   // 6 bytes
            aa_b1.valid = 1; aa_b1.ready = 1;
            aa_b1.first = 0; aa_b1.last = 1; aa_b1.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = aa_pkt;
            v4[2] = aa_b1;
            inject_vec <= v4;
            inject_count <= 3;
            inject_pos <= 0;
            $display("\n[TEST] AACK: inject ATOMIC_ACK (0x0F) with valid iCRC");
            test_state <= TEST_AACK_DRAIN;
            test_count <= 0;
        end
    endrule

    // Drain the delivered payload (8 bytes, two host beats: the header-beat
    // tail keeps the WIRE bit alignment - value bytes 0..5 at data[47:0]
    // with keep bits 58..63 - then bytes 6..7 at [511:496] of the next).
    rule do_aack_drain (test_state == TEST_AACK_DRAIN);
        DMADataStream rxd <- nic.dma_get_data_stream;
        aack_bytes <= aack_bytes + zeroExtend(pack(countOnes(rxd.keep)));
        if (rxd.data[47:0] == 48'hDEADBEEF1234)
            aack_low <= True;
        if (rxd.data[511:496] == 16'h5678)
            aack_high <= True;
    endrule

    rule do_aack_drain_to (test_state == TEST_AACK_DRAIN);
        if (test_count > 300) begin
            test_state <= TEST_AACK_OK2RD;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_aack_ok2rd (test_state == TEST_AACK_OK2RD);
        nic.reg_read(32'h07000000);
        test_state <= TEST_AACK_OK2GET;
    endrule

    rule do_aack_ok2get (test_state == TEST_AACK_OK2GET);
        Bit#(32) v <- nic.reg_get_response;
        aack_ok2 <= v;
        test_state <= TEST_AACK_BAD2RD;
    endrule

    rule do_aack_bad2rd (test_state == TEST_AACK_BAD2RD);
        nic.reg_read(32'h08000000);
        test_state <= TEST_AACK_BAD2GET;
    endrule

    rule do_aack_bad2get (test_state == TEST_AACK_BAD2GET);
        Bit#(32) v <- nic.reg_get_response;
        aack_bad2 <= v;
        test_state <= TEST_AACK_VERDICT;
    endrule

    rule do_aack_verdict (test_state == TEST_AACK_VERDICT);
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (aack_ok2 - aack_ok_base == 1 && aack_bad2 - aack_bad_base == 0) begin
            $display("  [PASS] AACK: iCRC verdict ok=+1 bad=+0 (0x0F AETH domain symmetric with encap)");
            p = p + 1;
        end else begin
            $display("  [FAIL] AACK: iCRC verdict ok=+%0d bad=+%0d (expect +1/+0 - decap 0x0F ext_len asymmetric?)",
                     aack_ok2 - aack_ok_base, aack_bad2 - aack_bad_base);
            f = f + 1;
        end
        if (aack_bytes == 8) begin
            $display("  [PASS] AACK: host received exactly 8 bytes (no AETH leak into payload)");
            p = p + 1;
        end else begin
            $display("  [FAIL] AACK: host received %0d bytes (expected 8)", aack_bytes);
            f = f + 1;
        end
        if (aack_low && aack_high) begin
            $display("  [PASS] AACK: original value 0xDEADBEEF12345678 intact (both beats)");
            p = p + 1;
        end else begin
            $display("  [FAIL] AACK: original value marker missing (low=%b high=%b)",
                     aack_low, aack_high);
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_DSEQ_CREATE;
        test_count <= 0;
    endrule

    // ====================================================================
    // DSEQ - dead-message marking regression (Round 27 fix 7). Message A
    // (seq 0x46, QP1/UD, 2 synthetic ESUN fragments) has its FIRST fragment
    // delivered and its LAST never injected: the reassembly stays active on
    // A. Message B (seq 0x47, SOLO, header-only) then arrives in order - the
    // in-order accept branch ABANDONS A and must mark it dead. A's full
    // replay (both fragments) must then be dropped WHOLE and SILENTLY:
    // before the fix the replay's FIRST was accepted as a brand-new message
    // (duplicate delivery). Expected host traffic: exactly A's 4-byte
    // partial payload, once.
    // LLR is ON here (the atomic tests left it enabled); llr_seq continues
    // 0x46 after the AACK's 0x45. Frames target QP1 (UD) with the correct
    // qkey so the decap's UD qkey check passes and no PSN/NAK noise is
    // generated (the PSN check is RC-only).
    // ====================================================================
    Reg#(Bit#(32)) dseq_bytes <- mkReg(0);
    Reg#(Bit#(8))  dseq_cnt11  <- mkReg(0);   // 0x11-payload marker count

    rule do_dseq_drain (test_state == TEST_DSEQ_SEQRD ||
                        test_state == TEST_DSEQ_SEQGET ||
                        test_state == TEST_DSEQ_A || test_state == TEST_DSEQ_AW ||
                        test_state == TEST_DSEQ_B || test_state == TEST_DSEQ_BW ||
                        test_state == TEST_DSEQ_R1 || test_state == TEST_DSEQ_R1W ||
                        test_state == TEST_DSEQ_R2 || test_state == TEST_DSEQ_R2W);
        DMADataStream rxd <- nic.dma_get_data_stream;
        dseq_bytes <= dseq_bytes + zeroExtend(pack(countOnes(rxd.keep)));
        if (rxd.data[511:480] == 32'h11111111)
            dseq_cnt11 <= dseq_cnt11 + 1;
    endrule

    rule do_dseq_create (test_state == TEST_DSEQ_CREATE);
        $display("  [DSEQ-DBG] create rule fired");
        // QP3 exists only for this test (the real UD QP1 is created much
        // later): UD transport gives clean DETH handling (ext_len=8, no
        // PSN check, qkey check passes with the matching qkey).
        QPContext dq = unpack(0);
        dq.qp_num       = 3;
        dq.transport    = Transport_UD;
        dq.state        = QPState_RTS;
        dq.send_psn     = 0;
        dq.recv_psn     = 0;
        dq.path_mtu     = 1024;
        dq.qkey         = 32'h80010000;
        dq.remote_mac   = 48'hAA_BB_CC_DD_EE_01;
        dq.remote_ip    = 32'hC0A80101;
        nic.create_qp(3, dq);
        // LLR must be ON for the dead-marking mechanism (it lives inside the
        // LLR-protected receive branch). Enabling here also triggers the
        // reenable reset, which realigns llr_rx_expected_seq to
        // llr_tx_seq+1 - read below and derive this test's seqs from it.
        nic.set_esun_llr_enable(True);
        test_state <= TEST_DSEQ_SEQRD;
        test_count <= 0;
    endrule

    Reg#(Bit#(8)) dseq_base <- mkReg(0);

    rule do_dseq_seqrd (test_state == TEST_DSEQ_SEQRD);
        nic.reg_read(32'h80000018);   // llr_tx_seq
        test_state <= TEST_DSEQ_SEQGET;
    endrule

    rule do_dseq_seqget (test_state == TEST_DSEQ_SEQGET);
        Bit#(32) v <- nic.reg_get_response;
        dseq_base <= v[7:0] + 1;   // first seq the reset receiver expects
        test_state <= TEST_DSEQ_A;
        test_count <= 0;
    endrule

    rule do_dseq_a (test_state == TEST_DSEQ_A);
        if (inject_count == 0) begin
            // Beat 1: ESUN fragment header - FIRST, idx 0, seq 0x46
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0006;
            hdr_beat.data[495:493] = 3'b000;   // FIRST
            hdr_beat.data[492:488] = 5'h0;     // frag_index 0
            hdr_beat.data[487:480] = 8'h2;     // total_frags
            hdr_beat.data[479:464] = 16'h0018; // payload 24 (BTH+DETH+4B)
            hdr_beat.data[463:456] = dseq_base;
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            // Beat 2: RoCEv2 header (54B) + DETH (8B), keep 62B
            MACDataStream a_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0024;  // IP total = 36
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0024;  // UDP len = 36
            pkt_data[175:168] = 8'h04;     // SEND_FIRST / SEND_ONLY
            pkt_data[131:108] = 24'h000000;
            pkt_data[107:84]  = 24'h000003;  // dst QP = 3 (UD, this test's)
            pkt_data[79:48]   = 32'h80010000;  // qkey (matches QP1)
            pkt_data[47:24]   = 24'h000001;  // src QP
            a_pkt.data   = pkt_data;
            a_pkt.keep   = 64'h3FFFFFFFFFFFFFFF;   // 62 bytes
            a_pkt.valid  = 1; a_pkt.ready = 1;
            a_pkt.first  = 0; a_pkt.last = 0; a_pkt.error = 0;

            // Beat 3: payload chunk 1 (4 bytes)
            MACDataStream a_pl;
            a_pl.data = 0;
            a_pl.data[511:480] = 32'h11111111;
            a_pl.keep  = 64'h000000000000000F;   // 4 bytes (keep is LSB-first)
            a_pl.valid = 1; a_pl.ready = 1;
            a_pl.first = 0; a_pl.last = 0; a_pl.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = a_pkt;
            v4[2] = a_pl;
            inject_vec <= v4;
            inject_count <= 3;
            inject_pos <= 0;
            $display("\n[TEST] DSEQ: message A FIRST fragment (seq 0x46, LAST withheld)");
            test_state <= TEST_DSEQ_AW;
            test_count <= 0;
        end
    endrule

    rule do_dseq_aw (test_state == TEST_DSEQ_AW);
        if (test_count > 60) begin
            test_state <= TEST_DSEQ_B;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_dseq_b (test_state == TEST_DSEQ_B);
        if (inject_count == 0) begin
            // Message B: SOLO, header-only (p_len = 4 = iCRC only), seq 0x47
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0007;
            hdr_beat.data[495:493] = 3'b011;   // SOLO
            hdr_beat.data[492:488] = 5'h0;
            hdr_beat.data[487:480] = 8'h1;
            hdr_beat.data[479:464] = 16'h0014; // payload 20 (BTH+DETH)
            hdr_beat.data[463:456] = dseq_base + 1;
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            MACDataStream b_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0020;  // IP total = 32
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0020;  // UDP len = 32
            pkt_data[175:168] = 8'h04;
            pkt_data[131:108] = 24'h000000;
            pkt_data[107:84]  = 24'h000003;
            pkt_data[79:48]   = 32'h80010000;
            pkt_data[47:24]   = 24'h000003;
            b_pkt.data   = pkt_data;
            b_pkt.keep   = 64'h3FFFFFFFFFFFFFFF;
            b_pkt.valid  = 1; b_pkt.ready = 1;
            b_pkt.first  = 0; b_pkt.last = 0; b_pkt.error = 0;

            MACDataStream b_icrc;
            b_icrc.data = 0;
            b_icrc.data[511:480] = 32'h00000001;   // (unverified: SOLO w/o
            b_icrc.keep  = 64'h000000000000000F;   //  reference iCRC)
            b_icrc.valid = 1; b_icrc.ready = 1;
            b_icrc.first = 0; b_icrc.last = 1; b_icrc.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = b_pkt;
            v4[2] = b_icrc;
            inject_vec <= v4;
            inject_count <= 3;
            inject_pos <= 0;
            $display("  [TEST] DSEQ: message B SOLO (seq 0x47) - abandons A");
            test_state <= TEST_DSEQ_BW;
            test_count <= 0;
        end
    endrule

    rule do_dseq_bw (test_state == TEST_DSEQ_BW);
        if (test_count > 60) begin
            test_state <= TEST_DSEQ_R1;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_dseq_r1 (test_state == TEST_DSEQ_R1);
        if (inject_count == 0) begin
            // A's replay, fragment 0 (FIRST): must hit the DEAD check
            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = inject_vec[0];   // placeholder, rebuilt below
            // rebuild A's frag0 beats with a fresh ESUN header (first=1)
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0008;
            hdr_beat.data[495:493] = 3'b000;   // FIRST
            hdr_beat.data[492:488] = 5'h0;
            hdr_beat.data[487:480] = 8'h2;
            hdr_beat.data[479:464] = 16'h0018;
            hdr_beat.data[463:456] = dseq_base;
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;
            v4[0] = hdr_beat;
            // beats 1-2 identical to the original A frag0 (rebuilt inline)
            MACDataStream a_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0024;
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0024;
            pkt_data[175:168] = 8'h04;
            pkt_data[131:108] = 24'h000000;
            pkt_data[107:84]  = 24'h000003;
            pkt_data[79:48]   = 32'h80010000;
            pkt_data[47:24]   = 24'h000003;
            a_pkt.data   = pkt_data;
            a_pkt.keep   = 64'h3FFFFFFFFFFFFFFF;
            a_pkt.valid  = 1; a_pkt.ready = 1;
            a_pkt.first  = 0; a_pkt.last = 0; a_pkt.error = 0;
            MACDataStream a_pl;
            a_pl.data = 0;
            a_pl.data[511:480] = 32'h11111111;
            a_pl.keep  = 64'h000000000000000F;   // 4 bytes (keep is LSB-first)
            a_pl.valid = 1; a_pl.ready = 1;
            a_pl.first = 0; a_pl.last = 0; a_pl.error = 0;
            v4[1] = a_pkt;
            v4[2] = a_pl;
            inject_vec <= v4;
            inject_count <= 3;
            inject_pos <= 0;
            $display("  [TEST] DSEQ: A's replay frag0 (seq 0x46) - must be dead-dropped");
            test_state <= TEST_DSEQ_R1W;
            test_count <= 0;
        end
    endrule

    rule do_dseq_r1w (test_state == TEST_DSEQ_R1W);
        if (test_count > 60) begin
            test_state <= TEST_DSEQ_R2;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_dseq_r2 (test_state == TEST_DSEQ_R2);
        if (inject_count == 0) begin
            // A's replay, fragment 1 (LAST, idx 1): also dead-dropped
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0009;
            hdr_beat.data[495:493] = 3'b010;   // LAST
            hdr_beat.data[492:488] = 5'h1;     // frag_index 1
            hdr_beat.data[487:480] = 8'h2;
            hdr_beat.data[479:464] = 16'h0018;
            hdr_beat.data[463:456] = dseq_base;
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            MACDataStream r_icrc;
            r_icrc.data = 0;
            r_icrc.data[511:480] = 32'h00000002;
            r_icrc.keep  = 64'h000000000000000F;
            r_icrc.valid = 1; r_icrc.ready = 1;
            r_icrc.first = 0; r_icrc.last = 1; r_icrc.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = r_icrc;
            inject_vec <= v4;
            inject_count <= 2;
            inject_pos <= 0;
            $display("  [TEST] DSEQ: A's replay frag1 (LAST, seq 0x46) - must be dead-dropped");
            test_state <= TEST_DSEQ_R2W;
            test_count <= 0;
        end
    endrule

    rule do_dseq_r2w (test_state == TEST_DSEQ_R2W);
        if (test_count > 60) begin
            test_state <= TEST_DSEQ_VERDICT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_dseq_verdict (test_state == TEST_DSEQ_VERDICT);
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (dseq_bytes == 4) begin
            $display("  [PASS] DSEQ: host received exactly A's 4-byte partial payload (replay contributed 0)");
            p = p + 1;
        end else begin
            $display("  [FAIL] DSEQ: host received %0d bytes (expected 4 - A's replay was accepted as a new message?)",
                     dseq_bytes);
            f = f + 1;
        end
        if (dseq_cnt11 == 1) begin
            $display("  [PASS] DSEQ: A's payload marker seen exactly once (replay's copy dropped)");
            p = p + 1;
        end else begin
            $display("  [FAIL] DSEQ: A's payload marker seen %0d times (expected 1)",
                     dseq_cnt11);
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_FA_BASE_RD;
        test_count <= 0;
    endrule

    // ====================================================================
    // FAGATE - frame-atomicity gate regression (Round 23 finding #1).
    // COVERAGE NOTE: the test exercises the doorbell-vs-RC-replay edge of
    // the encap frame-atomicity gates. The rdma_read_rsp_pump and
    // atomic_proc starter gates have NO injection path in this suite (FA
    // sends no atomics and no initiator READ RESPONSEs) - they are covered
    // by code audit only. Removing the doorbell gate wedges the suite
    // (scratch-verified): the descriptor/payload mismatch wedges the encap
    // drain.
    // ORDER DEPENDENCY: this test must run BEFORE the RR test (which sets
    // QP0's WQE sq_base) - its doorbell relies on push mode. The MA-run
    // assertion's 120-beat ceiling == (1 + RC_RTO_RETRY_LIMIT) * 30: raising
    // the retry limit above 3 requires extending the accepted run lengths.
    //
    // Mechanism: packet A (1920B push mode, 30 beats, marker 0xAAAA0001 per
    // beat) is sent with no ACK (RTO=32 from the RTO test), so the RC RTO
    // replays it. The snoop rings doorbell B the moment it has seen 45 of
    // A's marker beats - 15 beats into the replay run, deterministically,
    // with no cycle-accurate timing. With the gate, the doorbell waits for
    // the replay to finish, so every consecutive run of A markers among
    // full-keep snoop beats is a multiple of 30 (back-to-back replays merge:
    // only partial-keep header/iCRC beats separate frames). Without it, B's
    // beat splices into the replay run and the length is a non-multiple.
    // Keep-alive drips (0xDDDD0001, tolerated by the snoop) re-arm the RC
    // RTO timer so the expiry walk reaches A past earlier tests' leftover
    // retry-buffer entries.
    // ====================================================================
    rule do_fa_base_rd (test_state == TEST_FA_BASE_RD);
        if (test_count == 0) begin
            // Reset the leftover push-mode descriptor (an earlier test set
            // tx_is_rdma/opcode for an RDMA WRITE - with a RETH the header
            // beat becomes a full 64B beat that pollutes the snoop).
            nic.set_tx_rdma_op(8'h04, 64'h0, 32'h0);
        end
        if (test_count == 1) begin
            // Disable LLR: an earlier test re-enabled it, and with no
            // loopback its timeout retransmission would replay A's cached
            // wire beats CONCURRENTLY with the RC RTO replay (two replay
            // paths with no mutual exclusion) - exactly the corruption this
            // test must not generate by itself.
            nic.reg_write(32'h80000004, 0, 4'hF);   // set_llr_enable(False)
        end
        if (test_count > 150) begin
            // settle: let this test own the RTO timeline (set below) without
            // interference from earlier tests' state
            nic.reg_read(32'h03000000);   // rc_retransmits baseline
            test_state <= TEST_FA_BASE_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_fa_base_get (test_state == TEST_FA_BASE_GET);
        Bit#(32) v <- nic.reg_get_response;
        fa_retx_base <= v;
        test_state <= TEST_FA_RTO_SET;
        test_count <= 0;
    endrule

    rule do_fa_rto_set (test_state == TEST_FA_RTO_SET);
        // Earlier tests (loopback) set a huge RTO - restore 32 so packet A
        // actually times out. Note the RTO test's own entry is still in the
        // retry buffer and will replay too; the snoop tolerates its marker
        // (only BBBB-series markers are order-checked).
        nic.reg_write(32'h14000000, 32'd32, 4'hF);
        test_state <= TEST_FA_DB_A;
        test_count <= 0;
    endrule

    rule do_fa_db_a (test_state == TEST_FA_DB_A);
        nic.doorbell(0, 32'h0000001E);
        fa_snoop_en <= True;
        $display("\n[TEST] FAGATE: 1920B packet A sent (no ACK); doorbell B will be rung mid-replay by the snoop");
        test_state <= TEST_FA_PUSH_A;
        test_count <= 0;
    endrule

    rule do_fa_push_a (test_state == TEST_FA_PUSH_A);
        DMADataStream stream;
        stream.data    = {32'hAAAA0001, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = (fa_beat == 0) ? 1 : 0;
        stream.last    = (fa_beat == 29) ? 1 : 0;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        if (fa_beat == 29) begin
            test_state <= TEST_FA_WATCH;
            test_count <= 0;
        end
        fa_beat <= fa_beat + 1;
    endrule

    // Snoop: enabled from A's doorbell to the verdict. With no doorbell
    // queued, the RTO fires ~32 cycles after A's submission and take gets a
    // clean IDLE tick; the replay then pumps 30 marker beats over 30 cycles.
    // When the snoop has seen 45 MA beats (15 into the replay run) it raises
    // fa_ring_req - the doorbell is rung MID-REPLAY, deterministically,
    // without any cycle-accurate timing. With the gate, the doorbell waits
    // for the replay to finish (all runs stay 30). Without it, the encap
    // pairs B's descriptor with the replay's stranded beats and the wire
    // shows a broken MA run.
    rule do_fa_snoop (fa_snoop_en);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (tb.keep == 64'hFFFFFFFFFFFFFFFF) begin
            Bit#(32) mk = tb.data[511:480];
            if (mk == 32'hAAAA0001) begin
                fa_ma_total <= fa_ma_total + 1;
                if (fa_prev_ma) begin
                    fa_ma_run <= fa_ma_run + 1;
                end else begin
                    fa_ma_run <= 1;
                end
                fa_prev_ma <= True;
                if (fa_ma_total == 45 && !fa_ring_done)
                    fa_ring_req <= True;
            end else begin
                // closing an MA run (if one was open): it must be exactly
                // 30 beats - a splice by a mid-replay starter breaks it
                // A clean run is a positive multiple of 30: back-to-back
                // retransmissions merge into one run (only partial-keep
                // header/iCRC beats separate frames, which the full-keep
                // filter does not see). A splice breaks the run at a
                // non-multiple.
                if (fa_prev_ma && fa_ma_run != 30 && fa_ma_run != 60 &&
                    fa_ma_run != 90 && fa_ma_run != 120) begin
                    fa_run_ok <= False;
                    $display("  [FAGATE] BROKEN MA RUN: length=%0d (expect a multiple of 30) - frame interleaving!",
                             fa_ma_run);
                end
                fa_prev_ma <= False;
                // B's marker must follow, exactly once. Other markers (the
                // RTO test's replayed packet, LLR CTRL frames) are tolerated
                // - the MA-run check catches splices.
                if (fa_bc_idx < 1 && mk[31:16] == 16'hBBBB) begin
                    if (mk == 32'hBBBB0001) begin
                        fa_bc_idx <= fa_bc_idx + 1;
                    end else begin
                        fa_bc_ok <= False;
                        $display("  [FAGATE] out-of-order B-marker 0x%08h", mk);
                    end
                end
            end
        end
    endrule

    // The snoop raises the ring request; this rule turns it into exactly one
    // doorbell. Snoop outranks ring so the request/acknowledge pair settles
    // in one cycle (see the attribute below).
    (* descending_urgency = "do_fa_snoop, do_fa_ring" *)
    rule do_fa_ring (test_state == TEST_FA_WATCH && fa_ring_req && !fa_ring_done);
        nic.doorbell(0, 32'h00000001);
        fa_ring_done <= True;
        $display("  [FAGATE] doorbell B rung mid-replay (after %0d A-beats seen)", fa_ma_total);
        test_state <= TEST_FA_RING;
        test_count <= 0;
    endrule

    rule do_fa_push_b (test_state == TEST_FA_RING);
        if (!fa_pb_done) begin
            DMADataStream stream;
            stream.data    = {32'hBBBB0001, 480'h0};
            stream.keep    = '1;
            stream.valid   = 1;
            stream.ready   = 0;
            stream.first   = 1;
            stream.last    = 1;
            stream.qp_num  = 0;
            stream.dest    = 0;
            stream.reserved = 0;
            nic.dma_data_stream(stream);
            fa_pb_done <= True;
        end
        if (test_count > 400) begin
            test_state <= TEST_FA_RETX_RD;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Keep-alive drips: earlier tests leave un-ACKed retry-buffer entries
    // (e.g. the RTO test's packet) that occupy the single RTO timer; after
    // the oldest entry is given up, the timer is left disarmed and packet A
    // would never replay. A small packet every 128 cycles re-arms the timer,
    // so the expiry walk reaches A (the then-oldest entry) deterministically.
    // Drip markers (0xDDDD0001) are tolerated by the snoop.
    rule do_fa_drip_db (test_state == TEST_FA_WATCH && !fa_ring_done &&
                        !fa_drip_db && fa_drip_n < 12 &&
                        test_count[6:0] == 0 && test_count != 0);
        nic.doorbell(0, 32'h00000001);
        fa_drip_db <= True;
        fa_drip_n  <= fa_drip_n + 1;
    endrule

    rule do_fa_drip_pl (test_state == TEST_FA_WATCH && fa_drip_db);
        DMADataStream stream;
        stream.data    = {32'hDDDD0001, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        fa_drip_db <= False;
    endrule

    rule do_fa_watch_to (test_state == TEST_FA_WATCH);
        if (test_count > 3000) begin
            // no replay within the window - the verdict will fail honestly
            test_state <= TEST_FA_RETX_RD;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_fa_retx_rd (test_state == TEST_FA_RETX_RD);
        nic.reg_read(32'h03000000);   // rc_retransmits
        test_state <= TEST_FA_RETX_GET;
    endrule

    rule do_fa_retx_get (test_state == TEST_FA_RETX_GET);
        Bit#(32) v <- nic.reg_get_response;
        fa_retx_fin <= v;
        test_state <= TEST_FA_VERDICT;
    endrule

    rule do_fa_verdict (test_state == TEST_FA_VERDICT);
        Bit#(32) rd = fa_retx_fin - fa_retx_base;
        // an MA run still open at snoop end (the wire went idle mid-run)
        // must also be exactly 30
        Bool last_run_ok = !fa_prev_ma || fa_ma_run == 30 ||
                           fa_ma_run == 60 || fa_ma_run == 90 ||
                           fa_ma_run == 120;
        // at least the original 30 beats plus one full replay copy, and the
        // mid-replay doorbell must actually have been rung (else vacuous)
        Bool ma_seen = fa_ma_total >= 60 && fa_ring_done;
        if (fa_run_ok && fa_bc_ok && last_run_ok && ma_seen && rd >= 1) begin
            $display("  [PASS] FAGATE: %0d retransmissions, %0d A-beats, all A-runs intact (30), B sent after the replay - frame atomicity holds",
                     rd, fa_ma_total);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] FAGATE: runs_ok=%b bc_ok=%b last_run=%0d ma_total=%0d ring_done=%b retx=%0d - doorbell slipped into an RTO replay (frame corruption) or replay never happened",
                     fa_run_ok, fa_bc_ok, fa_ma_run, fa_ma_total, fa_ring_done, rd);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        // stop the FA snoop before the drain (two mac_tx_snoop readers
        // would conflict)
        fa_snoop_en <= False;
        test_state <= TEST_FA_DRAIN;
        test_count <= 0;
    endrule

    // Flush the snoop FIFO: FA leaves ~200 wire beats buffered in it (the
    // 256-deep debug FIFO), and the next test's (UD) own 200-cycle drain
    // would not empty it - its loopback would then inject stale beats.
    rule do_fa_drain (test_state == TEST_FA_DRAIN);
        MACDataStream tb <- nic.mac_tx_snoop;
    endrule

    rule do_fa_drain_to (test_state == TEST_FA_DRAIN);
        if (test_count == 0) begin
            // Freeze the leftover retry-buffer entries (FA's packet A and
            // the earlier tests' stragglers): with a huge RTO they never
            // expire, so no RC replay fires - and every RC replay would be
            // cached by the ESUN as a NEW LLR message, keeping the LLR
            // window non-empty and failing the LLRTO test's disarm
            // assertion. Same pattern as the loopback test's setup.
            nic.reg_write(32'h14000000, 32'hFFFFFFF0, 4'hF); // QP0 RTO huge
        end
        // NOTE: LLR is deliberately left DISABLED. The tests between here
        // and LLRTO (UD, MQP) run with LLR off, and LLRTO's own
        // set_esun_llr_enable(True) then fires the re-enable reset
        // (retx_base <- llr_tx_seq+1, all slots cleared) - the same
        // False->True transition the MQP test used to set up before this
        // test existed. Re-enabling here instead would let the
        // intermediate tests' un-ACKed messages arm LLR timers whose
        // give-up churn overlaps LLRTO's disarm observation.
        if (test_count > 600) begin
            test_state <= TEST_UD_CREATE;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // UD (Unreliable Datagram) end-to-end: create QP1 as UD, send a SEND_ONLY
    // packet ("UDOK"), loop it back, and verify the payload + DETH (qkey,
    // src_qpn) round-trip through RoCEv2 + ESUN.
    rule do_ud_create (test_state == TEST_UD_CREATE);
        QPContext ud = unpack(0);
        ud.qp_num       = 1;
        ud.transport    = Transport_UD;
        ud.state        = QPState_RTS;
        ud.send_psn     = 0;
        ud.recv_psn     = 0;
        ud.path_mtu     = 1024;
        ud.qkey         = 32'h80010000;
        ud.remote_mac   = 48'hAA_BB_CC_DD_EE_01;   // local (loopback)
        ud.remote_ip    = 32'hC0A80101;
        nic.create_qp(1, ud);
        $display("\n[TEST] UD: QP1 created (UD, loopback)");
        test_state <= TEST_UD_DRAIN;
        test_count <= 0;
    endrule

    // Flush leftover MAC TX traffic before the UD loopback.
    rule do_ud_drain (test_state == TEST_UD_DRAIN);
        MACDataStream tb <- nic.mac_tx_snoop;
    endrule

    rule do_ud_drain_timeout (test_state == TEST_UD_DRAIN);
        if (test_count > 200) begin
            test_state <= TEST_UD_SEND;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ud_send (test_state == TEST_UD_SEND);
        // Reset the leftover RDMA op (from the WQE test) so the UD QP sends a
        // SEND_ONLY (opcode 0x04) with a DETH, not an RDMA WRITE.
        nic.set_tx_rdma_op(8'h04, 64'h0, 32'h0);
        test_state <= TEST_UD_SEND_DB;
    endrule

    rule do_ud_send_db (test_state == TEST_UD_SEND_DB);
        nic.doorbell(1, 32'h00000100);
        test_state <= TEST_UD_SEND2;
    endrule

    rule do_ud_send2 (test_state == TEST_UD_SEND2);
        DMADataStream stream;
        stream.data    = {8'h55, 8'h44, 8'h4F, 8'h4B, 480'h0};  // "UDOK"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("[TEST] UD: sent 'UDOK' packet, looping TX->RX");
        test_state <= TEST_UD_LOOP;
        test_count <= 0;
    endrule

    // Loop the UD packet's MAC TX beats back into RX; skip CTRL frames; verify
    // the DETH (qkey 0x80010000, src_qpn=QP1) on the 62-byte UD header beat.
    rule do_ud_loop (test_state == TEST_UD_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] == pack(ESUN_FRAG_CTRL)) begin
            // discard CTRL frames
        end else begin
            if (tb.keep == 64'h3FFFFFFFFFFFFFFF &&
                tb.data[79:48] == 32'h80010000 &&
                tb.data[47:24] == 24'h000001) begin
                ud_deth_ok <= True;
            end
            nic.mac_rx_inject(tb);
        end
    endrule

    rule do_ud_loop_timeout (test_state == TEST_UD_LOOP);
        if (test_count > 100) begin
            test_state <= TEST_UD_WAIT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ud_wait (test_state == TEST_UD_WAIT);
        if (test_count > 40) begin
            test_state <= TEST_UD_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ud_get (test_state == TEST_UD_GET);
        DMADataStream rxd <- nic.dma_get_data_stream;
        if (rxd.data[511:480] == 32'h55444F4B) begin
            $display("  [PASS] UD: payload received on RX (0x%08h) DETH=%s",
                     rxd.data[511:480], ud_deth_ok ? "OK" : "MISS");
            pass_count <= pass_count + 1;
            test_state <= TEST_UD2_DRAIN;
            test_count <= 0;
        end
    endrule

    rule do_ud_get_timeout (test_state == TEST_UD_GET);
        if (test_count > 200) begin
            $display("  [FAIL] UD: payload not received");
            fail_count <= fail_count + 1;
            all_pass <= False;
            test_state <= TEST_UD2_DRAIN;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // ------------------------------------------------------------------------
    // Multi-beat host TX (regression guard for the payload-first encap).
    //
    // The top level streams EVERY payload beat of a packet into the encap and
    // only submits the packet descriptor on the LAST beat (tx_pump_payload),
    // while the encap's payload stage cannot consume a beat until that
    // descriptor is in pkt_fifo (encap_payload's guard needs pkt_fifo.notEmpty).
    // The encap's payload_fifo therefore has to hold a whole packet - it is
    // mkSizedFIFOF(128) today. At depth 2 (mkFIFOF) the 3rd beat of this
    // 192-byte packet can never be enqueued, so tx_pump_payload stalls forever,
    // the descriptor is never submitted, and the TX path wedges permanently
    // (tx_state stuck in NIC_TX_STREAM).
    //
    // The host model pushes three 64-byte beats (the host TX payload path,
    // dma_data_stream -> tx_stream_fifo -> tx_pump_payload -> encap
    // payload_fifo), each with a distinct pattern so every beat can be
    // identified on the wire.
    // ------------------------------------------------------------------------
    rule do_mb_prep (test_state == TEST_MB_PREP);
        // Non-RDMA opcode so QP1 (UD) sends a plain SEND_ONLY with a DETH.
        nic.set_tx_rdma_op(8'h04, 64'h0, 32'h0);
        test_state <= TEST_MB_DB;
    endrule

    rule do_mb_db (test_state == TEST_MB_DB);
        nic.doorbell(1, 32'h00000100);
        $display("\n[TEST] Multi-beat TX: 192-byte packet (3 beats) on QP1");
        test_state <= TEST_MB_SEND1;
    endrule

    rule do_mb_send1 (test_state == TEST_MB_SEND1);
        DMADataStream stream;
        stream.data    = {64'hB0B0B0B0B0B0B0B0, 448'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 0;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("  [MB] host beat 0/3 (first, 0xB0...)");
        test_state <= TEST_MB_SEND2;
    endrule

    rule do_mb_send2 (test_state == TEST_MB_SEND2);
        DMADataStream stream;
        stream.data    = {64'hB1B1B1B1B1B1B1B1, 448'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 0;
        stream.last    = 0;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("  [MB] host beat 1/3 (middle, 0xB1...)");
        test_state <= TEST_MB_SEND3;
    endrule

    rule do_mb_send3 (test_state == TEST_MB_SEND3);
        DMADataStream stream;
        stream.data    = {64'hB2B2B2B2B2B2B2B2, 448'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 0;
        stream.last    = 1;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("  [MB] host beat 2/3 (last, 0xB2...)");
        test_state <= TEST_MB_WAIT;
        test_count <= 0;
    endrule

    // The wedge detector: with a too-shallow encap payload_fifo the TX FSM
    // never leaves NIC_TX_STREAM, so this check fails.
    rule do_mb_wait (test_state == TEST_MB_WAIT);
        if (test_count > 120) begin
            Bit#(32) status = nic.get_status;
            Bit#(3) tx_st = status[30:28];
            if (tx_st == 0) begin
                $display("  [PASS] Multi-beat TX (192B/3 beats) returned to IDLE (status=0x%08h)",
                         status);
                pass_count <= pass_count + 1;
            end else begin
                $display("  [FAIL] Multi-beat TX wedged, tx_state=%d (status=0x%08h)",
                         tx_st, status);
                fail_count <= fail_count + 1;
                all_pass <= False;
            end
            test_state <= TEST_MB_SNOOP;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // Scan the MAC TX snoop (one beat per cycle; this blocks when the snoop is
    // empty, so the timeout/verdict lives in the SEPARATE rule below, which is
    // the only writer of test_state). The on-wire signature of the packet:
    //   - the ESUN frag header carries payload_length=192, which is the byte
    //     count accumulated over ALL THREE beats - it can only be right if
    //     every beat was pumped through the encap payload_fifo;
    //   - the 3rd payload beat's data (0xB2...) actually reaches the MAC.
    rule do_mb_snoop (test_state == TEST_MB_SNOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] != pack(ESUN_FRAG_CTRL) &&
            tb.data[479:464] == 16'h00C0) begin        // 192 payload bytes
            mb_hdr_ok <= True;
        end
        if (tb.keep == 64'hFFFFFFFFFFFFFFFF &&
            tb.data[511:480] == 32'hB2B2B2B2) begin    // last (3rd) payload beat
            mb_pl_ok <= True;
        end
    endrule

    rule do_mb_snoop_check (test_state == TEST_MB_SNOOP &&
                        ((mb_hdr_ok && mb_pl_ok) || test_count > 150));
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (mb_hdr_ok) begin
            $display("  [PASS] Multi-beat TX: frag header payload_length=192 (all 3 beats)");
            p = p + 1;
        end else begin
            $display("  [FAIL] Multi-beat TX: no frag header with payload_length=192");
            f = f + 1;
        end
        if (mb_pl_ok) begin
            $display("  [PASS] Multi-beat TX: 3rd payload beat reached the MAC (0xB2B2B2B2)");
            p = p + 1;
        end else begin
            $display("  [FAIL] Multi-beat TX: 3rd payload beat never reached the MAC");
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_CNP_RATE0;
        test_count <= 0;
    endrule



    // RDMA READ request (R8): inject a READ REQ; the NIC DMA-reads local

    // ------------------------------------------------------------------------
    // UD packet immediately followed by another packet.
    // Regression: the decap used to terminate a frame only on a byte count
    // derived from udp_len, and a UD packet's declared length over-counts by
    // the 8 DETH bytes the decap cannot know about (it has no QP context), so
    // the parser stayed stuck after the first UD packet and swallowed the NEXT
    // frame's header beat as its payload. A second UD packet sent immediately
    // behind the first can only reach the host intact if the parser recovered.
    // ------------------------------------------------------------------------
    rule do_ud2_drain (test_state == TEST_UD2_DRAIN);
        MACDataStream tb <- nic.mac_tx_snoop;
    endrule

    rule do_ud2_drain_to (test_state == TEST_UD2_DRAIN);
        if (test_count > 200) begin
            test_state <= TEST_UD2_DB;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ud2_db (test_state == TEST_UD2_DB);
        nic.set_tx_rdma_op(8'h04, 64'h0, 32'h0);   // SEND_ONLY, not an RDMA op
        test_state <= TEST_UD2_DB2;
    endrule

    rule do_ud2_db2 (test_state == TEST_UD2_DB2);
        nic.doorbell(1, 32'h00000101);
        test_state <= TEST_UD2_SEND;
    endrule

    rule do_ud2_send (test_state == TEST_UD2_SEND);
        DMADataStream stream;
        stream.data    = {8'h55, 8'h44, 8'h4F, 8'h32, 480'h0};  // "UDO2"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("\n[TEST] UD-then-next: sent 2nd UD packet, looping TX->RX");
        test_state <= TEST_UD2_LOOP;
        test_count <= 0;
    endrule

    rule do_ud2_loop (test_state == TEST_UD2_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
    endrule

    rule do_ud2_loop_to (test_state == TEST_UD2_LOOP);
        if (test_count > 100) begin
            test_state <= TEST_UD2_WAIT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ud2_wait (test_state == TEST_UD2_WAIT);
        if (test_count > 40) begin
            test_state <= TEST_UD2_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ud2_get (test_state == TEST_UD2_GET);
        DMADataStream rxd <- nic.dma_get_data_stream;
        if (rxd.data[511:480] == 32'h55444F32) begin
            $display("  [PASS] UD-then-next: 2nd UD payload intact (0x%08h) - decap recovered",
                     rxd.data[511:480]);
            pass_count <= pass_count + 1;
            test_state <= TEST_MB_PREP;
            test_count <= 0;
        end
    endrule

    // The timeout condition MUST be in the rule guard: with it in the body
    // the rule fires every cycle in this state and, being ordered above
    // do_ud2_get, suppresses it entirely ("can never fire").
    rule do_ud2_get_to (test_state == TEST_UD2_GET && test_count > 200);
        $display("  [FAIL] UD-then-next: 2nd UD payload not received (decap stuck after the 1st UD packet)");
        fail_count <= fail_count + 1;
        all_pass <= False;
        test_state <= TEST_MB_PREP;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // CNP frame on the wire.
    // Regression: the decap engine kept a per-engine CNP queue that nothing
    // drained, so one CNP with udp_len == 20 filled it and its notFull -
    // conjoined into decap_ingest's guard - disabled the whole RX decap. The
    // packet below is exactly that shape: BTH only, udp_len = 20, so the decap
    // takes the p_len == 0 control path and enqueues the CNP.
    // Asserted via the DCQCN per-QP CNP counter (proves the frame was parsed
    // AND reached the congestion controller). The following QP2 test proves
    // the decap is still alive afterwards.
    // ------------------------------------------------------------------------
    rule do_cnp_rate0 (test_state == TEST_CNP_RATE0);
        Bit#(32) r <- nic.get_dcqcn_rate(0);
        cnp_rate_before <= r;
        test_state <= TEST_CNP_CNT0;
    endrule

    rule do_cnp_cnt0 (test_state == TEST_CNP_CNT0);
        Bit#(16) c0 <- nic.get_dcqcn_cnp_count(0);
        cnp_cnt_before <= c0;
        test_state <= TEST_CNP_INJECT;
    endrule

    rule do_cnp_inject (test_state == TEST_CNP_INJECT);
        // Beat 0: ESUN fragment header (SOLO, no payload)
        MACDataStream hdr;
        hdr.data = 0;
        hdr.data[511:496] = 16'h0002;        // frag_id
        hdr.data[495:493] = 3'b011;          // frag_type = SOLO
        hdr.data[492:488] = 5'h0;            // frag_index
        hdr.data[487:480] = 8'h1;            // total_frags
        hdr.data[479:464] = 16'h0000;        // payload_length = 0
        hdr.data[463:456] = 8'h0;            // llr_seq
        hdr.data[455]     = 1'b0;            // llr_ack_req
        hdr.data[454:448] = 7'h0;
        hdr.keep  = 64'h00000000000000FF;
        hdr.valid = 1;
        hdr.ready = 1;
        hdr.first = 1;
        hdr.last  = 0;
        hdr.error = 0;

        // Beat 1: Ethernet / IPv4 / UDP / BTH(opcode 0xFE, QP0) - last beat
        MACDataStream pkt;
        Bit#(512) d = 0;
        d[511:464] = 48'hAA_BB_CC_DD_EE_01;  // dst MAC = local (pass validation)
        d[463:416] = 48'h11_22_33_44_55_66;  // src MAC
        d[415:400] = 16'h0800;
        d[399:392] = 8'h45;                  // v4, IHL 5
        d[391:384] = 8'h20;                  // DSCP
        d[383:368] = 16'h0028;               // IP total length = 40
        d[367:352] = 16'h0000;
        d[351:336] = 16'h4000;               // DF
        d[335:328] = 8'h40;                  // TTL
        d[327:320] = 8'h11;                  // UDP
        d[319:304] = 16'h0000;
        d[303:272] = 32'hC0A80102;           // src IP
        d[271:240] = 32'hC0A80101;           // dst IP = local
        d[239:224] = 16'h0101;               // src port
        d[223:208] = 16'h12B7;               // 4791
        d[207:192] = 16'h0014;               // udp len = 20 -> p_len == 0
        d[191:176] = 16'h0000;
        d[175:168] = 8'hFE;            // 0xFE
        d[167:164] = 4'h0;
        d[163:160] = 4'h0;
        d[159:152] = 8'h00;
        d[151:136] = 16'hFFFF;               // P_Key
        d[135:134] = 2'b00;
        d[133:132] = 2'b11;                  // B / F
        d[131:108] = 24'h000000;             // PSN
        d[107:84]  = 24'h000000;             // QP 0
        d[83:80]   = 4'h0;
        pkt.data = d;
        pkt.keep = 64'h003FFFFFFFFFFFFF;     // 54 bytes
        pkt.valid = 1;
        pkt.ready = 1;
        pkt.first = 0;
        pkt.last  = 1;                       // whole frame is these 2 beats
        pkt.error = 0;

        Vector#(4, MACDataStream) v4 = replicate(unpack(0));
        v4[0] = hdr;
        v4[1] = pkt;
        inject_vec <= v4;
        inject_count <= 2;
        inject_pos <= 0;
        $display("\n[TEST] CNP injected (opcode 0xFE, udp_len=20, QP0)");
        test_state <= TEST_CNP_WAIT;
        test_count <= 0;
    endrule

    rule do_cnp_wait (test_state == TEST_CNP_WAIT);
        if (test_count > 60) begin
            test_state <= TEST_CNP_RATE1;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_cnp_rate1 (test_state == TEST_CNP_RATE1);
        Bit#(32) r <- nic.get_dcqcn_rate(0);
        cnp_rate_after <= r;
        test_state <= TEST_CNP_CNT1;
    endrule

    rule do_cnp_cnt1 (test_state == TEST_CNP_CNT1);
        Bit#(16) c1 <- nic.get_dcqcn_cnp_count(0);
        if (c1 > cnp_cnt_before) begin
            $display("  [PASS] CNP: processed by DCQCN (cnp_count %d -> %d)",
                     cnp_cnt_before, c1);
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] CNP: cnp_count %d -> %d (frame not processed)",
                     cnp_cnt_before, c1);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_QP2_CREATE;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // Second RC QP (QP2): a second reliable connection sharing the retry
    // buffer, the ACK-clearing path and the DCQCN/LLR machinery with QP0.
    // Runs right after the CNP injection, so a PASS here is also the proof
    // that the decap engine survived the CNP.
    // ------------------------------------------------------------------------
    rule do_qp2_create (test_state == TEST_QP2_CREATE);
        QPContext c2 = unpack(0);
        c2.qp_num       = 2;
        c2.transport    = Transport_RC;
        c2.state        = QPState_RTS;
        c2.send_psn     = 0;
        c2.recv_psn     = 0;
        c2.path_mtu     = 1024;
        c2.remote_qpn   = 3;
        c2.remote_mac   = 48'hAA_BB_CC_DD_EE_01;   // loopback
        c2.remote_ip    = 32'hC0A80101;
        c2.ack_enabled  = 1;
        nic.create_qp(2, c2);
        $display("\n[TEST] QP2 created (RC, loopback) - 2nd RC QP sharing the retry buffer");
        test_state <= TEST_QP2_DRAIN;
        test_count <= 0;
    endrule

    rule do_qp2_drain (test_state == TEST_QP2_DRAIN);
        MACDataStream tb <- nic.mac_tx_snoop;
    endrule

    rule do_qp2_drain_to (test_state == TEST_QP2_DRAIN);
        if (test_count > 200) begin
            test_state <= TEST_QP2_DB;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_qp2_db (test_state == TEST_QP2_DB);
        // Long RTO: this test checks delivery and that the RX path stays
        // alive; a retransmission would only add noise to the loopback.
        nic.reg_write(32'h14000002, 32'hFFF00000, 4'hF);   // set_rto(QP2, huge) - addr[7:0] is the QP
        test_state <= TEST_QP2_DB2;
    endrule

    rule do_qp2_db2 (test_state == TEST_QP2_DB2);
        nic.doorbell(2, 32'h00000102);
        test_state <= TEST_QP2_SEND;
    endrule

    rule do_qp2_send (test_state == TEST_QP2_SEND);
        DMADataStream stream;
        stream.data    = {8'h51, 8'h50, 8'h32, 8'h21, 480'h0};  // "QP2!"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 2;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("[TEST] QP2: sent RC packet (64B), looping TX->RX");
        test_state <= TEST_QP2_LOOP;
        test_count <= 0;
    endrule

    rule do_qp2_loop (test_state == TEST_QP2_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
    endrule

    rule do_qp2_loop_to (test_state == TEST_QP2_LOOP);
        if (test_count > 100) begin
            test_state <= TEST_QP2_WAIT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_qp2_wait (test_state == TEST_QP2_WAIT);
        if (test_count > 40) begin
            test_state <= TEST_QP2_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_qp2_get (test_state == TEST_QP2_GET);
        DMADataStream rxd <- nic.dma_get_data_stream;
        if (rxd.data[511:480] == 32'h51503221) begin
            $display("  [PASS] QP2: 2nd RC QP payload received (0x%08h) - RX alive after the CNP",
                     rxd.data[511:480]);
            pass_count <= pass_count + 1;
            test_state <= TEST_BIG_LLR;
            test_count <= 0;
        end
    endrule

    rule do_qp2_get_to (test_state == TEST_QP2_GET && test_count > 200);
        $display("  [FAIL] QP2: 2nd RC QP payload not received");
        fail_count <= fail_count + 1;
        all_pass <= False;
        test_state <= TEST_BIG_LLR;
        test_count <= 0;
    endrule

    // The remaining two tests are scan-only (nothing is looped back), so their
    // messages would never be LLR-ACKed. Left enabled, the LLR window fills
    // and the timeout retransmit path runs - which is a known-broken area
    // (see README "Open issues") and hangs the sim. These tests target
    // fragmentation and the DMA path, so LLR is switched off here.
    rule do_big_llr (test_state == TEST_BIG_LLR);
        nic.set_esun_llr_enable(False);
        test_state <= TEST_BIG_DB;
    endrule


    // ------------------------------------------------------------------------
    // >2048-byte host TX: 33 full 64-byte beats = 2112 B, which crosses one
    // ESUN fragment boundary (max_frag_size 2048 = 32 beats). tx_frag_total
    // must therefore be 2 and the wire must carry a FRAG_FIRST header whose
    // payload_length is 2048 followed by a FRAG_LAST header whose
    // payload_length is the remaining 64.
    // ------------------------------------------------------------------------
    rule do_big_db (test_state == TEST_BIG_DB);
        nic.set_tx_rdma_op(8'h04, 64'h0, 32'h0);   // SEND_ONLY on QP1 (UD)
        big_idx       <= 0;
        big_bytes     <= 0;
        big_marker_ok <= False;
        test_state <= TEST_BIG_DB2;
    endrule

    rule do_big_db2 (test_state == TEST_BIG_DB2);
        nic.doorbell(1, 32'h00000103);
        test_state <= TEST_BIG_SEND;
    endrule

    // Stream the 33 payload beats, one per cycle.
    rule do_big_send (test_state == TEST_BIG_SEND);
        if (big_idx < 33) begin
            DMADataStream stream;
            stream.data    = {32'hB0000000 + zeroExtend(big_idx), 480'h0};
            stream.keep    = '1;
            stream.valid   = 1;
            stream.ready   = 0;
            stream.first   = (big_idx == 0) ? 1 : 0;
            stream.last    = (big_idx == 32) ? 1 : 0;
            stream.qp_num  = 1;
            stream.dest    = 0;
            stream.reserved = 0;
            nic.dma_data_stream(stream);
            big_idx <= big_idx + 1;
        end else begin
            $display("\n[TEST] BIG: 2112B (33 beats) pushed, looping TX->RX");
            test_state <= TEST_BIG_LOOP;
            test_count <= 0;
        end
    endrule

    // Scan the MAC TX snoop for the two fragment headers, and loop every
    // beat back into RX. The concurrent do_big_rx_drain keeps the host RX
    // stream drained, which is what stops the loopback from backpressuring
    // the MAC (a lesson from the earlier scan-only version of this test).
    rule do_big_loop (test_state == TEST_BIG_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] != pack(ESUN_FRAG_CTRL) &&
            tb.data[487:480] == 8'h02) begin
            if (tb.data[495:493] == pack(ESUN_FRAG_FIRST) &&
                tb.data[479:464] == 16'h0800) begin
                big_first_ok <= True;
            end
            if (tb.data[495:493] == pack(ESUN_FRAG_LAST) &&
                tb.data[479:464] == 16'h0040) begin
                big_last_ok <= True;
            end
        end
    endrule

    // Drain the reassembled payload as the loopback delivers it. Fires only
    // when data is available, so it coexists with the scan rule above.
    rule do_big_rx_drain (test_state == TEST_BIG_LOOP);
        DMADataStream rxd <- nic.dma_get_data_stream;
        big_bytes <= big_bytes + zeroExtend(pack(countOnes(rxd.keep)));
        if (rxd.first == 1 && rxd.data[511:480] == 32'hB0000000) begin
            big_marker_ok <= True;
        end
    endrule




    rule do_big_loop_to (test_state == TEST_BIG_LOOP);
        if (test_count > 300) begin
            test_state <= TEST_BIG_VERDICT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_big_verdict (test_state == TEST_BIG_VERDICT);
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (big_first_ok) begin
            $display("  [PASS] BIG: FRAG_FIRST header seen (total_frags=2, payload_length=2048)");
            p = p + 1;
        end else begin
            $display("  [FAIL] BIG: no FRAG_FIRST header with total_frags=2/payload_length=2048");
            f = f + 1;
        end
        if (big_last_ok) begin
            $display("  [PASS] BIG: FRAG_LAST header seen (total_frags=2, payload_length=64)");
            p = p + 1;
        end else begin
            $display("  [FAIL] BIG: no FRAG_LAST header with total_frags=2/payload_length=64");
            f = f + 1;
        end
        if (big_bytes == 2112) begin
            $display("  [PASS] BIG: reassembled payload = %0d bytes (headers stripped, no pad/iCRC)",
                     big_bytes);
            p = p + 1;
        end else begin
            $display("  [FAIL] BIG: reassembled payload = %0d bytes (expected 2112)", big_bytes);
            f = f + 1;
        end
        if (big_marker_ok) begin
            $display("  [PASS] BIG: first payload beat marker 0xB0000000 intact");
            p = p + 1;
        end else begin
            $display("  [FAIL] BIG: first payload beat marker missing");
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_PBIG_DB;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // PBIG: 144 full 64-byte beats = 9216 B = MAX_PKT_SIZE. This is the exact
    // blind spot of the old encap payload_fifo depth of 128: the payload-first
    // protocol needs the FIFO to hold a WHOLE packet, so beat 129 could never
    // be enqueued, the last beat never arrived, the descriptor was never
    // submitted and the whole TX path wedged in STREAM (the Round-27 CRITICAL
    // fix raised the depth to 160). Reuses the BIG test's registers (its
    // verdict has completed) and harness shape: LLR is off (set by
    // do_big_llr), QP1 is UD push mode.
    // ------------------------------------------------------------------------
    rule do_pbig_db (test_state == TEST_PBIG_DB);
        big_idx        <= 0;
        big_bytes      <= 0;
        big_marker_ok  <= False;
        big_first_ok   <= False;
        big_last_ok    <= False;
        test_state <= TEST_PBIG_DB2;
    endrule

    rule do_pbig_db2 (test_state == TEST_PBIG_DB2);
        nic.doorbell(1, 32'h00000103);
        test_state <= TEST_PBIG_SEND;
        test_count <= 0;
    endrule

    // Stream the 144 payload beats, one per cycle.
    rule do_pbig_send (test_state == TEST_PBIG_SEND);
        if (big_idx < 144) begin
            DMADataStream stream;
            stream.data    = {32'hB1000000 + zeroExtend(big_idx), 480'h0};
            stream.keep    = '1;
            stream.valid   = 1;
            stream.ready   = 0;
            stream.first   = (big_idx == 0) ? 1 : 0;
            stream.last    = (big_idx == 143) ? 1 : 0;
            stream.qp_num  = 1;
            stream.dest    = 0;
            stream.reserved = 0;
            nic.dma_data_stream(stream);
            big_idx <= big_idx + 1;
        end else begin
            $display("\n[TEST] PBIG: 9216B (144 beats) pushed, looping TX->RX");
            test_state <= TEST_PBIG_LOOP;
            test_count <= 0;
        end
    endrule

    // Watchdog for the push itself: if payload_fifo is too small (the
    // regression this test guards), dma_data_stream's notFull stops the
    // send rule and only this tick rule advances - the timeout FAILs
    // instead of hanging the sim.
    rule do_pbig_send_to (test_state == TEST_PBIG_SEND);
        if (test_count > 2000) begin
            Bit#(32) st = nic.get_status;
            $display("  [FAIL] PBIG: 144-beat push wedged (payload_fifo too small?)");
            $display("  [PBIG-DBG] status=%08h tx_state=%0d beats_accepted=%0d",
                     st, st[30:28], big_idx);
            nic.reg_read(32'h12000000);   // TX-stall diagnostic register
            pbig_dbg_pending <= True;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_pbig_dbg_rd if (pbig_dbg_pending);
        Bit#(32) dbg <- nic.reg_get_response;
        $display("  [PBIG-DBG] txpipe=%08h  [7:0]=encap{req_ne,req_nf,pkt_ne,pkt_nf,pay_ne,pay_nf,icrc_ne,out_ne} [8]=pend_ne [9]=buf_nf [10]=hold_v [11]=retx_act [12]=rto_act [13]=ackclr_busy [14]=giveup_pend",
                 dbg);
        pbig_dbg_pending <= False;
        fail_count <= fail_count + 1;
        all_pass <= False;
        test_state <= TEST_DMAMB_DRAIN;
        test_count <= 0;
    endrule

    // Scan the MAC TX snoop for the first/last ESUN fragment headers and loop
    // every data beat back into RX (same shape as the BIG test).
    rule do_pbig_loop (test_state == TEST_PBIG_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] != pack(ESUN_FRAG_CTRL) &&
            tb.data[487:480] == 8'h05) begin
            if (tb.data[495:493] == pack(ESUN_FRAG_FIRST) &&
                tb.data[479:464] == 16'h0800) begin
                big_first_ok <= True;
            end
            if (tb.data[495:493] == pack(ESUN_FRAG_LAST) &&
                tb.data[479:464] == 16'h0400) begin
                big_last_ok <= True;
            end
        end
    endrule

    // Drain the reassembled payload as the loopback delivers it.
    rule do_pbig_rx_drain (test_state == TEST_PBIG_LOOP);
        DMADataStream rxd <- nic.dma_get_data_stream;
        big_bytes <= big_bytes + zeroExtend(pack(countOnes(rxd.keep)));
        if (rxd.first == 1 && rxd.data[511:480] == 32'hB1000000) begin
            big_marker_ok <= True;
        end
    endrule

    rule do_pbig_loop_to (test_state == TEST_PBIG_LOOP);
        if (test_count > 1500) begin
            test_state <= TEST_PBIG_VERDICT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_pbig_verdict (test_state == TEST_PBIG_VERDICT);
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (big_first_ok) begin
            $display("  [PASS] PBIG: FRAG_FIRST header seen (payload_length=2048)");
            p = p + 1;
        end else begin
            $display("  [FAIL] PBIG: no FRAG_FIRST header (payload_length=2048)");
            f = f + 1;
        end
        if (big_last_ok) begin
            $display("  [PASS] PBIG: FRAG_LAST header seen (payload_length=1024)");
            p = p + 1;
        end else begin
            $display("  [FAIL] PBIG: no FRAG_LAST header (payload_length=1024)");
            f = f + 1;
        end
        if (big_bytes == 9216) begin
            $display("  [PASS] PBIG: reassembled payload = 9216 bytes (5 fragments, no pad/iCRC)");
            p = p + 1;
        end else begin
            $display("  [FAIL] PBIG: reassembled payload = %0d bytes (expected 9216)", big_bytes);
            f = f + 1;
        end
        if (big_marker_ok) begin
            $display("  [PASS] PBIG: first payload beat marker 0xB1000000 intact");
            p = p + 1;
        end else begin
            $display("  [FAIL] PBIG: first payload beat marker missing");
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_PPAD_DB;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // PPAD: 66-byte payload (not 4-aligned) - validates the Round-27 PadCount
    // fix. The encap writes pad = (4 - len%4) % 4 = 2 into BTH bits [165:164]
    // (the fix moved the decap's read from the always-zero [167:166] half of
    // the 4-bit truncate(pad16) slice); the looped-back frame must deliver
    // EXACTLY 66 bytes to the host - the old wrong-bit read saw padcnt=0 and
    // leaked the 2 pad bytes into the host stream (68 != 66). Same harness
    // shape as BIG/PBIG: LLR off, QP1 UD push mode, big_* registers reused
    // (PBIG's verdict has completed).
    // ------------------------------------------------------------------------
    rule do_ppad_db (test_state == TEST_PPAD_DB);
        big_idx        <= 0;
        big_bytes      <= 0;
        big_marker_ok  <= False;
        test_state <= TEST_PPAD_DB2;
    endrule

    rule do_ppad_db2 (test_state == TEST_PPAD_DB2);
        nic.doorbell(1, 32'h00000103);
        test_state <= TEST_PPAD_SEND;
        test_count <= 0;
    endrule

    // Stream 66 payload bytes: one full 64B beat + a 2-byte tail beat.
    rule do_ppad_send (test_state == TEST_PPAD_SEND);
        if (big_idx < 2) begin
            DMADataStream stream;
            stream.data    = (big_idx == 0) ? {32'hB2000000, 480'h0}
                                            : {16'hCCDD, 496'h0};
            stream.keep    = (big_idx == 0) ? '1 : 64'h3;
            stream.valid   = 1;
            stream.ready   = 0;
            stream.first   = (big_idx == 0) ? 1 : 0;
            stream.last    = (big_idx == 1) ? 1 : 0;
            stream.qp_num  = 1;
            stream.dest    = 0;
            stream.reserved = 0;
            nic.dma_data_stream(stream);
            big_idx <= big_idx + 1;
        end else begin
            $display("\n[TEST] PPAD: 66B (64+2) pushed, looping TX->RX");
            test_state <= TEST_PPAD_LOOP;
            test_count <= 0;
        end
    endrule

    rule do_ppad_loop (test_state == TEST_PPAD_LOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
    endrule

    rule do_ppad_rx_drain (test_state == TEST_PPAD_LOOP);
        DMADataStream rxd <- nic.dma_get_data_stream;
        big_bytes <= big_bytes + zeroExtend(pack(countOnes(rxd.keep)));
        if (rxd.first == 1 && rxd.data[511:480] == 32'hB2000000)
            big_marker_ok <= True;
    endrule

    rule do_ppad_loop_to (test_state == TEST_PPAD_LOOP);
        if (test_count > 500) begin
            test_state <= TEST_PPAD_VERDICT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_ppad_verdict (test_state == TEST_PPAD_VERDICT);
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (big_bytes == 66) begin
            $display("  [PASS] PPAD: host received exactly 66 bytes (pad=2 honored, no pad leak)");
            p = p + 1;
        end else begin
            $display("  [FAIL] PPAD: host received %0d bytes (expected 66 - padcnt read from the wrong BTH bits?)",
                     big_bytes);
            f = f + 1;
        end
        if (big_marker_ok) begin
            $display("  [PASS] PPAD: first payload beat marker 0xB2000000 intact");
            p = p + 1;
        end else begin
            $display("  [FAIL] PPAD: first payload beat marker missing");
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_DMAMB_DRAIN;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // 192-byte DMA read (3 beats) driven through the DMA read path - not the
    // host push path the multi-beat test above uses - so gen_byte_en is
    // exercised for a multi-beat read.
    // ------------------------------------------------------------------------
    rule do_dmamb_drain (test_state == TEST_DMAMB_DRAIN);
        MACDataStream tb <- nic.mac_tx_snoop;
    endrule

    rule do_dmamb_drain_to (test_state == TEST_DMAMB_DRAIN);
        if (test_count > 200) begin
            test_state <= TEST_DMAMB_DB;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // QP1 (UD, no host SQ base) so the doorbell takes the push path, not the
    // WQE fetch path that the earlier WQE test configured on QP0.
    rule do_dmamb_db (test_state == TEST_DMAMB_DB);
        nic.doorbell(1, 32'h00000104);
        test_state <= TEST_DMAMB_REQ;
    endrule

    rule do_dmamb_req (test_state == TEST_DMAMB_REQ);
        DMARequest rreq;
        rreq.qp_num     = 0;
        rreq.req_type   = 0;                 // Read
        rreq.is_doorbell = 0;
        rreq.reserved   = 0;
        rreq.addr       = 64'h0000000000001000;
        rreq.length     = 32'd192;           // 3 beats
        rreq.lkey       = 0;
        rreq.wr_id      = 0;
        nic.dma_request(rreq);
        $display("\n[TEST] DMA multi-beat read: 192B (3 beats)");
        test_state <= TEST_DMAMB_RESP;
        test_count <= 0;
    endrule

    // ONE response PER BEAT (the engine dequeues a response per 64-byte
    // beat). Each beat carries a distinctive marker in its LAST 8 bytes
    // (data[63:0] = 0xE0E0.. / 0xE1E1.. / 0xE2E2..) so the snoop below can
    // verify the beats are streamed in order with per-beat data - the old
    // one-response-for-all-beats convention repeated beat 0's data and the
    // wire checks never looked at content.
    rule do_dmamb_resp (test_state == TEST_DMAMB_RESP);
        if (dmamb_resp_beat < 3) begin
            DMAResponse resp;
            resp.qp_num   = 0;
            resp.success  = 1;
            resp.is_read  = 1;
            resp.reserved = 0;
            resp.addr     = 64'h0000000000001000 +
                            ((dmamb_resp_beat == 0) ? 64'h0000 :
                             (dmamb_resp_beat == 1) ? 64'h0040 :
                                                      64'h0080);
            resp.length   = 32'd64;
            resp.wr_id    = 0;
            Bit#(64) beat_marker =
                            (dmamb_resp_beat == 0) ? 64'hE0E0E0E0E0E0E0E0 :
                            (dmamb_resp_beat == 1) ? 64'hE1E1E1E1E1E1E1E1 :
                                                     64'hE2E2E2E2E2E2E2E2;
            resp.data     = {448'h0, beat_marker};
            resp.byte_en  = '1;
            nic.dma_response(resp);
            if (dmamb_resp_beat == 2) test_state <= TEST_DMAMB_SNOOP;
            dmamb_resp_beat <= dmamb_resp_beat + 1;
        end
    endrule

    rule do_dmamb_snoop (test_state == TEST_DMAMB_SNOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (tb.keep == 64'h00000000000000FF &&
            tb.data[495:493] != pack(ESUN_FRAG_CTRL) &&
            tb.data[479:464] == 16'h00C0) begin      // payload_length = 192
            dma_mb_ok <= True;
        end else if (dma_mb_ok && tb.keep == 64'hFFFFFFFFFFFFFFFF) begin
            // The ESUN header is its own beat (keep=0xFF); the packet's
            // payload beats follow unshifted, one 64B DMA beat per beat.
            // DMA beat k's tail marker (its bytes 56..63 = data[63:0])
            // therefore appears as the k-th full-keep beat's data[63:0].
            Bit#(64) marker_want = (dmamb_data_ok == 0) ? 64'hE0E0E0E0E0E0E0E0 :
                                   (dmamb_data_ok == 1) ? 64'hE1E1E1E1E1E1E1E1 :
                                                          64'hE2E2E2E2E2E2E2E2;
            if (tb.data[63:0] == marker_want)
                dmamb_data_ok <= dmamb_data_ok + 1;
        end
    endrule

    // Tick: without this neither rule fires when the snoop is momentarily
    // empty, so test_count would never advance and the verdict never runs.
    rule do_dmamb_tick (test_state == TEST_DMAMB_SNOOP && test_count <= 150);
        test_count <= test_count + 1;
    endrule

    rule do_dmamb_verdict (test_state == TEST_DMAMB_SNOOP && test_count > 150);
        if (dma_mb_ok && dmamb_data_ok == 3) begin
            $display("  [PASS] DMA multi-beat read: all 192 bytes reached the wire, per-beat data verified (3/3 markers in order)");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] DMA multi-beat read: length ok=%b, per-beat markers %0d/3 (beats repeated or dropped)",
                     dma_mb_ok, dmamb_data_ok);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_DB2_DB1;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // Doorbells rung while TX is busy. A 4-beat packet is streaming; two more
    // doorbells are rung while the FSM is in STREAM, then their payloads are
    // pushed. With the old register+flag channel the second ring overwrote the
    // first, so one of the two packets was silently lost. All three payloads
    // must reach the wire.
    // ------------------------------------------------------------------------
    rule do_db2_db1 (test_state == TEST_DB2_DB1);
        nic.doorbell(1, 32'h00000201);
        db2_idx <= 0;
        $display("\n[TEST] DB2: doorbell for a 4-beat packet, then 2 rings while TX is busy");
        test_state <= TEST_DB2_PUSH1;
    endrule

    rule do_db2_push1 (test_state == TEST_DB2_PUSH1);
        if (db2_idx < 4) begin
            DMADataStream stream;
            stream.data    = {32'hD1D1D1D1, 480'h0};
            stream.keep    = '1;
            stream.valid   = 1;
            stream.ready   = 0;
            stream.first   = (db2_idx == 0) ? 1 : 0;
            stream.last    = (db2_idx == 3) ? 1 : 0;
            stream.qp_num  = 1;
            stream.dest    = 0;
            stream.reserved = 0;
            nic.dma_data_stream(stream);
            db2_idx <= db2_idx + 1;
        end else begin
            test_state <= TEST_DB2_RING1;
        end
    endrule

    // TX is in STREAM here: neither ring is consumed yet.
    rule do_db2_ring1 (test_state == TEST_DB2_RING1);
        nic.doorbell(1, 32'h00000202);
        test_state <= TEST_DB2_RING2;
    endrule

    rule do_db2_ring2 (test_state == TEST_DB2_RING2);
        nic.doorbell(1, 32'h00000203);
        test_state <= TEST_DB2_WAIT;
        test_count <= 0;
    endrule

    // Let the 4-beat packet drain and the FSM return to IDLE; the two queued
    // rings are then consumed one at a time.
    rule do_db2_wait (test_state == TEST_DB2_WAIT);
        if (test_count > 80) begin
            test_state <= TEST_DB2_PUSH2;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_db2_push2 (test_state == TEST_DB2_PUSH2);
        DMADataStream stream;
        stream.data    = {32'hE2E2E2E2, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        test_state <= TEST_DB2_WAIT2;
        test_count <= 0;
    endrule

    rule do_db2_wait2 (test_state == TEST_DB2_WAIT2);
        if (test_count > 80) begin
            test_state <= TEST_DB2_PUSH3;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_db2_push3 (test_state == TEST_DB2_PUSH3);
        DMADataStream stream;
        stream.data    = {32'hE3E3E3E3, 480'h0};
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 1;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        test_state <= TEST_DB2_SNOOP;
        test_count <= 0;
    endrule

    rule do_db2_snoop (test_state == TEST_DB2_SNOOP);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (tb.keep == 64'hFFFFFFFFFFFFFFFF) begin
            if (tb.data[511:480] == 32'hD1D1D1D1) db2_m1 <= True;
            if (tb.data[511:480] == 32'hE2E2E2E2) db2_m2 <= True;
            if (tb.data[511:480] == 32'hE3E3E3E3) db2_m3 <= True;
        end
    endrule

    // Tick: without it neither rule fires while the snoop is empty.
    rule do_db2_tick (test_state == TEST_DB2_SNOOP && test_count <= 150);
        test_count <= test_count + 1;
    endrule

    rule do_db2_verdict (test_state == TEST_DB2_SNOOP && test_count > 150);
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (db2_m1) begin
            $display("  [PASS] DB2: the 4-beat packet's payload reached the wire (0xD1D1D1D1)");
            p = p + 1;
        end else begin
            $display("  [FAIL] DB2: the 4-beat packet's payload missing");
            f = f + 1;
        end
        if (db2_m2) begin
            $display("  [PASS] DB2: 2nd ring's packet delivered (0xE2E2E2E2)");
            p = p + 1;
        end else begin
            $display("  [FAIL] DB2: 2nd ring's packet missing (doorbell overwritten)");
            f = f + 1;
        end
        if (db2_m3) begin
            $display("  [PASS] DB2: 3rd ring's packet delivered (0xE3E3E3E3)");
            p = p + 1;
        end else begin
            $display("  [FAIL] DB2: 3rd ring's packet missing (doorbell overwritten)");
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_MQP_LLR;
        test_count <= 0;
    endrule

    // ------------------------------------------------------------------------
    // Multi-QP: QP0 and QP2 each send one packet through the loopback, so both
    // retry-buffer entries must be cleared by their ACKs. The assertion is a
    // delta on rc_retransmits (an earlier test deliberately triggers one).
    // ------------------------------------------------------------------------
    rule do_mqp_llr (test_state == TEST_MQP_LLR);
        nic.set_esun_llr_enable(False);   // scan-only: no ACKs would come
        test_state <= TEST_MQP_DB0;
    endrule

    rule do_mqp_db0 (test_state == TEST_MQP_DB0);
        nic.reg_read(32'h03000000);          // rc_retransmits baseline
        test_state <= TEST_MQP_RD0;
    endrule

    rule do_mqp_rd0_get (test_state == TEST_MQP_RD0);
        Bit#(32) b <- nic.reg_get_response;
        mqp_base <= b;
        test_state <= TEST_MQP_DB0B;
    endrule

    rule do_mqp_db0b (test_state == TEST_MQP_DB0B);
        nic.doorbell(0, 32'h00000201);
        test_state <= TEST_MQP_PUSH0;
    endrule

    rule do_mqp_push0 (test_state == TEST_MQP_PUSH0);
        DMADataStream stream;
        stream.data    = {32'h4D513030, 480'h0};   // "MQ00"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("\n[TEST] MQP: QP0 packet sent");
        test_state <= TEST_MQP_LOOP0;
        test_count <= 0;
    endrule

    rule do_mqp_loop0 (test_state == TEST_MQP_LOOP0);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
        if (tb.keep == 64'hFFFFFFFFFFFFFFFF &&
            tb.data[511:480] == 32'h4D513030) begin
            mqp_m0 <= True;
        end
    endrule

    rule do_mqp_loop0_to (test_state == TEST_MQP_LOOP0 && test_count > 120);
        test_state <= TEST_MQP_DB2;
        test_count <= 0;
    endrule

    rule do_mqp_tick0 (test_state == TEST_MQP_LOOP0 && test_count <= 120);
        test_count <= test_count + 1;
    endrule

    rule do_mqp_db2 (test_state == TEST_MQP_DB2);
        nic.doorbell(2, 32'h00000202);
        test_state <= TEST_MQP_PUSH2;
    endrule

    rule do_mqp_push2 (test_state == TEST_MQP_PUSH2);
        DMADataStream stream;
        stream.data    = {32'h4D513232, 480'h0};   // "MQ22"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 2;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        $display("[TEST] MQP: QP2 packet sent");
        test_state <= TEST_MQP_LOOP2;
        test_count <= 0;
    endrule

    rule do_mqp_loop2 (test_state == TEST_MQP_LOOP2);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
        if (tb.keep == 64'hFFFFFFFFFFFFFFFF &&
            tb.data[511:480] == 32'h4D513232) begin
            mqp_m2 <= True;
        end
    endrule

    rule do_mqp_loop2_to (test_state == TEST_MQP_LOOP2 && test_count > 120);
        nic.reg_read(32'h03000000);          // rc_retransmits after
        test_state <= TEST_MQP_RD1;
        test_count <= 0;
    endrule

    rule do_mqp_tick2 (test_state == TEST_MQP_LOOP2 && test_count <= 120);
        test_count <= test_count + 1;
    endrule

    rule do_mqp_rd1 (test_state == TEST_MQP_RD1);
        Bit#(32) v <- nic.reg_get_response;
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (mqp_m0) begin
            $display("  [PASS] MQP: QP0 payload reached the wire (0x4D513030)");
            p = p + 1;
        end else begin
            $display("  [FAIL] MQP: QP0 payload missing");
            f = f + 1;
        end
        if (mqp_m2) begin
            $display("  [PASS] MQP: QP2 payload reached the wire (0x4D513232)");
            p = p + 1;
        end else begin
            $display("  [FAIL] MQP: QP2 payload missing");
            f = f + 1;
        end
        // The NAK-driven retransmission (R3) makes a zero delta impossible
        // in this loopback: the packets' PSNs mismatch the receiver's
        // expectation forever, so every looped NAK legitimately triggers a
        // replay. What must hold is a BOUND: no unbounded retransmission
        // storm during the test window (the RTO give-up budget and the
        // bounded loop window cap it).
        if (v >= mqp_base && v - mqp_base <= 8) begin
            $display("  [PASS] MQP: retransmissions bounded (count=%0d, delta=%0d)",
                     v, v - mqp_base);
            p = p + 1;
        end else begin
            $display("  [FAIL] MQP: rc_retransmits %0d -> %0d (unbounded storm)",
                     mqp_base, v);
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_STATUS_CHECK;
        test_count <= 0;
    endrule

    rule do_status (test_state == TEST_STATUS_CHECK);
        Bit#(32) status = nic.get_status;
        $display("\n[TEST] Status: 0x%08h", status);
        $display("  TX state=%d, RX state=%d, Active QPs=%d",
                 status[30:28], status[26:24], status[7:0]);

        if (status[7:0] >= 1)
            pass_count <= pass_count + 1;
        else begin
            fail_count <= fail_count + 1;
            all_pass <= False;
        end

        test_state <= TEST_RR_SET;
    endrule

    // ------------------------------------------------------------------------
    // READ REQ round trip (R8 initiator + responder): a WQE with opcode 0x0A
    // produces a header-only RETH packet (BTH + RETH + iCRC, no payload), the
    // loopback delivers it to the responder, which DMA-reads local memory and
    // answers with a READ RESPONSE; the initiator consumes it. Regression
    // guard: the no_payload encap path previously wedged the encap engine
    // (pkt_fifo never dequeued), deadlocking TX and RX on the first READ REQ.
    // ------------------------------------------------------------------------
    rule do_rr_set (test_state == TEST_RR_SET);
        nic.set_wqe_sq_base(0, 64'h0000000000004000);
        nic.reg_read(32'h04000000);          // rdma_read_resps baseline
        test_state <= TEST_RR_BASE;
    endrule

    rule do_rr_base (test_state == TEST_RR_BASE);
        Bit#(32) b <- nic.reg_get_response;
        rr_base <= b;
        nic.doorbell(0, 32'h00000000);
        $display("\n[TEST] RR: doorbell QP0 (READ REQ WQE, rdma_read_resps base=%0d)",
                 b);
        test_state <= TEST_RR_WQE;
        test_count <= 0;
    endrule

    // Respond with the 64-byte WQE: opcode=0x0A (RDMA READ REQ), dma_len=64,
    // remote_addr=0x1000 (the responder's local buffer), rkey=0x1234,
    // buffer_addr=0x6000 (where the initiator wants the data written).
    rule do_rr_wqe (test_state == TEST_RR_WQE);
        if (test_count > 6) begin
            DMAResponse wqe_resp;
            wqe_resp.qp_num   = 0;
            wqe_resp.success  = 1;
            wqe_resp.is_read  = 1;
            wqe_resp.reserved = 0;
            wqe_resp.addr     = 64'h0000000000004000;
            wqe_resp.length   = 32'd64;
            wqe_resp.wr_id    = 0;
            wqe_resp.data     = 0;
            wqe_resp.data[511:504] = 8'h0A;                       // READ REQ
            wqe_resp.data[479:448] = 32'h00000040;            // dma_len=64
            wqe_resp.data[447:384] = 64'h0000000000001000;    // remote va
            wqe_resp.data[383:352] = 32'h00001234;            // rkey
            wqe_resp.data[319:256] = 64'h0000000000006000;    // local buffer
            wqe_resp.data[255:192] = 64'h000000000000BEEF;    // wr_id
            wqe_resp.byte_en = '1;
            nic.dma_response(wqe_resp);
            $display("  [RR] host returned READ REQ WQE descriptor");
            test_state <= TEST_RR_REFUSE_DB;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    // --- Refusal regression (Round 27 fix 6): a SECOND READ REQ WQE while
    // the first initiator read is outstanding must be refused AND post an
    // error CQE - the WQE was consumed from the SQ, so without the CQE that
    // wr_id leaks (its completion never arrives). Before the fix the
    // refusal branch only skipped the STREAM state.
    rule do_rr_refuse_db (test_state == TEST_RR_REFUSE_DB);
        if (test_count > 12) begin
            nic.doorbell(0, 32'h00000001);
            test_state <= TEST_RR_REFUSE_WQE;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_rr_refuse_wqe (test_state == TEST_RR_REFUSE_WQE);
        if (test_count > 6) begin
            DMAResponse wqe2;
            wqe2.qp_num   = 0;
            wqe2.success  = 1;
            wqe2.is_read  = 1;
            wqe2.reserved = 0;
            wqe2.addr     = 64'h0000000000004040;   // sq_base + 1<<6
            wqe2.length   = 32'd64;
            wqe2.wr_id    = 0;
            wqe2.data     = 0;
            wqe2.data[511:504] = 8'h0A;                       // READ REQ
            wqe2.data[479:448] = 32'h00000040;
            wqe2.data[447:384] = 64'h0000000000001000;
            wqe2.data[383:352] = 32'h00001234;
            wqe2.data[319:256] = 64'h0000000000006000;
            wqe2.data[255:192] = 64'h000000000000CAFE;        // wr_id
            wqe2.byte_en = '1;
            nic.dma_response(wqe2);
            $display("  [RR] host returned 2nd READ REQ WQE (wr_id=0xCAFE, expect refusal CQE)");
            test_state <= TEST_RR_SCAN;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    Reg#(Bool)     rr_refuse_ok <- mkReg(False);
    Reg#(Bool)     rr_refuse_status_ok <- mkReg(False);

    rule do_rr_scan (test_state == TEST_RR_SCAN);
        let cqe <- nic.get_cqe(0);
        if (cqe.wr_id == 64'h000000000000CAFE) begin
            rr_refuse_ok <= True;
            if (cqe.status == zeroExtend(pack(CQE_LOC_PROT_ERR)))
                rr_refuse_status_ok <= True;
        end
    endrule

    rule do_rr_scan_tick (test_state == TEST_RR_SCAN && !rr_refuse_ok &&
                          test_count <= 100);
        test_count <= test_count + 1;
    endrule

    rule do_rr_scan_verdict (test_state == TEST_RR_SCAN &&
                             (rr_refuse_ok || test_count > 100));
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (rr_refuse_ok) begin
            $display("  [PASS] RR: refused READ REQ posted error CQE (wr_id=0xCAFE)");
            p = p + 1;
        end else begin
            $display("  [FAIL] RR: refused READ REQ wr_id=0xCAFE not found in CQ0 (wr_id leaks)");
            f = f + 1;
        end
        if (rr_refuse_status_ok) begin
            $display("  [PASS] RR: refusal CQE status = CQE_LOC_PROT_ERR");
            p = p + 1;
        end else begin
            $display("  [FAIL] RR: refusal CQE status != CQE_LOC_PROT_ERR");
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_RR_FAKE;
        test_count <= 0;
    endrule

    // --- rd_ini_qp QP-match regression (Round 27 fix 3): an inbound READ
    // RESPONSE addressed to a DIFFERENT QP must NOT complete the outstanding
    // initiator read (the old code matched on rd_ini_pending alone - the
    // fake response's payload was written to rd_ini_addr and the pending
    // flag was falsely cleared, so the REAL response was later refused and
    // its data lost). The fake QP2 response is delivered as an ordinary
    // host receive (designed behavior for an unsolicited response); the
    // pending flag must survive it.
    rule do_rr_fake (test_state == TEST_RR_FAKE);
        if (inject_count == 0) begin
            MACDataStream hdr_beat;
            hdr_beat.data = 0;
            hdr_beat.data[511:496] = 16'h0005;
            hdr_beat.data[495:493] = 3'b011;   // SOLO
            hdr_beat.data[487:480] = 8'h1;
            hdr_beat.data[479:464] = 16'h0016; // payload 22 (BTH+AETH+6B)
            hdr_beat.data[463:456] = 8'h45;   // llr_seq (continues 0x44)
            hdr_beat.data[455]     = 1'b1;
            hdr_beat.keep  = 64'h00000000000000FF;
            hdr_beat.valid = 1; hdr_beat.ready = 1;
            hdr_beat.first = 1; hdr_beat.last = 0; hdr_beat.error = 0;

            MACDataStream fk_pkt;
            Bit#(512) pkt_data = 0;
            pkt_data[511:464] = 48'hAA_BB_CC_DD_EE_01;
            pkt_data[463:416] = 48'h11_22_33_44_55_66;
            pkt_data[415:400] = 16'h0800;
            pkt_data[399:392] = 8'h45;
            pkt_data[383:368] = 16'h0038;  // IP total = 56
            pkt_data[327:320] = 8'h11;
            pkt_data[303:272] = 32'hC0A80102;
            pkt_data[271:240] = 32'hC0A80101;
            pkt_data[223:208] = 16'h12B7;
            pkt_data[207:192] = 16'h0022;  // UDP len = 34
            pkt_data[175:168] = 8'h0D;     // READ RSP LAST
            pkt_data[131:108] = 24'h000000;
            pkt_data[107:84]  = 24'h000002;  // dst QP = 2 (NOT rd_ini_qp)
            pkt_data[79:48]   = 32'h00000000; // AETH: syndrome 0, msn 0
            pkt_data[47:0]    = 48'h515151515151;  // payload bytes 58..63
            fk_pkt.data   = pkt_data;
            fk_pkt.keep   = 64'hFFFFFFFFFFFFFFFF;
            fk_pkt.valid  = 1; fk_pkt.ready = 1;
            fk_pkt.first  = 0; fk_pkt.last = 0; fk_pkt.error = 0;

            // iCRC over packet bytes 42..63 (BTH+AETH + the 6 tail bytes
            // folded by the header-beat forward).
            Bit#(32) fk_c = 32'hFFFFFFFF;
            for (Integer i = 0; i < 22; i = i + 1)
                fk_c = tb_crc32c_byte(fk_pkt.data[175 - 8*i : 168 - 8*i], fk_c);
            MACDataStream fk_b1;
            fk_b1.data = 0;
            fk_b1.data[511:480] = fk_c ^ 32'hFFFFFFFF;
            fk_b1.keep  = 64'h000000000000000F;
            fk_b1.valid = 1; fk_b1.ready = 1;
            fk_b1.first = 0; fk_b1.last = 1; fk_b1.error = 0;

            Vector#(4, MACDataStream) v4 = replicate(unpack(0));
            v4[0] = hdr_beat;
            v4[1] = fk_pkt;
            v4[2] = fk_b1;
            inject_vec <= v4;
            inject_count <= 3;
            inject_pos <= 0;
            $display("\n[TEST] RR: inject fake QP2 READ RSP (pending must survive)");
            test_state <= TEST_RR_FAKE_PEND;
            test_count <= 0;
        end
    endrule

    rule do_rr_fake_pend (test_state == TEST_RR_FAKE_PEND);
        if (test_count > 100) begin
            nic.reg_read(32'h0F000000);   // rd_ini_pending
            test_state <= TEST_RR_FAKE_RD;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_rr_fake_rd (test_state == TEST_RR_FAKE_RD);
        Bit#(32) v <- nic.reg_get_response;
        if (v == 1) begin
            $display("  [PASS] RR: rd_ini_pending survived the foreign-QP response (reg 0x0F = 1)");
            pass_count <= pass_count + 1;
        end else begin
            $display("  [FAIL] RR: rd_ini_pending cleared by the foreign-QP response (reg 0x0F = %0d)",
                     v);
            fail_count <= fail_count + 1;
            all_pass <= False;
        end
        test_state <= TEST_RR_MEM;
        test_count <= 0;
    endrule

    // Loopback: echo the READ REQ frame (and later the READ RESPONSE) back
    // into the RX MAC. ESUN CTRL frames are not injected (scan-only, as in
    // the MQP test). Active across the whole round trip.
    rule do_rr_loop (test_state == TEST_RR_MEM || test_state == TEST_RR_WAIT);
        MACDataStream tb <- nic.mac_tx_snoop;
        if (!(tb.keep == 64'h00000000000000FF &&
              tb.data[495:493] == pack(ESUN_FRAG_CTRL))) begin
            nic.mac_rx_inject(tb);
        end
    endrule

    // Drain the host RX data stream: earlier tests left beats in the depth-2
    // rx_stream_fifo, and a full FIFO's implicit condition silently blocks
    // the whole rx_decap_pump rule (no result would ever be consumed).
    rule do_rr_rxdrain (test_state == TEST_RR_SET || test_state == TEST_RR_BASE ||
                        test_state == TEST_RR_WQE || test_state == TEST_RR_MEM ||
                        test_state == TEST_RR_REFUSE_DB ||
                        test_state == TEST_RR_REFUSE_WQE ||
                        test_state == TEST_RR_SCAN ||
                        test_state == TEST_RR_FAKE ||
                        test_state == TEST_RR_FAKE_PEND ||
                        test_state == TEST_RR_FAKE_RD ||
                        test_state == TEST_RR_WAIT || test_state == TEST_RR_GET);
        let d <- nic.dma_get_data_stream;
    endrule

    // Respond to the responder's local-memory DMA read (the RETH va=0x1000,
    // 64 bytes) with a recognizable pattern.
    rule do_rr_mem (test_state == TEST_RR_MEM);
        if (test_count > 60) begin
            DMAResponse mem_resp;
            mem_resp.qp_num   = 0;
            mem_resp.success  = 1;
            mem_resp.is_read  = 1;
            mem_resp.reserved = 0;
            mem_resp.addr     = 64'h0000000000001000;
            mem_resp.length   = 32'd64;
            mem_resp.wr_id    = 0;
            mem_resp.data     = 0;
            for (Integer i = 0; i < 8; i = i + 1)
                mem_resp.data[511 - 64 * i : 448 - 64 * i] =
                    {32'h0, 8'h52, 8'h44, 8'h0A, 8'h00};   // "RD." marker
            mem_resp.byte_en = '1;
            nic.dma_response(mem_resp);
            $display("  [RR] host returned responder local memory (64B)");
            test_state <= TEST_RR_WAIT;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_rr_wait (test_state == TEST_RR_WAIT);
        if (test_count > 120) begin
            nic.reg_read(32'h04000000);
            test_state <= TEST_RR_GET;
            test_count <= 0;
        end else begin
            test_count <= test_count + 1;
        end
    endrule

    rule do_rr_get (test_state == TEST_RR_GET);
        Bit#(32) v <- nic.reg_get_response;
        Bit#(32) status = nic.get_status;
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (v == rr_base + 1) begin
            $display("  [PASS] RR: READ REQ answered by one READ RESPONSE (%0d -> %0d)",
                     rr_base, v);
            p = p + 1;
        end else begin
            $display("  [FAIL] RR: rdma_read_resps %0d -> %0d (expected +1)",
                     rr_base, v);
            f = f + 1;
        end
        if (status[30:28] == 0) begin
            $display("  [PASS] RR: TX FSM back to IDLE (no encap wedge)");
            p = p + 1;
        end else begin
            $display("  [FAIL] RR: TX FSM stuck in state %0d", status[30:28]);
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_LLRTO_SET;
    endrule

    // SECOND initiator READ: the first response's last beat (its iCRC beat,
    // byte_en 0) must have cleared rd_ini_pending. The clear used to live
    // behind a byte_en != 0 gate - unreachable dead code, so rd_ini_pending
    // latched True after the FIRST initiator READ and every later READ REQ
    // WQE was silently rejected (tx_skip_stream). Without the fix this round
    // produces no response and the +1 assertion below fails.
    // ------------------------------------------------------------------------
    // LLR give-up regression (R13/E13): enable LLR with a 100-cycle timeout,
    // send one packet that is NEVER acknowledged (no loopback), and let the
    // retransmission timer exhaust the retry budget. Expected: 7 replayed
    // retransmissions, then exactly ONE give-up (retry_dropped, sticky
    // llr_link_error, retx_base + 1), and the timer DISARMED because the
    // window is now empty - llr_timeouts and llr_retransmits must be stable
    // across a second wait window. The pre-fix code re-armed the timer on the
    // empty window and dropped phantom messages forever.
    // ------------------------------------------------------------------------
    rule do_llrto_set (test_state == TEST_LLRTO_SET);
        nic.set_esun_llr_enable(True);
        test_state <= TEST_LLRTO_CFG;
    endrule

    rule do_llrto_cfg (test_state == TEST_LLRTO_CFG);
        nic.set_llr_timeout(100);
        // Reset the push-mode descriptor registers: the WQE-driven READ REQ
        // test left tx_opcode=0x0A/tx_is_rdma=1 behind, which would turn this
        // test's plain SEND into a READ REQ (the same leftover-state trap the
        // UD test hit).
        nic.set_tx_rdma_op(8'h04, 64'h0, 32'h0);
        test_state <= TEST_LLRTO_BASE;
    endrule

    rule do_llrto_base (test_state == TEST_LLRTO_BASE);
        nic.set_wqe_sq_base(0, 0);          // back to push mode for QP0
        llrto_base <= nic.get_llr_retx_base;
        test_state <= TEST_LLRTO_TO0;
    endrule

    rule do_llrto_to0 (test_state == TEST_LLRTO_TO0);
        nic.reg_read(32'h80000014);         // llr_timeouts baseline
        test_state <= TEST_LLRTO_PUSH;
    endrule

    rule do_llrto_push (test_state == TEST_LLRTO_PUSH);
        let to0v <- nic.reg_get_response; llrto_to0 <= to0v;
        test_state <= TEST_LLRTO_PUSHB;
    endrule

    rule do_llrto_pushb (test_state == TEST_LLRTO_PUSHB);
        nic.reg_read(32'h80000010);         // llr_retransmits baseline
        test_state <= TEST_LLRTO_SND;
    endrule

    rule do_llrto_snd (test_state == TEST_LLRTO_SND);
        let rt0v <- nic.reg_get_response; llrto_rt0 <= rt0v;
        test_state <= TEST_LLRTO_PUSH2;
    endrule

    rule do_llrto_push2 (test_state == TEST_LLRTO_PUSH2);
        nic.doorbell(0, 32'h00000000);
        $display("\n[TEST] LLRTO: QP0 packet sent (no ACKs; timeout=100, retx_base=%0d)",
                 llrto_base);
        test_state <= TEST_LLRTO_PUSH3;
    endrule

    rule do_llrto_push3 (test_state == TEST_LLRTO_PUSH3);
        DMADataStream stream;
        stream.data    = {32'h4C543030, 480'h0};   // "LT00"
        stream.keep    = '1;
        stream.valid   = 1;
        stream.ready   = 0;
        stream.first   = 1;
        stream.last    = 1;
        stream.qp_num  = 0;
        stream.dest    = 0;
        stream.reserved = 0;
        nic.dma_data_stream(stream);
        test_state <= TEST_LLRTO_WAIT1;
        test_count <= 0;
    endrule

    // No loopback injection: the packet is never ACKed. The snoop FIFO
    // absorbs the original frame plus 7 replays (~24 beats, capacity 256).
    // WAIT1 must outlast the LLR churn of messages created by late
    // NAK-triggered RC replays from earlier loopback tests (each replay is
    // cached as a NEW LLR message with a 7x100 budget, and the single LLR
    // timer serializes their give-ups) - the disarm observation below
    // requires a QUIET window.
    rule do_llrto_tick1 (test_state == TEST_LLRTO_WAIT1 && test_count <= 15000);
        test_count <= test_count + 1;
    endrule

    rule do_llrto_wait1 (test_state == TEST_LLRTO_WAIT1 && test_count > 15000);
        nic.reg_read(32'h80000014);         // llr_timeouts after give-up
        test_state <= TEST_LLRTO_TO1;
        test_count <= 0;
    endrule

    rule do_llrto_to1 (test_state == TEST_LLRTO_TO1);
        let to1v <- nic.reg_get_response; llrto_to1 <= to1v;
        test_state <= TEST_LLRTO_TO1B;
    endrule

    rule do_llrto_to1b (test_state == TEST_LLRTO_TO1B);
        nic.reg_read(32'h80000010);         // llr_retransmits
        test_state <= TEST_LLRTO_RT1;
    endrule

    rule do_llrto_rt1 (test_state == TEST_LLRTO_RT1);
        let rt1v <- nic.reg_get_response; llrto_rt1 <= rt1v;
        test_state <= TEST_LLRTO_CAP1;
    endrule

    rule do_llrto_cap1 (test_state == TEST_LLRTO_CAP1);
        test_state <= TEST_LLRTO_WAIT2;
        test_count <= 0;
    endrule

    // WAIT2 must outlast the give-up budgets of LLR messages created by
    // late NAK-triggered RC replays (a bounded trickle from earlier loopback
    // tests; each replay is cached as a NEW LLR message with a 7x100 budget,
    // and with the honest dup-ACK semantics the window is no longer freed
    // prematurely, so the churn runs its full budget).
    rule do_llrto_tick2 (test_state == TEST_LLRTO_WAIT2 && test_count <= 20000);
        test_count <= test_count + 1;
    endrule

    rule do_llrto_wait2 (test_state == TEST_LLRTO_WAIT2 && test_count > 20000);
        nic.reg_read(32'h80000014);
        test_state <= TEST_LLRTO_TO2;
        test_count <= 0;
    endrule

    rule do_llrto_to2 (test_state == TEST_LLRTO_TO2);
        let to2v <- nic.reg_get_response; llrto_to2 <= to2v;
        test_state <= TEST_LLRTO_TO2B;
    endrule

    rule do_llrto_to2b (test_state == TEST_LLRTO_TO2B);
        nic.reg_read(32'h80000010);
        test_state <= TEST_LLRTO_RT2;
    endrule

    rule do_llrto_rt2 (test_state == TEST_LLRTO_RT2);
        let rt2v <- nic.reg_get_response; llrto_rt2 <= rt2v;
        test_state <= TEST_LLRTO_VERDICT;
    endrule

    rule do_llrto_verdict (test_state == TEST_LLRTO_VERDICT);
        Bit#(32) dropped = nic.get_llr_retry_dropped;
        Bool     link_err = nic.get_llr_link_error;
        Bit#(8)  base_now = nic.get_llr_retx_base;
        Bit#(32) p = 0;
        Bit#(32) f = 0;
        if (dropped >= 1) begin
            $display("  [PASS] LLRTO: message given up after retry budget (dropped=%0d)",
                     dropped);
            p = p + 1;
        end else begin
            $display("  [FAIL] LLRTO: no give-up recorded (dropped=%0d)", dropped);
            f = f + 1;
        end
        if (link_err) begin
            $display("  [PASS] LLRTO: sticky llr_link_error set");
            p = p + 1;
        end else begin
            $display("  [FAIL] LLRTO: llr_link_error not set on give-up");
            f = f + 1;
        end
        if (base_now != llrto_base) begin
            $display("  [PASS] LLRTO: window slid past the dropped message (retx_base %0d -> %0d)",
                     llrto_base, base_now);
            p = p + 1;
        end else begin
            $display("  [FAIL] LLRTO: retx_base stuck at %0d (window did not slide)",
                     llrto_base);
            f = f + 1;
        end
        if (llrto_rt1 >= llrto_rt0 + 7) begin
            $display("  [PASS] LLRTO: full retry budget consumed before give-up (retx=%0d)",
                     llrto_rt1);
            p = p + 1;
        end else begin
            $display("  [FAIL] LLRTO: only %0d retransmissions (expected >= 7)",
                     llrto_rt1);
            f = f + 1;
        end
        if (llrto_to2 == llrto_to1 && llrto_rt2 == llrto_rt1) begin
            $display("  [PASS] LLRTO: timer disarmed on the empty window (timeouts %0d stable, retx %0d stable)",
                     llrto_to1, llrto_rt1);
            p = p + 1;
        end else begin
            $display("  [FAIL] LLRTO: timer re-armed on an EMPTY window (timeouts %0d -> %0d, retx %0d -> %0d)",
                     llrto_to1, llrto_to2, llrto_rt1, llrto_rt2);
            f = f + 1;
        end
        pass_count <= pass_count + p;
        fail_count <= fail_count + f;
        all_pass   <= all_pass && (f == 0);
        test_state <= TEST_DONE;
    endrule

    // Module-wide drain/timeout priority (moved here from do_loop_drain:
    // every referenced rule must be defined before the attribute).
    (* descending_urgency =
       "do_loop_drain, do_loop_drain_timeout, \
        do_loopback, do_loop_timeout, \
        do_loop_get, do_loop_get_timeout, \
        do_ud_drain, do_ud_drain_timeout, \
        do_ud_loop, do_ud_loop_timeout, \
        do_ud_get, do_ud_get_timeout, \
        do_ud2_drain, do_ud2_drain_to, \
        do_ud2_loop, do_ud2_loop_to, \
        do_qp2_drain, do_qp2_drain_to, \
        do_qp2_loop, do_qp2_loop_to, \
        do_big_loop, do_big_rx_drain, do_big_loop_to, \
        do_dmamb_drain, do_dmamb_drain_to" *)
    rule do_done (test_state == TEST_DONE);
        $display("\n========================================");
        $display("100G RoCEv2 NIC Test Summary");
        $display("  Cycles:     %d", cycle_count);
        $display("  Pass:       %d", pass_count);
        $display("  Fail:       %d", fail_count);
        $display("  Result:     %s", all_pass ? "PASS" : "FAIL");
        $display("========================================");
        $finish;
    endrule

endmodule

endpackage
