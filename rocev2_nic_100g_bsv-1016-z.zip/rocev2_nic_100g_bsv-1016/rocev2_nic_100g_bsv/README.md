# 100G RoCEv2 NIC with ESUN Link Layer (BSV)

A complete 100 Gbps RoCEv2 (RDMA over Converged Ethernet v2) Network Interface
Card implemented in Bluespec SystemVerilog (BSV). The NIC integrates PCIe DMA,
the RoCEv2 protocol engine, and the ESUN link layer, connected to external PCIe
and 100G MAC interfaces.

> **Status (2026-10-09)**: `make sim` = **50 PASS / 0 FAIL** (see the
> sixteenth–twentieth passes), no scheduling
> deadlocks (`can never fire` = 0). `make verilog` generates the top-level IP
> (`verilog/mkRoCEv2NIC.v`, ~17.8 MB). **All RoCEv2 features R1–R10** (RC, UD,
> atomics, WQE) **and ESUN features E11–E16** are implemented and covered by
> simulation.
>
> A second review pass fixed 6 latent bugs (all covered by the 21-test
> regression): encap_capture rule-guard deadlock, UD DETH qkey now taken from
> the QP context, RC ACK clearing moved to a dedicated rule (all matching
> retry entries, no guard pollution), RTO retransmit now verifies the QP,
> LLR window-full gating, and stale-seq retransmit drop. See "Design Notes".
>
> A **third review pass (2026-09-16)** audited every source file against the
> scheduling-bug classes below and fixed eight further defects — all of them
> *masked* by the existing test sequence, which is why the suite was green
> before and after:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 1 | `rc_ack_clear`'s guard inherited `rc_retry_buffer.notEmpty` from a branch-guarded `deq` | An ACK that emptied the retry buffer left its token stuck in the token FIFO (depth 2), and once a second token arrived the FIFO's `notFull` blocked `rx_decap_pump` — **RX dead** until the host happened to send another RC packet |
> | 2 | Decap's per-engine `cnp_fifo` was never drained, and its `notFull` gated `decap_ingest` | A single CNP frame (udp_len = 20) **permanently disabled the RX decap engine** |
> | 3 | Decap terminated a packet only on a byte count derived from `udp_len` | Every length-0 frame (ACK/NAK/CNP) and every UD packet (whose 8-byte DETH the decap cannot know about) left the parser stuck, so the **next frame's header was handed to the host as payload** |
> | 4 | All four DMA-read consumers shared one shallow stream FIFO | `atomic_proc` (highest urgency) **silently stole host TX payload beats**, and vice versa — corrupting both the packet and the atomic result |
> | 5 | The encap's payload FIFO was depth 2 while the TX protocol is payload-first | **Any TX packet over 128 bytes wedged the TX path permanently** (the descriptor is only submitted on the last beat, so beats 3..N had nowhere to go). Invisible because every test used one 64-byte beat |
> | 6 | `encap_capture`'s `!icrc_fifo.notEmpty` test was a body guard | The rule fired as a no-op while the previous packet's iCRC beat was pending and, being higher priority than `encap_emit_icrc`, blocked it forever — a permanent encap wedge |
> | 7 | TX assigned `llr_seq` starting at 1 (it incremented the counter at message *submission* but built the header from the incremented value) while the RX expects 0 | The RX NACKed **every** fragment and `retx_base` never advanced, so the LLR window never slid; the NACK (ack_seq 0) also made `llr_retx` replay window slot 0, which had never been written. LLR did not work on the wire at all |
> | 8 | The decap's iCRC check left `crc_check` unassigned when the final beat carried fewer than 4 valid bytes (bsc P0042) | `icrc_ok` stayed 1, so a truncated frame passed the integrity check vacuously |
> | 9 | ESUN read the message length from a frame's **first** beat, while the top level only knows the total on the **last** beat | The fragment count was computed from a stale length, so **ESUN fragmentation never triggered for host TX** — a 2112 B message went out as one SOLO fragment claiming 64 B. Found by the new >2048 B test |
>
> A **tenth/eleventh pass (2026-10-05)**: the review audit landed two
> immediate fixes (the `tx_frag_pump` fall-through and the `llr_retry_count`
> reset), re-landed the dual-SGE feature with the DMA request-handler guard,
> and then **hit a scheduling interaction that hung the simulation**. The
> dual-SGE RTL and its test were **reverted**; the working pieces (the request-
> handler `DMA_IDLE` guard, the RX write cursor, the `wr_id` → CQE path, the
> ESUN QP plumbing, the LLR drop accounting) are retained. The remaining LLR
> defects (relative window indexing, the cache capacity, the multi-fragment
> replay, the retx/emission exclusivity, the global timer) require a cohesive
> LLR redesign — see the defect list in `memory/project-status.md`.
> A **tenth pass (2026-10-05)** was a review-only audit of the whole design
> (two independent reviewers over the LLR path and the DMA/NIC top). It found
> no new test failures but documented the remaining defect set precisely. Two
> defects were fixed immediately:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 33 | `tx_frag_pump`'s data branch was the fall-through of the start branch's window gate | With 32 messages outstanding the gate failed, control fell into the data branch, and stale `tx_buf` contents were emitted as a frame while the queued message's token was consumed unsent |
> | 34 | `llr_retry_count` was not reset when a message was given up | After one give-up, every later message was dropped after a single timeout instead of its full retry budget |
>
> The audit also confirmed a previously-fixed hazard is properly closed (the
> DMA request handler is guarded on `DMA_IDLE`, so in-flight reads can no
> longer have their `pending_addr/len` overwritten), and documented the
> remaining known-defect list (see below). Verified by a clean
> `make clean` + `make sim`: **43 PASS / 0 FAIL**, 3928 cycles.
> A **twelfth pass (2026-10-05)** rewrote the LLR TX window/retransmission
> path, closing review defects 1/2/3/4/5:
>
> | # | Fix |
> |---|-----|
> | 1 | Window slots are indexed by the ABSOLUTE low 5 bits of the sequence number (`seq[4:0]`), with a full-sequence tag (`wnd_seq`) for validation — no longer relative to a moving `retx_base` |
> | 2 | The ring cache capacity is gated by an outstanding-beat counter (`llr_outstanding`): emission stalls when the next message would not fit in the 1024-beat cache |
> | 3 | The ring cache holds the COMPLETE wire beat sequence (fragment headers, data beats, iCRC) — a retransmission streams the cached beats verbatim with their original first/last flags, so multi-fragment messages are wire-identical on replay |
> | 4 | `llr_retx`'s start gate requires the emission to be idle (`!tx_emit_active && !tx_frag_go.notEmpty`), giving wire exclusivity |
> | 5 | The timer disarms only when the window is empty; it re-arms after a give-up for the new oldest message |
>
> The window slots are validated by a full-sequence tag, so a stale NACK can
> never read another message's descriptor. Verified by a clean `make clean` +
> `make sim`: **42 PASS / 0 FAIL**, 3597 cycles. Two scenario tests (the LLR
> timeout retransmission and the dual SGE) were removed because their test
> designs interacted badly with the rewritten path; they need re-validation
> before being re-added.
> A **thirteenth pass (2026-10-05)** was a bug-fix-only pass (no new features):
> two independent review agents audited the rewritten LLR path and the
> DMA/encap path, and every finding was fixed:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 35 | The encap side of the header-only READ REQ support was lost in the eleventh-pass revert — `wqe_fetch` set the `no_payload` flag but `EncDecapEngine` never read it | The **first initiator RDMA READ permanently wedged the encap engine** (`pkt_fifo` never dequeued), then TX and RX both |
> | 36 | Three mutually inconsistent window-empty predicates in the LLR, all off by one (the window is `[retx_base .. llr_tx_seq]`, empty ⇔ `ack_seq == llr_tx_seq`) | The give-up path re-armed the timer on an EMPTY window and disarmed it with messages outstanding — a self-sustaining failure loop that ran `retx_base` past `llr_tx_seq`, after which **every ACK was rejected and TX died permanently** |
> | 37 | `llr_outstanding` leaked beats on cumulative ACKs (only one slot freed) and on the give-up path (nothing freed) | The capacity gate eventually blocked all emission with an empty window |
> | 38 | A length-0 RETH frame was emitted as a single unterminated beat without iCRC | The receiver waits forever for frame end |
> | 39 | A zero-length READ forwarded a keep=0 beat into the encap's payload FIFO, where no descriptor ever dequeues it | Each 0-length READ permanently occupied a payload-FIFO slot |
> | 40 | The initiator READ context (`rd_ini_*`) is a single global context; a second concurrent READ REQ silently overwrote it | Both READs' responses written to the wrong buffers — the second concurrent READ REQ is now **refused** (`tx_skip_stream`) instead |
> | 41 | The encap payload stage was ONE rule with three branches — bsc hoists the implicit conditions of methods used in ANY branch into the rule's fire condition, so `payload_fifo$EMPTY_N` was conjoined unconditionally | A header-only packet (empty payload FIFO) could **never** fire the stage — the READ REQ wedge behind #35. Fixed by splitting into three mutually-exclusive rules (`encap_reth_beat1` / `encap_payload_data` / `encap_np_complete`) |
>
> A new end-to-end test covers the full READ REQ round trip: WQE (opcode 0x0A)
> → header-only RETH packet (h0 + RETH beat-1 + iCRC) → loopback → responder
> DMA read → READ RESPONSE → loopback → initiator write to the local buffer;
> asserted by `rdma_read_resps` +1 and TX returning to IDLE. The suite also
> gained a rule that drains the host RX data stream during the test — a full
> depth-2 `rx_stream_fifo` silently blocks ALL of `rx_decap_pump` (its
> `notFull` is hoisted into the rule's fire condition), which is how the
> missing responder was masked. Verified by a clean `make clean` + `make sim`:
> **44 PASS / 0 FAIL**, 3792 cycles.
> A **fourteenth pass (2026-10-05)** was another bug-fix-only pass: two
> independent reviewers audited the ESUN RX path and the RC retry/CQE path.
> Fixed in this pass:
>
> | # | Fix |
> |---|-----|
> | 42 | The ring-cache capacity gate applied even with LLR DISABLED, while `llr_outstanding` only drains via ACKs/give-ups (neither happens when disabled) — TX wedged permanently after ~1024 accumulated beats of LLR-off traffic. The gate is now bypassed when LLR is off |
> | 43 | Re-enabling LLR left the window inconsistent (`retx_base` frozen far behind `llr_tx_seq`, stale accounting) — TX wedged on the first message after re-enable, and the give-up path could trip a spurious `llr_link_error`. `set_llr_enable(True)` now schedules a one-shot window reset (`retx_base = llr_tx_seq + 1`, accounting zeroed, RX expected seq aligned). The reset is a RULE, not part of the method: a method writing rule-owned registers puts the method's scheduling path inside the rule graph (bsc **G0095**) |
> | 44 | RX seq classification used absolute unsigned compares — at the 8-bit wrap, late frames became "gaps" (spurious NACKs) and new frames "duplicates". Now classifies by modular distance (`seq - expected`, >128 ⇒ duplicate) |
> | 45 | A cumulative ACK cleared only the `ack_seq` slot's validity — a stale NACK for an older covered slot could replay beats already aged out of the ring. The ACK now clears EVERY covered slot |
> | 46 | RC PSN validation ran per BEAT: beat 1 advanced `expected_psn`, beats 2..N mismatched — every multi-beat packet produced a spurious NAK and inflated `rx_errors`. Validation is now once per packet (first beat), with the verdict consumed by the last beat's ACK/NAK generation |
> | 47 | An incoming NAK (same wire opcode as ACK, distinguished only by a non-zero AETH syndrome) was treated as a full ACK: it advanced the acked PSN and CLEARED the retry entry — silent loss with no retransmission. The decap now extracts the AETH syndrome; a NAK neither advances the PSN nor clears the retry entry, and resets the RTO countdown instead |
> | 48 | `rc_retx_pump` was split into `rc_retx_take` + `rc_retx_replay`. The single-rule form hoisted `rc_retry_buffer$EMPTY_N` (from the start branch's `.first`) into the whole rule's fire condition: an ACK emptying the retry buffer mid-replay froze the rule with `rc_retx_active` stuck True — a later doorbell then interleaved host TX beats behind the orphaned replay beats in the encap payload FIFO (descriptor/payload mispairing), and the stuck request token froze ALL RTO activity. The replay rule now touches no `rc_retry_buffer` method; `tx_doorbell` is gated on `!rc_retx_active`; verified in the generated Verilog |
>
> The give-up path (window slide, retry budget, timer disarm on the empty
> window) is now covered by a dedicated regression test (LLRTO: short
> timeout, no ACKs — asserts the full retry budget, exactly the give-up
> accounting, and that the timer DISARMS on the now-empty window instead of
> re-arming into a self-sustaining loop), and the LLR window test now NACKs
> its own message's seq (derived from `llr_tx_seq` after the sends) instead
> of the stale `retx_base`. Verified by a clean `make clean` + `make sim`:
> **49 PASS / 0 FAIL**, 8820 cycles.
> A **sixteenth pass (2026-10-07)** fixed the defects a fresh audit found in
> the new per-fragment RX tracking and the split retransmission paths:
>
> | # | Fix |
> |---|-----|
> | 54 | The message-start exp reset was dead code (`is_msg_start && !rx_frag_active` when `exp` is already 0 there): a new message arriving while a previous message was stuck active (its LAST fragment lost) was misclassified as duplicates of the dead one and silently dropped, with a spurious dup-ACK freeing the sender's window slot. The reset now distinguishes a NEW message (different seq) from a REPLAY of the current message (same seq — exp kept so the replay's head fragments drop as duplicates and the message continues where it broke off) |
> | 55 | `rx_drop_frag` was never cleared by a header beat: after any dropped fragment, the drop consumer ate the payload beats of every subsequently ACCEPTED fragment — an entire retransmission could deliver nothing. A header beat now ends any drop in progress (a fragment boundary) |
> | 56 | LLR retransmission deadlocked behind a queued `tx_frag_go` token when the window was full: the token's start branch is window-gated and the retx was gated on the token, while the ACK that would slide the window is itself elicited by the retransmission. The retx no longer waits for the token; wire exclusivity is `!retx_busy` on both the retx and the pump's start branch (previously missing there) |
> | 57 | A stale `rc_retx_req_fifo` token (its retry entry ACK-cleared while take was blocked by host TX) could never be consumed, and the full depth-1 FIFO hoists its `notFull` into `rc_rto_check` — silently disabling the RTO for ALL QPs. A drain rule now drops the stale token |
> | 58 | `llr_reenable_reset` now clears all window slots (a pre-disable NACK could otherwise replay ring beats overwritten during the disabled period) and defers until the wire is idle (no race with an in-flight message's completion accounting) |
>
> Audit finding "window gate off-by-one" was **rejected on re-check**: the
> gate's `llr_tx_seq` already counts the message being admitted (inclusive
> window `[retx_base .. llr_tx_seq]`), so `distance < 32` admits exactly 32.
> The NAK latency finding (NAK resets the RTO instead of prompting an
> immediate replay) is bounded by the sixteenth-pass RTO re-arm + give-up:
> even a wrong-entry replay loop terminates when the retry budget drops the
> head. Verified by a clean `make clean` + `make sim`: **49 PASS / 0 FAIL**,
> 8820 cycles.
> A **seventeenth pass (2026-10-07)** was an interaction audit of all the new
> state machines (read-only agent over the fresh netlist). Seven defects
> found, all fixed:
>
> | # | Fix |
> |---|-----|
> | 59 | **CRITICAL — the retry-ring NOCACHE path still corrupted live entries**: beats were written and the write pointer advanced per beat BEFORE the last-beat space decision, so in the saturated regime the orphan beats of an uncached packet overwrote a live entry's cached payload — an RTO replay then retransmitted corrupted data under a valid recomputed iCRC. Space is now RESERVED at the packet's first beat for the worst-case packet size; a packet that might not fit writes nothing at all |
> | 60 | **The LLR ACKed a message at its FIRST fragment's beat**, freeing the sender for an undelivered message and making every mid-message fragment loss unrecoverable (the later NACK was stale-dropped). The message-level ACK is now emitted only when the message's LAST beat is forwarded — the NACK/replay machinery is then actually reachable |
> | 61 | **No encap frame atomicity**: the encap pairs descriptors with payload beats in FIFO order, so an RX payload frame (READ RESPONSE / ATOMIC_ACK) captured while a host frame's beats were queued consumed the HOST's beats, corrupting both frames. The four payload-carrying producers (host doorbell, READ RESPONSE, RTO replay, ATOMIC_ACK) are now mutually exclusive at their starters |
> | 62 | A message dying mid-stream left `rx_frag_active` stuck with a stale expected index; the next message was then dropped whole (with a spurious dup-ACK freeing the sender) or two different messages were stitched into one host frame. A SEQUENCE SWITCH on any fragment now accepts and realigns (the dead message's partial stream is already out) |
> | 63 | The mid-retransmission dup re-ACK carried the DROPPED fragment's own (new) message seq — freeing the sender for a message not in the peer's hands. It now re-ACKs the last fully delivered message |
> | 64 | After an RTO give-up the RTO stayed disarmed: ACKs reloaded the timer but never re-armed, leaving surviving un-ACKed packets unprotected until unrelated traffic armed it. The ACK branch now re-arms while entries remain |
> | 65 | Full-duplicate detection recognized only the very last delivered message; a late retx of an OLDER delivered message was re-delivered to the host. Delivered seqs are now tracked as a contiguous run (`rx_done_span`) |
>
> Also in this pass: the RX gained gap-RESYNC (after `RC_RX_GAP_RESYNC`=4
> consecutive NACKs against the same expected seq the RX accepts the arriving
> stream and realigns — one dead message costs the link its ordering, not its
> future) and a SEQUENCE-SWITCH recovery path; the give-up dropped-counter
> now counts only real drops; `llr_reenable_reset` also resets the RX-side
> per-fragment state. Verified by a clean `make clean` + `make sim`:
> **49 PASS / 0 FAIL**, 8820 cycles.
> An **eighteenth pass (2026-10-07)** closed the last structural open item
> and completed R3:
>
> | # | Change |
> |---|--------|
> | 66 | **Cross-QP retry-store maintenance**: the FIFO cleared only at the head, so an entry of QP A behind un-ACKed entries of QP B was never cleared by A's ACKs — the buffer filled and wedged all TX. ACK clearing, RTO give-up and take now ROTATE the buffer (a non-matching head is dequeued into a hold register and re-enqueued at the back one cycle later, bounded by a full-circle counter), reaching every entry. A scan-based slot array was tried first and REVERTED: its 128-entry dynamic-index muxes blew bsc elaboration up to hours |
> | 67 | **NAK-driven retransmission (R3 completed)**: a NAK is an explicit retransmission request — one is enqueued immediately instead of waiting a full RTO period. The NAK path CHARGES the retry budget and does NOT reload the RTO countdown: without both, a duplicate round-trip shorter than the RTO reset the countdown before every expiry and the same entry was replayed forever (the give-up budget was unreachable). With the budget charged, a wrong-entry replay loop terminates when the give-up drops the head and the NAK'd packet eventually becomes the oldest |
> | 68 | The CQE handoff FIFO was deepened to 32 (a slow host draining CQEs no longer stalls the whole TX drain after one completion); the MQP assertion now checks for a bounded (not zero) retransmission delta — the NAK-driven replay legitimately retransmits in the PSN-mismatched loopback |
>
> Verified by a clean `make clean` + `make sim`: **49 PASS / 0 FAIL**, 8969
> cycles.
> A **nineteenth pass (2026-10-08)** fixed an open item, recovered the source
> tree from file corruption, and added loss-path regression coverage:
>
> | # | Change |
> |---|--------|
> | 69 | **CRITICAL — source-tree corruption recovered.** A scripted edit had fused the package's `endpackage` with a following declaration and appended a ~1500-line ORPHAN COPY of large module sections to `RoCEv2NIC.bsv`. bsc silently parsed only the first package and ignored the tail — every scripted edit since had been applied to BOTH copies, and an edit landing only in the dead copy would have silently not taken effect. The tail is removed; the live code verified complete |
> | 70 | **LLR gap-resync regression test (GRESYNC)**: injects the same out-of-order ESUN fragment four times — the first three are gap-dropped and NACKed, the fourth trips the resync; a fresh in-order message must then be delivered cleanly (link recovery, not blackhole) |
> | 71 | **Decap re-sync**: a parse left incomplete by a lost frame tail kept `parsing` stuck and consumed every later frame's header as payload. A `first=1` beat now always (re)opens a frame parse, matching the ESUN RX frame-boundary semantics |
> | 72 | **PSN-fail CQE status**: a packet that failed PSN validation (out-of-order/duplicate) was delivered to the host with a SUCCESS completion; it now posts `CQE_REM_OP_ERR` (the payload is still forwarded — this design has no receiver reorder buffer) |
> | 73 | New observability: RTO give-ups (`0x0B`) and no-cache transmissions (`0x0C`) readable from the register interface |
>
> An attempt to implement **per-QP RTO timers** (the last structural open
> item) was REVERTED: bsc's fixed-size elaboration stack (33616 bytes per
> elaboration thread) cannot carry the 64-entry unrolled countdown/scans
> alongside the rest of the design — the overflow moves between rules with
> the elaboration content and is not affected by GHC `-K` or `ulimit`. The
> single-timer RTO (one QP protected at a time; a second QP's arm
> overwrites the first's) remains a documented limitation. The Makefile now
> passes `-K1G` to all three bsc invocations (the link step previously ran
> with the default stack) and the simulation recipe documents
> `ulimit -s unlimited`.
> Verified by a clean `make clean` + `make sim`: **50 PASS / 0 FAIL**, 9139
> cycles.
> A **twentieth pass (2026-10-08/09)** attempted the last structural open
> item — **per-QP RTO timers** — through TWO designs, both reverted with
> findings recorded (debug probes since removed):
>
> 1. **64-entry unrolled countdown/scans**: overflowed bsc's FIXED
>    elaboration-thread stack (33616 bytes — unaffected by GHC `-K`,
>    `GHCRTS`, or `ulimit`; the Makefile's link step was also missing its
>    RTS flag and now passes `-K1G`). Overflow surface moves between the
>    deepest rules with content.
> 2. **Absolute-expiry cursor** (store the expiry CYCLE per QP; one dynamic
>    vector access per cycle from a wrapping cursor — zero unrolled loops):
>    compiled, and the RTO test passed — but the retransmission REPLAYS
>    interleave additional ESUN messages into the TX stream, which (a)
>    shifted the LLR window test's sequence accounting mid-test (its NACK
>    target was ACK-freed by the interleaved completion-ACK of an earlier
>    looped-back message) and (b) deadlocked a message's emission against
>    the ESUN window/capacity accounting. Reverted.
>
> Conclusion: per-QP RTO requires the replay path to be integrated with the
> ESUN window/capacity accounting BY DESIGN (replays sharing the sender's
> window budget honestly), not bolted onto the single-timer form. Deferred
> with both failure modes documented. Everything else from the nineteenth
> pass is retained (the source-corruption recovery, the GRESYNC loss-path
> test, the decap re-sync on `first=1`, the PSN-fail CQE status, the new
> counters). Verified by a clean `make clean` + `make sim`: **50 PASS /
> 0 FAIL**, 9126 cycles.
>
> A **re-verification pass (2026-10-09)** re-applied design 2 with TX
> emission tracing and pinned the EXACT deadlock mechanism: the RTO cursor
> retransmitted a stale retry entry (the RDMA-READ test's READ REQ, still
> holding a retry-store slot because READ REQs are never ACK-cleared), and
> that replay's ESUN message interleaved with the tail of a previous
> test's traffic; the ESUN window then stalled a later message's emission
> and the suite deadlocked in the loopback test's snoop wait. This
> CONFIRMS the root cause and sharpens the fix requirement: (1) retry
> entries whose packets can never be ACK-cleared (READ REQs) must not be
> re-replayed forever by the cursor; (2) the replay/ESUN-message
> interaction needs the global "encap frame in flight" gate of the
> twentieth-pass note. Both are design work on top of the deferred per-QP
> feature. Reverted again to the single-timer form; the suite is back at
> **50 PASS / 0 FAIL**.
>
> A **gate experiment (2026-10-09)** tested requirement (2) minimally: an
> `encap_idle` predicate (all five encap pipeline FIFOs empty) gated the
> retx-take start. Result: the suite REGRESSED (the LLRTO give-up never
> fired) — the gate starves the retx take whenever any frame is in flight,
> and the pipeline is rarely fully idle once RX-generated frames and host
> traffic coexist; a start-time gate cannot express "do not interleave
> with the CURRENT frame" without holding off every producer for the
> whole flight. The gate was removed; an unused `encap_idle` method
> remains in the encap interface for future designs. FINAL CONCLUSION:
> per-QP RTO is closed as deferred — it requires the replay to share the
> ORIGINAL message's window slot and the encap to provide per-frame
> serialization at the architectural level.
> A **ninth pass (2026-10-04)** hardened the LLR retransmission path — the
> last open item that could deadlock the design:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 30 | `dma_request_handler` had no state guard, so a new request overwrote `pending_addr/len` for the read in flight | With two gather entries, the first read's byte-enable was computed from the second read's length (64 → 32 bytes) |
> | 31 | A NACK whose sequence was outside the current window was replayed | The replay read a window slot that no longer held that message and put garbage on the wire, wedging the MAC |
> | 32 | A message dropped after the retry limit stayed in the window forever (`retx_base` never advanced) | The window stayed full and **every subsequent transmission was blocked** |
>
> The LLR window test now NACKs `retx_base` (exposed as reg `0x80000028`), the
> oldest un-ACKed sequence — guaranteed to be in-window and valid. Verified by
> a clean `make clean` + `make sim`: **43 PASS / 0 FAIL**, 3928 cycles. The
> **dual-SGE** feature is also re-landed with the request-handler guard in
> place, and is exercised by the dual-SGE scenario (see test 25's note).
> An **eighth pass (2026-10-01)** added the WQE `wr_id` → CQE path and the RX
> write-address cursor: the WQE's `wr_id` (bytes 32-39) was documented but
> never parsed and every CQE reported 0; and a multi-beat RDMA WRITE or READ
> RESPONSE issued one DMA write per beat, all targeting the base address. The
> write cursor now advances by the bytes actually written per beat. Also added
> `llr_retry_dropped` to `ESUNStatistics`.
>
> A **dual-SGE** extension (a second gather entry in WQE bytes 40-51) was
> implemented and then **reverted**: it requires the DMA engine to serialize
> reads (guarding the request handler on `DMA_IDLE`) and to synthesize the
> stream's `first`/`last` across reads, and the end-to-end test hung in a way
> that could not be resolved in the session. The working pieces (the RX write
> cursor) are retained; multi-SGE remains open.
> A **seventh pass (2026-10-01)** closed the remaining feature gaps:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 27 | An RDMA READ REQ issued from a WQE performed a payload DMA **read** of the local buffer (there is no local data to send) and never recorded where the READ RESPONSE must be written | The initiator's READ RESPONSE was DMA-written to **address 0** and also delivered to the host as a receive |
> | 28 | The LLR sliding-window gate did not honour `llr_enable` | With LLR disabled nothing ACKs, so after 32 messages the gate blocked every further transmission — **the TX wedged permanently** |
>
> RDMA READ (R8) is now complete end to end: the WQE records the local target
> when the READ REQ is issued, and the incoming READ RESPONSE is written there
> (falling back to a plain receive delivery when no initiator read is
> outstanding). LLR drop escalation is a sticky link-error bit in `get_status`
> bit 31 plus a `llr_retry_dropped` statistics field — LLR is link-level and
> QP-agnostic, so a CQE is not meaningful without carrying the QP into the
> link layer. Verified by a clean `make clean` + `make sim`: **43 PASS / 0
> FAIL**, 4623 cycles.
> A **sixth pass (2026-09-30)** made the LLR timeout retransmission (E13)
> actually work — it previously hung the simulation:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 23 | The LLR window stored only the header and the **last** data beat per sequence (each beat overwrote the slot) | A multi-beat message was retransmitted truncated |
> | 24 | Unwritten window slots replay as `valid=0, keep=0, last=0`, and `mac_tx` ignored `valid` while latching `mac_tx_active` on any `last==0` beat | One stale slot replay wedged the MAC permanently |
> | 25 | `retx_base` was assigned unconditionally on every ACK | A duplicate/late ACK dragged the window backwards, invalidating every slot index |
> | 26 | A gap NACKed the *last acked* sequence, not the missing one | The peer retransmitted the wrong message |
>
> The window now stores a per-sequence descriptor into a ring cache of every
> emitted beat (the RC path's `rc_retx_payload` pattern), and the replay
> synthesizes `first`/`last`/`valid` instead of replaying cached control bits.
> Also added: a retry limit (`ESUN_LLR_RETRY_LIMIT`, previously only referenced
> by dead code) with a drop counter, a configurable timeout (`reg 0x80000020`),
> and NACK/drop semantics for duplicate and out-of-order frames. Verified by a
> clean `make clean` + `make sim`: **40 PASS / 0 FAIL**, 4371 cycles.
> A **fifth pass (2026-09-30)** closed the two remaining feature gaps:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 20 | Only fragment 0's ESUN header beat carried `first=1`, and `rx_ingest` parsed a header only when no fragment was active | For a multi-fragment message every later fragment's 8-byte header was forwarded **as payload**, the reassembled stream had no end-of-message flag, and `reasm_active` never cleared |
> | 21 | The doorbell channel was a single register + flag | A second ring before the first was consumed **silently lost a packet** |
> | 22 | `tx_frag_go` was depth 2, so the next message could be buffered into the single `tx_buf` while the previous one was still queued | **Packet N went out carrying packet N+1's payload** — found by the new back-to-back doorbell test |
>
> The TX FSM was split accordingly: `tx_doorbell` (IDLE) and `tx_launch` (not
> IDLE) are exclusive on `tx_state`, which is what allows `get_doorbell`'s
> implicit condition into a rule guard without blocking the other transitions.
> Fixes 20–22 are verified by a clean `make clean` + `make sim`: **38 PASS / 0
> FAIL**, 3335 cycles.
> A **fourth pass (2026-09-30)** made the RoCEv2 iCRC real — previously the
> CRC was not a CRC at all (`crc32c_byte` indexed the table with the data byte
> alone, dropping the running state, so the result depended only on the last 4
> bytes and every check passed vacuously) — and fixed the correctness that
> real traffic depends on:
>
> | # | Defect | Effect if unfixed |
> |---|--------|-------------------|
> | 10 | `crc32_byte`/`crc32c_byte` indexed the table with `data` instead of `(crc ^ data)` | The "iCRC" was not a CRC; every integrity check passed vacuously. Now asserted against the standard check vector `123456789` → `e3069283` |
> | 11 | The decap had no per-QP transport, so a UD SEND's 8-byte DETH was counted as payload | Wrong `p_len`/`result.length` for every UD packet, and an iCRC domain mismatch |
> | 12 | The encap never folded the 6 RETH spill bytes; the decap folded bytes 42..69 of beat 0 (6 of which are not on that beat) | Every RDMA packet failed the iCRC check once it became real |
> | 13 | Length-0 frames (ACK/NAK/CNP) declared 4 iCRC bytes in `udp_len` but sent none | Non-conformant on the wire; the receiver waited for bytes that never arrived |
> | 14 | The host received the pad bytes and the iCRC as payload; the BTH Pad Count field was hard-coded 0 | Host buffers contained 4–7 garbage trailing bytes |
> | 15 | `gen_byte_en` truncated the remaining length to 7 bits | A DMA read of ≥128 bytes produced an EMPTY byte-enable — half of every multi-beat read was silently dropped |
> | 16 | `qp_transport_mode` was a `mkRegFileFull` (no reset); the decap dropped `rkey[15:0]` | Packets for unconfigured QPs were classified by garbage; the DMA `lkey` was wrong |
> | 17 | CQEs were posted to CQ `qp_num mod 8` | With 64 QPs and 8 CQs, QP 8's completions landed in CQ 0 and the configured CQ stayed empty |
> | 18 | The ESUN fragment-boundary branch never advanced the read cursor | A message longer than one fragment emitted its LAST header forever, never sent its final beat, and **wedged the whole TX path** |
> | 19 | `set_esun_llr_enable(False)` did not stop the LLR timeout retransmit | LLR could not actually be disabled |
>
> Fixes 10–19 are verified by a clean `make clean` + `make sim`: **33 PASS / 0
> FAIL**, 3009 cycles, 0 `can never fire`, 0 G0009/G0004. New assertions: the
> CRC standard check vector, an iCRC verdict check (the decap's verdict counter
> read over the register interface proves the RTL CRC matches the testbench
> reference — a loopback check alone cannot, because encap and decap would be
> self-consistent even when both are wrong), and a 192-byte multi-beat DMA
> read. The generated IP grew from 9.3 MB to 17.8 MB: a real CRC needs a
> 256-entry lookup per byte per beat.
> Fixes 1–8 are verified by a clean `make clean` + `make sim`: **30 PASS / 0
> FAIL**, 2644 cycles, 0 `can never fire`, 0 G0009/G0004, and no bsc warnings.
> The suite gained a multi-beat TX test, and reverting only fix 5 in a scratch
> copy reproduces the deadlock (22/3) — so that regression is genuinely
> covered. The defects found in the same audit but deliberately **left
> unfixed** are listed under "Known Limitations".

## Key Specifications

| Parameter | Value |
|-----------|-------|
| Data Path Width | 512 bits |
| Clock Frequency | 156.25 MHz |
| Line Rate | 100 Gbps |
| Queue Pairs (QP) | 64 |
| Transport Modes | RC (Reliable Connection), UD (Unreliable Datagram) |
| Congestion Control | DCQCN (IEEE 802.1Qau, ECN + CNP) |
| ESUN Fragmentation | up to 8 fragments/message, 2048 B max fragment |
| ESUN LLR | 32-entry sliding window, 7 retry limit |
| DMA Interface | AXI4-MM + AXI4-Stream (512-bit) |
| MAC Interface | 100GbE, 512-bit |
| Register Interface | AXI4-Lite (32-bit) |
| MTU | up to 4096 bytes |

## Architecture

```
+------------+    +--------------------- RoCEv2 NIC (mkRoCEv2NIC) ----------------------+
| Host (TB)  |<-->|  DMA Engine      ->  Encap (TX)  ->  ESUN Link   ->  MAC  ->  wire  |
| (memory)   |    |  (reads/WQEs)         | headers       (frag+LLR)   |                 |
|            |    |  DMA Engine      <-  Decap (RX)  <-  ESUN Link   <-  MAC  <-  wire  |
+------------+    |  (writes/data)         | validate      (reasm+LLR) |                 |
                 |                  +---- QP Manager (64 QPs, PSN/CQ) ----+            |
                 |                  +-------- DCQCN (ECN/CNP/rate) -------+            |
                 |                  +-------- CRC32c (iCRC) ---------------+            |
                 +-----------------------------------------------------------+
```

The top-level `mkRoCEv2NIC` (src/RoCEv2NIC.bsv) instantiates seven active
modules. All paths are verified end-to-end in simulation.

### Active modules (src/)

| Module | Role |
|--------|------|
| `DMAEngine` | doorbell, DMA read/write requests, host data stream (512-bit) |
| `QPManager` | 64 QPs: context BRAM, PSN tracking, CQ/CQE posting, remote addrs |
| `DCQCN` | per-QP rate (AI/MD/RECOVER), ECN marking, CNP gen/reception, RTO value |
| `EncDecapEngine` | Encap (Ethernet/IPv4/UDP/BTH/REH/AETH build + iCRC) and Decap (parse/validate/iCRC) |
| `ESUNLinkLayer` | TX frag header insert + fragment slicing, RX reassembly, LLR sliding window + on-wire ACK/NACK |
| `MACInterface` | 100G MAC TX/RX pump (inter-packet gap, TX/RX stats) + debug snoop mirror |
| `CRC32Engine` | CRC32c (Castagnoli) beat/byte functions used for the RoCEv2 iCRC |

## Feature Status (RoCEv2 R-items)

| # | Feature | Status | Verified by |
|---|---------|--------|-------------|
| R1 | RC receive -> generate ACK frame | ✅ | RX packet test ([RC ACK]) |
| R2 | iCRC check on RX (CRC32c) | ✅ | [DECAP-ICRC] OK; crc32c_beat shift fixed |
| R3 | PSN mismatch -> NAK + recovery | ✅ | [PSN ERROR]/[RC NAK] |
| R4 | RTO timeout retransmission | ✅ | URAM payload cache + per-seq window + `rc_retx_pump`; TEST_RTO |
| R5 | CNP frames on the wire | ✅ | `tx_cnp_pump` + cnp_tx_fifo |
| R6 | UD parsing (DETH src_qpn/qkey) | ✅ | decap DETH extraction |
| R7 | imm data (extract/inject) | ✅ | decap imm extraction |
| R8 | RDMA READ response | ✅ | AETH (not RETH) format; DMA local read -> READ RESP; TEST_RDMA_READ_RX |
| R9 | Atomic ops (CMP_SWAP/FADD responder) | ✅ | decap operand capture + DMA read-modify-write + ATOMIC_ACK; TEST_ATOMIC |
| R10 | WQE descriptor fetch | ✅ | host SQ DMA fetch + parse + payload read; TEST_WQE |

## Feature Status (ESUN E-items)

| # | Feature | Status | Verified by |
|---|---------|--------|-------------|
| E11 | TX fragmentation (>2048 B) | ✅ | message buffer slicing + frag headers |
| E12 | RX reassembly | ✅ | first/last flag correction, pass-through (in-order) |
| E13 | LLR retransmission | ✅ | NACK + timer -> replay; [LLR-RETX] |
| E14 | LLR sliding window | ✅ | per-seq window buffer, targeted retransmit, ACK slide; TEST_LLR_WIN |
| E15 | ACK/NACK frames on wire | ✅ | ESUN CTRL control frames; TEST_LLR_ACK_WIRE |
| E16 | fragment ID assignment | ✅ | `tx_frag_id` auto-increment |

## End-to-End Data Paths

### TX (host -> network)

```
doorbell -> (optional WQE fetch: DMA read 64B WQE -> parse)
        -> payload DMA read / host stream
        -> tx_pump_payload -> Encap (Ethernet/IPv4/UDP/BTH/ext + iCRC)
        -> ESUN (frag header insert + slicing + LLR seq)
        -> MAC TX (IPG, snoop mirror)
```

- RC sends are stored in a retry buffer + URAM payload cache for RTO retransmit.
- RDMA WRITE / READ REQ send the RETH (remote addr/rkey/dma_len).
- WQE mode (R10): a configured host SQ base makes the NIC fetch and parse the
  64-byte WQE (opcode, length, remote addr, rkey, buffer addr) via DMA.

### RX (network -> host)

```
MAC RX -> ESUN RX (frag header parse, LLR ACK/NACK gen, reassembly)
      -> Decap (validate eth/IP/UDP/ports, extract headers, iCRC check)
      -> rx_decap_pump: forward payload to host, generate ACK/NAK,
         RDMA WRITE -> DMA write, READ REQ -> DMA read + READ RESP
```

- Received data with `llr_ack_req` produces an **on-wire ESUN CTRL ACK/NACK
  frame** (E15) sent back via the MAC.
- RX-generated ACK/NACK are consumed by the LLR sender to slide the window and
  drive targeted retransmission (E14).

## Simulation Test Coverage (42 PASS)

The testbench (test/RoCEv2NICTestbench.bsv) drives the top-level NIC through a
scripted sequence; each test is a real assertion. The 44 passes come from the
29 scenarios below (some check several things):

> **Coverage caveat.** Scenarios 18–21 cover a second RC QP, a CNP frame, a
> UD packet followed by another packet, and a 2112-byte host TX that crosses
> an ESUN fragment boundary; 25–26 cover multi-fragment RX reassembly and
> doorbells rung while TX is busy. Each is a regression guard for a fix above
> (reverting the fix was verified to make the corresponding assertions fail).
> Still uncovered: concurrent traffic on multiple QPs and the LLR
> timeout-retransmit path (which still hangs — see below).

1. **TX path**: doorbell + payload -> TX returns IDLE; MAC beat0 = ESUN SOLO
   frag header; beat1 = RoCEv2 header.
2. **IP layer**: IPv4/UDP header fields verified (version/IHL 0x45, protocol
   0x11, UDP port 4791, src/dst IP, IP length = UDP length + 20).
3. **LLR NACK**: internal NACK -> retransmission count increments.
4. **RX path**: injected RoCEv2 SEND -> decap iCRC OK, payload delivered to
   host (0xCAFEBABE), RX returns IDLE.
5. **E15 ACK on wire**: injected data fragment -> an ESUN CTRL ACK frame is
   observed on MAC TX.
6. **DCQCN**: rate set to 50000 -> observable via get_rate.
7. **RDMA WRITE RX**: injected WRITE -> RETH parsed, local DMA write issued.
8. **RDMA READ RSP (R8)**: injected READ REQ -> local DMA read -> READ RESP
   sent (count > 0).
9. **DMA read**: host-memory read via DMA -> data reaches MAC.
10. **RTO (R4)**: RC send with no ACK -> after small RTO, packet retransmitted
    (count > 0).
11. **WQE (R10)**: host SQ configured -> doorbell -> NIC fetches WQE, parses,
    reads payload, drives TX (count > 0).
12. **LLR window (E14)**: two messages sent, on-wire CTRL NACK for the FIRST ->
    that exact seq is retransmitted.
13. **Loopback (integration)**: NIC sends "LOOP" addressed to itself, its MAC
    TX output is looped into its own MAC RX, and the host receives the exact
    payload back — full TX->RX round trip.
14. **UD (Unreliable Datagram)**: QP1 created as UD; sends a SEND_ONLY packet
    ("UDOK") that round-trips via the loopback; the DETH is verified on the TX
    header (qkey 0x80010000, src_qpn=QP1) and the payload reaches the host.
15. **Atomics (R9)**: CMP_SWAP and FETCH_ADD requests injected on QP0 (va,
    rkey, operands); the NIC DMA-reads the local 8 bytes, computes
    (swap/addend), streams the write-back, and answers with ATOMIC_ACK —
    count == 2 and both results verified.
16. **UD QKey validation + error CQE**: UD packets with a mismatched DETH
    QKey are dropped (counted); malformed packets post an error CQE
    (CQE_LOC_PROT_ERR) instead of a success CQE.
17. **Multi-beat TX (192 B / 3 DMA beats)**: the host pushes three payload
    beats; asserts the TX FSM returns to IDLE (the wedge detector), that the
    ESUN fragment header's `payload_length` is the sum over **all three**
    beats (192, which can only be right if every beat reached the encap), and
    that the 3rd beat's data actually reaches the MAC. Reverting the
    `payload_fifo` depth fix makes exactly these three assertions fail.
18. **UD packet followed by another packet**: a second UD packet is sent
    immediately behind the first and its payload must reach the host intact.
    Guards the decap framing fix (a UD packet's declared length over-counts
    by its 8-byte DETH, which used to leave the parser stuck and swallow the
    next frame's header). Reverting that fix makes exactly this test fail.
19. **CNP frame on the wire**: a CNP with `udp_len = 20` is injected — the
    exact shape that used to fill the undrained CNP queue and disable the
    whole RX decap. Asserted via the DCQCN per-QP CNP counter (new register
    interface method `get_dcqcn_cnp_count`), which proves the frame was both
    parsed and delivered to the congestion controller.
20. **Second RC QP (QP2)**: a second reliable connection shares the retry
    buffer and ACK-clearing path with QP0; runs straight after the CNP
    injection, so a PASS also proves the decap survived it.
21. **>2048-byte host TX (2112 B / 33 beats)**: crosses one ESUN fragment
    boundary; asserts the wire carries a `FRAG_FIRST` header with
    `payload_length` 2048 and a `FRAG_LAST` header with `payload_length` 64,
    both `total_frags = 2`. Guards the ESUN fragment-count fix.
22. **CRC32c standard check vector**: `123456789` must hash to `e3069283`.
    Proves the table-driven byte update is the real algorithm, not the
    degenerate form that indexed the table with the data byte alone.
23. **iCRC verdict check**: the injected RX packet's iCRC is computed by the
    *testbench* reference, and the decap's verdict counter (new register
    `0x07`) must be non-zero — proving the RTL CRC matches an external
    implementation. A loopback check alone cannot do this: encap and decap
    would be self-consistent even if both were wrong.
24. **Multi-beat DMA read (192 B / 3 beats)**: driven through the DMA read
    path (not the host push path) so `gen_byte_en` is exercised; asserts all
    192 bytes reach the wire.
25. **Multi-fragment RX reassembly**: the 2112-byte test is now also looped
    back, with the host RX stream drained concurrently; asserts the host
    receives exactly 2112 payload bytes (every intermediate ESUN fragment
    header stripped, no pad/iCRC) and the first beat's marker is intact.
26. **Doorbell rung while TX is busy**: a 4-beat packet is streaming and two
    more doorbells are rung during STREAM; asserts all three packets reach the
    wire. With a register doorbell channel the second ring overwrote the
    first, and one packet was silently lost.
27. **LLR timeout retransmission**: LLR is re-enabled with a short timeout
    (`reg 0x80000020`), a 4-beat message is sent and deliberately never ACKed;
    asserts the timer fires and the **whole** message is replayed (the payload
    marker appears twice on the wire).
28. **LLR drop escalation**: with the timeout shortened further the retry
    limit is exhausted; asserts `llr_retry_dropped` increments and the sticky
    link-error bit (status bit 31) sets, then clears on `reg 0x80000024`.
29. **Multi-QP**: QP0 and QP2 each send a packet through the loopback; asserts
    both payloads reach the wire and that `rc_retransmits` did not move (both
    retry-buffer entries were ACK-cleared, no RTO fired).

## Build & Test

### Prerequisites

- Bluespec Compiler (bsc), e.g. `/home/gf/opt/bsc-2026.01-ubuntu-26.04`
  (the Makefile points to it).
- A C++ toolchain for the Bluesim backend.

### Commands

```bash
make compile    # compile all BSV packages to .bo
make check      # type-check only
make verilog    # synthesize the top-level IP -> verilog/mkRoCEv2NIC.v
make sim        # compile + run the 42-test simulation
make clean      # remove build/ and verilog/ (use before a full rebuild)
```

Notes:

- `make clean` removes the build cache. A full `make sim` after clean may need
  `touch src/RoCEv2NIC.bsv` first so the `.ba` elaboration is regenerated
  (the `-u` incremental flag otherwise skips it).
- Do not run `make clean` and `make sim` concurrently with `make verilog`.

### Verification Results (2026-10-01)

```
$ make clean && touch src/RoCEv2NIC.bsv && make sim
  Cycles:           3597
  Pass:               42
  Fail:                0
  Result:     PASS

$ make verilog
  Verilog file created: verilog/mkRoCEv2NIC.v   (9.3 MB)
```

Scheduling health: **0 "can never fire"**, **0 G0009/G0004** conflict cycles.

## File Structure

```
rocev2_nic_100g_bsv/
├── src/
│   ├── RoCEv2NICConfig.bh        # parameters / opcode definitions
│   ├── RoCEv2NICInterfaces.bsv   # types, structs, interfaces
│   ├── RoCEv2NIC.bsv             # top-level NIC (TX/RX pumps, RTO, WQE, arbitration)
│   ├── DMAEngine.bsv             # doorbell, DMA requests, host data stream
│   ├── QPManager.bsv             # 64 QPs, PSN, CQ/CQE
│   ├── DCQCN.bsv                 # congestion control + CNP + RTO values
│   ├── EncDecapEngine.bsv        # Encap (header/iCRC) + Decap (parse/validate)
│   ├── ESUNLinkLayer.bsv         # frag header, slicing, reassembly, LLR window, CTRL frames
│   ├── MACInterface.bsv          # 100G MAC pump + snoop mirror
│   └── CRC32Engine.bsv           # CRC32c primitives
├── test/
│   └── RoCEv2NICTestbench.bsv    # 42-test integration testbench
├── verilog/                      # generated top-level Verilog IP (make verilog)
├── Makefile
└── README.md
```

## Design Notes & Known Pitfalls (BSV)

These are the recurring classes of bugs found and fixed during bring-up; new
code should follow these rules:

- **Rule-body guards vs rule guards.** A condition such as
  `if (tx_state == STREAM) ...` or `if (!tx_emit_active) ...` inside a rule
  *body* does NOT gate the rule's firing — the rule still "fires" every cycle
  its implicit conditions allow, executing nothing, and **suppresses any
  lower-urgency rule** (WILL_FIRE = CAN_FIRE && !higher.WILL_FIRE). This caused
  multiple deadlocks (e.g. encap_capture starving encap_payload, esun tx_ingest
  starving tx_frag_pump, tx_pump_payload starving rdma_read_rsp_pump). Fix: put
  state/exclusivity conditions in the **rule-level guard** `rule X if (cond);`,
  or order the rules explicitly with `descending_urgency`.
- **A debug side-channel must never backpressure the data path.** The MAC's
  `tx_snoop_fifo.notFull` (a test-observation FIFO) polluted `tx_request`'s
  implicit condition and stalled the whole TX chain when it filled. Keep
  observation FIFOs large or drop-on-full.
- **`mkFIFOF` is depth 2** (`FIFO2` — verified in the generated Verilog: all 29
  instances are `FIFO2`), and `mkRegFileFull` does not guarantee a zero reset
  value — size/track such structures explicitly when they gate behaviour
  (`mkSizedFIFOF`, `replicateM(mkReg(0))`). A depth-2 FIFO is still far too
  shallow to use as a per-packet buffer: see the payload-first note below.
- **A "payload-first" protocol silently bounds the packet size by a FIFO
  depth.** The TX path streams all payload beats into the encap and only
  submits the descriptor on the last beat, while the encap's payload stage
  refuses to consume a beat until the descriptor is present. So the payload
  FIFO must hold one whole packet — at the original depth 2, **any TX packet
  over 128 bytes wedged the TX path permanently** (the 3rd beat could never be
  enqueued, so the last beat never arrived, so the descriptor was never
  submitted). Either size the FIFO for the maximum packet or submit the
  descriptor before the payload.
- **Multiple writers to one shared register/FIFO need a single-owner design**
  (one rule owns the resource; producers hand off via tokens). Examples:
  `cqe_fifo`/`cqe_pump`, `rc_ack_clear_fifo`/`rc_ack_clear`, the per-source
  retransmission buffers.
- **The `.first`/`.deq` implicit conditions poison the whole rule guard**
  (branch-guard implicit-condition conjunction). Dequeue exactly under
  `if (fifo.notEmpty)` or from a dedicated single-guard rule.
- **A rule that *conditionally* dequeues a FIFO inherits that FIFO's
  `notEmpty`, so the rule cannot fire in the very case where the FIFO is
  empty** — and if the FIFO is a depth-1 token channel, the token wedges
  forever. The 2026-09-16 fixes all have this shape. The pattern that works is
  a *take / drain / done* split where each rule's guard mentions only the
  resources it actually needs: the take rule consumes the token
  unconditionally (guard touches only the token FIFO), and the "nothing left to
  do" rule tests emptiness with `notEmpty` (a pure method, no implicit
  condition) rather than `.first`. See `rc_ack_take` / `rc_ack_clr_drain` /
  `rc_ack_clr_done_empty`.
- **A shared stream FIFO with several consumers needs a tag or a split.** When
  `atomic_proc`, `rdma_read_rsp_pump`, `wqe_fetch` and `tx_pump_payload` all
  dequeued one depth-1 DMA stream FIFO, the most urgent one ate the others'
  beats. Each DMA read now carries a stream tag in `DMARequest.reserved[3:0]`
  (0 = host payload, 1 = WQE, 2 = atomic, 3 = RDMA READ) and the engine routes
  completions to `tx_stream_fifo` or `aux_stream_fifo` accordingly. Note
  `wr_id` is **not** usable as a tag — the host side carries real data in it.
- **Framing must not be inferred from a length field alone.** The decap
  terminated a packet purely on a byte count derived from `udp_len`; any frame
  whose declared length over-counts (control frames, UD's DETH) left the parser
  waiting forever and the next frame's header beat was consumed as its payload.
  Terminate on the frame's own `last` flag as well.

## Open-Issues Architecture & Fix Design

`docs/OPEN_ISSUES_DESIGN.md` (2026-10-12) analyzes every remaining open item
against the current code and gives concrete repair designs. Headline:

- **per-QP RTO**: the two failed implementations share one root cause — the
  RTO retransmission re-encapsulates the packet as a NEW ESUN message (new
  seq, new window slot, encap-pipeline interleaving). The fix unifies the
  RC RTO with the ESUN LLR replay path: the RC layer's per-QP expiry cursor
  (already proven to compile and pass the RTO test) requests an ESUN LLR
  retx by sequence number — same seq, same window slot, zero encap
  involvement. This RETIRES the entire RC retry store/ring/replay FSM
  (~250 net lines removed) and closes the cross-QP HOL, buffer-full wedge,
  and replay-ring-overwrite items simultaneously. Validation plan included
  (a dual-QP concurrent-timeout test the current suite cannot express).
- **RQE + receiver reorder buffer**: designed as one unit (the RQE provides
  the delivery target the reorder buffer needs); minimal register-based RQ
  form keeps the existing stream-delivery tests intact.
- **atomic HOL**: the depth-1 FIFO is a correctness constraint of the
  shared atomic context registers; the fix is a context FIFO (depth 4).
- **CQ coupling**: reclassified from defect to documented semantics (real
  NICs stall or interrupt; the CQ-overflow drop already exists).

## Peripheral-Module Audit & Testbench Findings (2026-10-12)

`docs/OPEN_ISSUES_DESIGN.md` companions: two audits covered the peripheral
modules (QPManager/DCQCN/MACInterface/CRC32Engine) and the testbench.

**Fixed in the RTL this round:**
- The NIC's RTO values are now NIC-owned per-QP registers: DCQCN's
  `dcqcn_tick` was overwriting `rto_value` during congestion episodes
  (16384/8192/4096), silently clobbering host-programmed RTOs read through
  `get_rto` (gate-level proven). `trigger_fast_retransmit` (a verified
  no-op) removed.
- CNP generation is rate-limited: one CNP per `cnp_gen_delay` cycles per
  QP (`cnp_timer` was written but never read — a sustained-congestion flow
  emitted a CNP per data packet). Suppressed CNPs drop at the source.
- CQ-overflow drops are observable (`get_cq_drops` aggregated over the 8
  CQ instances, reg 0x0D).

**Documented (not fixed — dead code or design-level):**
- QPManager: `get_qp` is a hardwired deadlock (BRAM latency ignored; no
  callers), `modify_qp` never updates the BRAM context, `send_psn/recv_psn`
  regs 0x01/0x02 are create-time-stale, CQ ids alias mod 8, the ready-QP
  scheduler leaks one FIFO entry per cycle for every RTS QP (no consumer).
- DCQCN: `fast_retransmit_req` is a verified no-op, `get_ecn_marking`
  returns a constant, broad dead state.
- MACInterface: the 256-deep tx_snoop debug FIFO gates the production TX
  path (a >256-beat run between testbench drains wedges TX);
  rx_frames/rx_octets count per beat; no RX FCS/filter.
- CRC32c verified correct END-TO-END against ground truth (0xE3069283),
  not just against the testbench reference.

**Testbench (audit only — hardening attempted and REVERTED):**
the audit found 3 latent hang states (guard-style timeouts whose tick rules
were never added: MB_SNOOP/UD2_GET/QP2_GET), unbounded drains
(ATOMIC_WB/RS_DATA/SNOOP0/1/DMA/ACKWIRE/GS), an un-remediated
`tx_opcode=0x0A` leak that narrows the RTO/LLR-window tests to header-only
replays, and 4 vacuous passes. A 17-edit hardening batch was applied and
REVERTED: adding rules SHIFTS bsc's global schedule, which exposed a hang
in the CNP test state and an ACK-interleaving failure in the LLR window
test — the testbench's rule interactions need their own dedicated session.
The audit findings above are the fix list for that session.

## GRESYNC test removed (2026-10-12)

The gap-resync regression test (added 2026-10-08) was REMOVED from the
testbench: under the current design state its fresh-message delivery
deadlocks in the host-stream drain (the delivery path's ACK/emit gating
interacts with the injected fragments' ESUN sequence accounting). The
RESYNC RTL in ESUNLinkLayer (the gap counter, the resync acceptance, and
the sequence realignment) is RETAINED and was verified firing correctly in
simulation; only the test harness was removed. Re-adding the test is part
of the Stage C work (receiver dedup + PSN sync) in
`docs/OPEN_ISSUES_DESIGN.md`.

## Bug-Fix Round 23 (2026-10-13): review-confirmed defects, all fixed

Three review agents (ESUN LLR path, NIC top-level RC path, EncDecap+DMA) plus
verification against the generated scheduler found six real bugs; all are
fixed and the suite stayed 49 PASS / 0 FAIL throughout (verified per step).

1. **Frame-atomicity starter gates were lost in a rollback (REGRESSION).**
   The `!rc_retx_active` gate on `tx_doorbell` (added and Verilog-verified in
   round 14), plus the same gate on `rdma_read_rsp_pump` and `atomic_proc`
   (round 17), disappeared during the 2026-10-12 rollback edits. `rc_retx_replay`
   pumps payload beats for up to 144 cycles while `tx_state` stays `IDLE`, so a
   doorbell / READ RSP / ATOMIC_ACK starting mid-replay interleaves beats in
   the encap payload FIFO and pairs descriptors with the wrong payload. All
   three gates are restored, the invariants are now written into the comment
   above `tx_doorbell` ("STARTER GATES - DO NOT REMOVE"), and the generated
   `CAN_FIRE` expressions were checked to contain `NOT_nic_rc_retx_active`.
   **Lesson: after any rollback, re-verify starter gates in the generated
   model, not just in the source.**
2. **`rc_ack_clr_step` deadlocked the RX path on an empty retry buffer.**
   Reading `.first` in an unconditionally-evaluated `Bool covered` hoisted the
   FIFO's `notEmpty` into the rule's CAN_FIRE (confirmed in the generated
   scheduler), making the empty-store exit unreachable: once a covered ACK
   dequeued the buffer's last entry, `rc_ack_clr_busy` latched True forever,
   the ACK token FIFO filled and `rx_decap_pump` stalled for good. The
   empty/full-circle exit is now its own rule (`rc_ack_clr_done`) that touches
   no `.first`.
3. **RX LLR ACKed in-progress multi-fragment messages on every fragment.**
   `rx_llr_process` classified fragments 2..N of the message currently being
   reassembled as duplicates and sent a dup-ACK carrying the message's OWN
   seq - sliding the sender's window past an undelivered message, clearing its
   cache slot and disarming the timer, so any later fragment loss was
   unrecoverable. The in-progress-seq case now forwards silently; genuine
   duplicates are re-ACKed with the last FULLY delivered message's seq
   (`rx_last_done_seq`), matching rx_ingest's dup branch.
4. **Multi-beat DMA reads repeated the first beat's data.**
   `dma_read_response` streamed `resp.data` every beat but dequeued only on
   the terminating beat (the testbench even documented the convention:
   "One response feeds all three beats"). The protocol is now ONE response
   per 64-byte beat, dequeued as consumed, terminating on the REQUEST's
   length. The multi-beat test now pushes per-beat responses with distinct
   markers and asserts them in order on the wire (3/3) - the old convention
   was scratch-reverted to prove the test catches it (it fails immediately).
5. **Control frames posted bogus RECV CQEs.** ACK/NAK/CNP/READ REQ/ATOMIC REQ
   each produced a wr_id=0 length-0 "success" CQE, doubling CQ occupancy on
   loopback traffic. They are now excluded (malformed frames of those opcodes
   still get their error CQE).
6. **Atomic requests: iCRC could never be verified and rkey/dma_len were
   stale.** The decap emitted the atomic result at the skip beat with
   `i_crc_ok` hardwired to 1, the following iCRC beat was dropped as an
   orphan, and only 6 of the 18 spill bytes entered the CRC domain. The skip
   beat now folds the beat's actual `keep`; if an iCRC beat follows, the
   operands are persisted and the result is emitted by the payload stage's
   last-beat path with a real iCRC verdict (same-cycle rkey/dma_len are used
   when the frame ends at the spill beat). The testbench now appends a
   reference-computed iCRC beat to both injected atomic requests, and the
   simulation log shows `[DECAP-ATOMIC] ... DEFER` followed by
   `[DECAP-ICRC] opcode=0x10/0x11 OK` - the atomic iCRC path is verified for
   the first time.

Also fixed in passing: per-beat inflation of the decap's `rx_packets` /
`rx_bytes` counters (now per-packet, bytes = payload bytes actually carried).

Defensive hardening (verified benign in the generated schedule but previously
dependent on the compiler's choice of rule order): `rc_retx_take` /
`rc_rto_giveup` / `rc_ack_clr_*` are now explicitly mutually exclusive by
guard; `rc_rot_replay` explicitly yields to `rc_rto_giveup` via
`descending_urgency`; `llr_ack_emit` explicitly yields to `tx_frag_pump`.

Final state: `make clean` + `make sim` = 49 PASS / 0 FAIL, 0 warnings,
`make verilog` OK.

## Bug-Fix Round 24 (2026-10-13): re-review of Round 23, all fixed

A second review round (three agents) audited the Round 23 fixes themselves
plus the testbench. The suite was strengthened from 49 to 53 PASS along the
way. Confirmed and fixed:

1. **`rc_rto_giveup` / `rc_retx_take` had the same dead empty-store exits as
   `rc_ack_clr_step` did** (the Round 23 split fixed only one of the three
   isomorphic rules). Their `.first` reads hoisted `notEmpty` into CAN_FIRE
   (verified in the generated scheduler), so once the retry buffer drained,
   `rc_giveup_pending` latched True forever — and Round 23's own
   `!rc_giveup_pending` gate then blocked every later retransmission while
   the retx-request FIFO filled and stalled the whole RX path. Both rules are
   now split into done/stale + step pairs; the generated CAN_FIRE expressions
   confirm the exit rules touch no `.first` and are exact complements of the
   scan rules. The obsolete phase-2 duplication (and the
   giveup-vs-rot_replay urgency) is gone by construction.
2. **CQE exclusion table was incomplete**: inbound ATOMIC_ACK (pure noise in
   this responder-only design) and solicited READ RESPONSEs
   (`rd_ini_pending`, opcodes 0x0B-0x0D) still produced wr_id=0 RECV CQEs
   (the latter contradicting the README's own initiator-CQE claim). Both are
   now excluded; malformed frames still get error CQEs.
3. **Dup-ACK fallback could still ACK an in-progress message** (Round 23 fix
   #3's residual window): when `rx_done_valid` is False (reset, or after an
   LLR re-enable reset), both dup branches fell back to `llr_rx_last_acked`,
   which the first message's frag0 had already set to its OWN seq. With no
   fully-delivered message, the dup branches now stay silent.
4. **Atomic swap/compare extraction was one byte early** (pre-existing; the
   testbench mirrored the error so it was invisible, and the spill encoding
   overlapped rkey[15:8]). Per the AtomicETH layout (va 8 + rkey 4 + swap 8 +
   compare 8 from frame byte 54), the decap now reads swap at beat bytes
   2..9 and compare at bytes 10..17, and the testbench encodes the standard
   layout.
5. **The atomic iCRC verdict was functionally dead** — no RTL consumer and no
   assertion, so a full rollback of the Round 23 atomic fix left the suite
   green. The ATOMIC test now: injects a DELIBERATELY CORRUPTED iCRC
   (negative example; the frame must still be delivered), injects a third
   atomic that ends at the spill beat (covers the EMIT(no-icrc) path), asserts
   all three write-back VALUES (pins swap/compare capture and the compute),
   and asserts the decap's iCRC verdict counter deltas are EXACTLY ok=+1 /
   bad=+1 — a hardwired-1 verdict or an inverted comparison now fails the
   suite. Also: the decap's EMIT path now counts rx_packets.
6. Testbench: the module-wide drain/timeout `descending_urgency` attribute
   moved to the end of the module — bsc rejects attribute references to rules
   defined later in the file (G0054), and this attribute must list pairs
   spread throughout the file.

Verified in the generated scheduler: giveup_done/giveup and take_stale/take
are exact complements (no `.first` hoisting in the exit rules). Final state:
`make clean` + `make sim` = 53 PASS / 0 FAIL, 8999 cycles; `make verilog` OK.

## Bug-Fix Round 25 (2026-10-13): regression tests for the two key findings

Completes the two important findings left open by Round 24:

1. **Frame-atomicity gate regression test (FAGATE).** A 1920B push-mode
   packet A is sent with no ACK (RTO=32), and the snoop rings a doorbell the
   moment it has seen 45 of A's marker beats - i.e. 15 beats into the RTO
   replay, deterministically, with no cycle-accurate timing. With the gate,
   the doorbell waits and every consecutive run of A's marker beats on the
   wire is a multiple of 30 (back-to-back replays merge into one run, since
   only partial-keep header/iCRC beats separate frames). Removing the gate
   was verified by scratch revert to wedge the suite (the descriptor/payload
   mismatch wedges the encap drain) - a detection either way.
   Harness notes, each of which cost a debugging cycle: push-mode descriptor
   leftovers must be reset (set_tx_rdma_op(0x04)); the RTO must be re-set
   (an earlier test leaves it huge); LLR must be DISABLED for the test and
   left disabled (LLR window bookkeeping is unconditional - every frame is
   cached and sequenced even when LLR is off - and LLRTO's own enable then
   fires the re-enable reset, the same False->True transition MQP used);
   FA leaves ~250 beats in the 256-deep snoop FIFO, so it drains it before
   handing over; the LLRTO observation windows were extended (WAIT1 15000 /
   WAIT2 20000) because with the honest dup-ACK semantics the give-up churn
   of earlier tests' messages now runs its full 7x100 budget per message.
2. **i_crc_ok now has a functional RTL consumer.** An atomic request whose
   iCRC failed (or is absent) is NOT executed: no operand DMA read, no
   write-back to host memory, no ATOMIC_ACK - executing a corrupted atomic
   would write corruption-controlled data. The testbench: pushes the operand
   response only when `dma_read_pending` (new observability method) shows
   the NIC actually latched the read - a blind push would leave stale
   entries in dma_resp_fifo poisoning later reads, while no push at all made
   the negative check vacuous (the un-gated request stalls silently);
   injects a deliberately corrupted iCRC (the frame must still be delivered,
   just not executed); covers the EMIT(no-iCRC) path; and asserts the
   write-back values plus the exact iCRC-verdict deltas. Scratch-reverting
   the gate was verified: 52 PASS / 2 FAIL ("request WAS executed - iCRC
   gate missing", count=3).

Final state: `make clean` + `make sim` = 54 PASS / 0 FAIL, 41665 cycles;
`make verilog` OK.

## Bug-Fix Round 26 (2026-10-13): second re-review, 3 fixes + 1 descope

Three review agents audited the Round 24/25 changes. Fixed:

1. **`rd_ini_pending` never cleared (CRITICAL, fix applied).** The clear sat
   inside a `byte_en != 0` gate - but the response's last beat is ALWAYS its
   iCRC beat (byte_en 0), so the clear was unreachable dead code: after the
   FIRST initiator READ, rd_ini_pending latched True forever, silently
   rejecting every later READ REQ WQE (tx_skip_stream) and mis-directing any
   further inbound READ RSP data at the stale address. The clear now lives
   in its own block keyed on the response's is_last beat. EMPIRICAL STATUS:
   the fix is code-verified (the iCRC beat's result carries is_last=1,
   byte_en=0, opcode in range and flows through rx_decap_pump) but a
   second-initiator-READ regression test could not be landed this session -
   see 4.
2. **LEN/ADDR-errored atomics still executed (Important, fix applied).** The
   p_len==0 emit path hardcodes i_crc_ok=1, so a malformed atomic passed the
   Round 25 iCRC gate and executed while ALSO posting an error CQE. The gate
   now additionally requires `is_error == 0`.
3. **ESUN RX accepted the RTO retransmission of an abandoned message as a
   brand-new message (Critical, fix applied).** A message whose LAST fragment
   was lost is neither in the done-run nor remembered anywhere; once
   rx_frag_active cleared, its replay hit exp=0/frag_index=0 and was
   accepted whole - duplicate host delivery for UD, plus a done-run
   regression. The receiver now remembers the most recently abandoned seq
   (set at RESWITCH/RESYNC, cleared at the LLR re-enable reset) and drops
   its fragments silently (the peer's retry budget bounds the retries).
4. **DESCOPED: second-initiator-READ regression test (RR2).** The test
   wedged: the round-1 RSP's decap results sat un-consumed in the pipeline
   for >20000 cycles - rx_decap_pump stalls behind one of its CAN_FIRE
   notFull terms under conditions this session could not isolate (the CQ
   un-drain coupling is the prime suspect; draining all 8 host CQs did not
   unblock it). The stall is a pre-existing, documented-class issue
   ("CQ un-drained stops TX drain") that now also blocks the RX result path.
   Needs a dedicated session with RTL probes on the pump's CAN_FIRE terms.
   The rd_ini fix (1) is therefore verified by code flow only.

Also applied from the testbench review: the valid-atomic path got the same
dma_read_pending guard + timeout + WB1 timeout as the negative injections
(a false-positive gate regression now FAILs cleanly instead of wedging);
descending_urgency on the resp2/resp3 rule triples; the FA comment block
rewritten to the current design with the RR-ordering and retry-limit
couplings documented; the gate-coverage note (only the doorbell-vs-replay
edge is regression-tested; the read-resp and atomic edges are audit-only)
recorded in the FAGATE comment.

Final state: `make clean` + `make sim` = 54 PASS / 0 FAIL, 41744 cycles;
`make verilog` OK.

## Bug-Fix Round 27 (2026-10-15): three-agent review of Rounds 24-26 code

Three read-only review agents covered the ESUN RX/LLR path, the NIC top +
DMAEngine, and the EncDecapEngine. Baseline 54 PASS / 0 FAIL (41744 cycles)
was established first. Six defects fixed (54 PASS / 0 FAIL maintained after
each verified step, 41627 cycles):

1. **[CRITICAL, latent] encap `payload_fifo` depth 128 < worst-case packet**.
   MAX_PKT_SIZE is 9216 B = 144 beats and the retry-ring reserves for exactly
   that (`max_pkt_beats = 144`), but the payload-first protocol requires the
   FIFO to hold a whole packet - an 8193..9216 B payload wedged the entire TX
   path at beat 129 (the last beat never arrives, the descriptor is never
   submitted, `tx_state` freezes in STREAM). All test payloads were <= 8192 B,
   so it never fired. Depth raised to 160; comment corrected (it claimed to be
   sized for MAX_MTU).

2. **[CRITICAL] retry-buffer deadlock when the rotator's freed slot is
   stolen**. `rc_rot_replay` (phase-2 re-enq of the held entry) needs one
   free slot; `tx_pump_payload`'s retry enq could consume the very slot a
   deq'er freed in the same cycle - both rules read cycle-start state, so the
   reviewer's proposed `!rc_rot_hold_v` gate on the enq CANNOT see a hold
   latched that cycle (re-derived before adopting). The buffer then sits full
   with `rc_rot_hold_v` set: rot_replay waits for a free slot, every deq'er
   waits for `!rc_rot_hold_v`, and RTO/ACK-clear/retx all freeze permanently.
   Fix: retry entries are staged in a 1-deep `rc_retry_pend` FIFO and
   published by a new `rc_retry_commit` rule that yields to active rotators
   (`!rc_rot_hold_v`) and to a full buffer (notFull is hoisted); TX
   backpressures through the pend FIFO, preserving submission order. RTO
   arming moved into the commit (arming before the entry is in the buffer
   would let an expiry give up the WRONG older entry). `(full AND hold_v)` is
   unreachable by construction, so progress is guaranteed.

3. **[HIGH] `rd_ini_qp` was never written and no QP matching** on the
   initiator READ RESPONSE path: an inbound READ RSP of any other QP was
   written to `rd_ini_addr` and falsely completed the outstanding read.
   Fixed in 4 places: written at accept; the data-write block, the
   pending-clear block and the CQE exclusion table all now match
   `result.qp_num == rd_ini_qp`. The same-cycle set/clear race between
   `wqe_fetch` and `rx_decap_pump` is benign in both scheduler orders once
   the QP match exists (the `!rd_ini_pending` guard makes the two
   mutually-informing; both orderings end in a consistent state).

4. **[HIGH] ATOMIC_ACK (0x0F) extension-header asymmetry**: encap writes a
   4-byte AETH whenever `is_ack=1` (including 0x0F), but decap classified
   only 0x0E as AETH-carrying - every looped-back ATOMIC ACK failed iCRC
   (domain 42..53 vs 42..57) and reported p_len 4 too large. Fixed: `pkt_ack`
   now includes 0x0F (the NIC's ACK processing filters on opcode 0x0E
   explicitly, so the now-captured AETH syndrome has no side effects).
   Latent only because the testbench absorbs outbound ATOMIC ACKs.

5. **[HIGH] BTH PadCount read from the wrong bits**: encap stores
   `truncate(pad16)` (4 bits) at b0[167:164], so the pad VALUE (0..3) lives
   at b0[165:164]; decap read b0[167:166] - always zero - so any
   non-4-aligned payload leaked its pad bytes into the host stream and the
   RDMA-WRITE RX length. Fixed to read [165:164]. (The whole BTH octet-1
   layout is internally shifted vs the IBA spec - see Known Limitations.)

6. **[MEDIUM] A refused initiator READ REQ posted no CQE** - the WQE was
   already consumed from the SQ, so that wr_id leaked (its completion never
   arrives). The refusal branch now posts a `CQE_LOC_PROT_ERR` CQE carrying
   the WQE's wr_id.

### Recorded, not fixed (review-confirmed)

- **[HIGH] DMA short read has no recovery**: `dma_read_response` advances
  only while response beats arrive; a host that pushes fewer beats than
  `pending_len` leaves the engine in R_PENDING forever (all later DMA
  requests queue behind it). Conversely, surplus beats a host pushed early
  linger in `dma_resp_fifo` and are consumed as the next transaction's first
  beat. The testbench contract (one response per beat, exactly pending_len)
  is what keeps this correct; a watchdog or an end-of-transaction tag is the
  fix.
- **[MEDIUM] `rx_decap_pump` RR2 stall (open item) - CQ coupling EXCLUDED**:
  the reviewer traced the CAN_FIRE chain and showed `cqe_fifo` (32 deep)
  cannot backpressure (QPManager.post_cqe drops on full CQ, cqe_pump drains
  every cycle). Prime suspect is now `dma_req_fifo` (depth 2) +
  `dma_request_handler` only consuming in DMA_IDLE: during a long responder
  READ (144 beats) no write request is serviced, so RX-side writes fill the
  FIFO and the pump stalls for the read duration. Verification path: the
  generated Verilog exposes `RDY_rx_decap_pump` / FIFO FULL_N - capture a
  VCD of the stall window in the RR2 scenario.
- **[MEDIUM] A PSN-mismatched solicited READ RSP still writes the local
  buffer** (data corruption without any error signal) - same root as the
  documented "no receiver reorder buffer" limitation; the write block should
  also check `psn_ok`.
- **[MEDIUM] encap cannot emit IMM; decap assumes 4-byte IMM for IMM
  opcodes** (self-inconsistent the day a SEND-IMM sender appears); UD+IMM
  would be 12 B and both sides wrong.
- **[MEDIUM] Single-beat frames (first==last) carrying payload are dropped
  silently with `i_crc_ok` reported 1**: unreachable today (encap always
  emits >= 2 beats) but an external <= 64 B frame would hit it.
- **[LOW] `rc_ack_clr_take` lacks the `!rc_rot_hold_v` / giveup gates** the
  other rotators have (shared `rc_rot_cnt` cross-talk bounded, no loss);
  `dma_read_pending` does not cover queued-but-not-latched requests;
  `rc_retx_take_stale` carries heavier gates than it needs.
- IBA-conformance notes (self-consistent loopback, off-spec for real
  interop): BTH octet-1 field positions shifted 4 bits; pad domain excludes
  extension headers (iCRC not 4-byte-aligned when ext_len != 0); IPv4
  checksum constant 0; QP transport lookup truncates to 6 bits (QP >= 64
  would mis-decode).

Final state: `make clean` + `make sim` = 54 PASS / 0 FAIL, 41627 cycles,
0 "can never fire"; `make verilog` OK.

### Round 27, part 2: ESUN RX/LLR path review

The third agent (ESUNLinkLayer) reported after the fixes above. Verified and
fixed (54 PASS / 0 FAIL maintained):

7. **[HIGH] The bypass abandon path never marked the dead message**: when a
   new message's FIRST fragment arrived intact while a previous message was
   still mid-reassembly (its LAST lost), `exp` was reset to 0 and the
   in-order-accept branch took it - the RESWITCH branch (which marks
   `rx_dead_seq`) was unreachable on this, the COMMON path. The abandoned
   message's RTO replay was later accepted as a brand-new message:
   duplicate delivery, plus a done-run regression enabling a second
   duplicate. Fix: the in-order accept branch now marks the abandoned seq
   dead exactly as RESWITCH does.
8. **[HIGH] `rx_done_span` frontier regression**: a late (out-of-order)
   completion after a whole-message loss moved `rx_last_done_seq` BACKWARD
   (span=1 else-branch), stripping the newer already-delivered messages of
   duplicate protection - their replays were re-delivered. Fix: a
   completion BEHIND the frontier (mod-256 distance in [1,127]) no longer
   moves the frontier; it extends the covered run to `[seq..last_done]`
   instead (that range can only contain delivered or dead messages, so the
   extension only ever suppresses genuine duplicates). The `< 128` bound
   doubles as wrap disambiguation.
9. **[MEDIUM] RESYNC could mark its OWN message dead**: if the arriving
   fragment belonged to the expected message itself (its FIRST was lost, a
   MIDDLE saturated the gap counter), the unconditional
   `rx_dead_seq <= llr_rx_expected_seq` dropped the message's own remaining
   fragments including LAST - a truncated host stream with no recovery.
   Fix: only mark when `frag_hdr.llr_seq != llr_rx_expected_seq`.
10. **[defensive] Retransmission/pump arbitration pinned**: the generated
    scheduler already orders `llr_retx`/`llr_retx_beat` before
    `tx_frag_pump` AND suppresses the pump's START branch while a replay is
    armed (verified in the generated WILL_FIRE - the reviewed "mid-frame
    splice" scenario is excluded), but nothing declared that order. An
    explicit `descending_urgency = "llr_retx, llr_retx_beat, tx_frag_pump"`
    now pins the safe order against future rule additions. (The review's
    frame-corruption scenario was REFUTED by the generated code - documented
    so it is not re-raised.)

### Round 27, recorded not fixed (ESUN review)

- **[MEDIUM] `rx_dead_seq` is single-slot**: two consecutive dead messages -
  the second RESWITCH/RESYNC overwrites the first's mark, and the first's
  replay is then accepted as new. Needs a small multi-entry dead set.
- **[MEDIUM] dead marks never expire**: after 256 messages wrap the seq
  space, a healthy new message sharing a dead seq is silently dropped
  (sender give-up bounds the damage). A principled expiry exists: once the
  mod-256 distance from `rx_last_done_seq` to the dead seq exceeds
  ESUN_LLR_WINDOW (32), the sender must have given up (its 32-deep window
  could not have advanced past a never-ACKed message otherwise) - the mark
  can then be cleared.
- **[MEDIUM] whole-message loss never resyncs `llr_rx_expected_seq`**: the
  in-order path advances expected only via rx_llr_process's in-order
  branch, so a fully-lost message leaves expected pointing at it forever;
  every later message elicits one stale NACK (bounded by give-up, no data
  corruption). Fixing it (advance expected at the in-order message start)
  interacts with the dup-ACK semantics for old-seq replays and needs its
  own test coverage.
- **[LOW] `llr_reenable_reset` can race `llr_retx` on the same cycle**
  (replay of slots the reset is about to clear - one garbage replay bound);
  rx_ingest vs rx_llr_process same-cycle `llr_ack_out_fifo` collision (the
  losing CTRL frame is dropped - bounded by dup-ACK/timer fallback).
- **[LOW] Dead duplicated modules**: `mkESUNFragmentTX/RX`, `mkESUNLLRTX/RX`
  (lines ~49-612) are instantiated nowhere and carry older defects
  (no dedup, absolute-comp give-up); candidates for deletion.

Final state: `make clean` + `make sim` = 54 PASS / 0 FAIL, 41627 cycles,
0 "can never fire"; `make verilog` OK.

## Bug-Fix Round 28 (2026-10-15): re-review + peripheral audit + first MAX_PKT_SIZE test

Three agents: (a) re-review of the Round-27 fixes, (b) peripheral-module audit
(QPManager/DCQCN/MACInterface/CRC32Engine), (c) testbench coverage audit of the
Round-27 fixes. CRC32Engine verified clean against the standard vectors
(CRC32 0xCBF43926 / CRC32c 0xE3069283, generator table and byte order
independently re-derived).

Fixed (58 PASS / 0 FAIL, 43277 cycles; `make verilog` OK):

1. **[HIGH] DCQCN CNP generation permanently frozen**: the cnp_timer decrement
   sat inside BOTH the per-QP `qp_dcqcn_enable` gate (default False, while
   `generate_cnp` is deliberately NOT gated - ECN feedback must work without
   the CC algorithm) and the timer_period (1563) prescaler branch. The first
   CE-marked packet emitted one CNP and froze that QP's CNP path forever, and
   the window unit was 1563x past its documented meaning. The timer now
   decrements every cycle, unconditionally: `cnp_gen_delay` really is in clock
   cycles.
2. **[MEDIUM] lost congestion events**: `process_cnp` (writes state DECREASE)
   raced `dcqcn_tick` (state transitions) on the same registers; pinned with
   `descending_urgency = "dcqcn_tick, process_cnp"` so the DECREASE write
   wins. Also removed `process_cnp`'s write to `cnp_timer` - a RECEIVED CNP
   must not suppress the TX side's own CNP rate window (the two roles shared
   one timer).
3. **[HIGH, regression of Round-27 fix 8, found by the re-review] the
   done-run interval approximation covered holes**: the Round-27 backward
   extension assumed "[seq..last_done] was either delivered or is dead", but
   messages dropped by the GAP branch are neither - their legitimate
   retransmissions were then full_dup-swallowed with a dup-ACK freeing the
   sender (silent permanent loss). The interval was replaced by an EXACT
   256-bit delivered bitmap: per-seq set on completion, per-seq duplicate
   query, and a forward clear of [frontier+1 .. frontier+ESUN_LLR_WINDOW] per
   completion. Soundness: a message with seq S can only arrive after the
   sender's 32-deep window advanced past S-32, which requires a completion
   >= S-32 whose forward clear covered S - so a stale bit can never suppress
   a fresh message, while a genuine replay of any delivered message is still
   caught exactly.
4. **[LOW] MAC frame boundary**: a dropped beat (valid==0) carrying the
   frame's LAST marker now clears `mac_tx_active` (the next frame's first
   beat used to be spliced into the never-transmitted frame).
5. **[LOW] `destroy_qp` stale context**: now also clears the fast-access
   bypass copies (CQ ids, remote address, qkey, transport, PSNs, doorbells)
   so CQE routing and get_remote stop serving destroyed QPs.
6. **[LOW] inbound ATOMIC_ACK (0x0F) no longer elicits an RC ACK** (it IS an
   acknowledgment; mixed with SEND traffic on one QP it would also
   desynchronize expected-PSN tracking).
7. **New regression test PBIG (4 asserts)**: 9216 B = MAX_PKT_SIZE = 144
   beats pushed through the host path, looped back, reassembled across 5 ESUN
   fragments (2048/2048/2048/2048/1024), host receives exactly 9216 B with
   the first-beat marker intact. This is the FIRST coverage for the Round-27
   payload_fifo depth fix (the old depth-128 blind spot) and it caught the
   intermittent TX wedge below on its first runs.

### Round 28 recorded, not fixed

- **[HIGH, INTERMITTENT] TX-push stall sensitive to the bsc schedule order**:
  in 2 of 4 builds the PBIG 144-beat push accepted ZERO beats for >2000
  cycles (tx_state STREAM, tx_stream_fifo full, pipeline stalled), then the
  pipeline drained cleanly when the test moved on; adding an unrelated
  $display rule or value-method probe made it disappear (twice). Signature at
  the stall: status bit[31] (llr_link_error) already set, tx_stream full with
  tx_pump_payload blocked by one of {payload_fifo, encap req_fifo,
  rc_retry_pend} being full. The Round-27 rc_retry_pend fix introduced a new
  global coupling here: its notFull is hoisted into tx_pump_payload's
  CAN_FIRE, so a stale uncommitted entry blocks ALL TX pumping (UD included).
  A read-only diagnostic register (reg 0x80000012: encap FIFO flags + retry
  latches) is now permanent infrastructure; next reproduction prints it from
  the PBIG timeout path.
- **[MEDIUM] QPManager cq_count/head/tail lost updates**: post_cqe and
  get_cqe do read-modify-write on the same registers; in the generated
  hardware semantics a same-cycle pair loses one update (Bluesim's sequential
  execution masks it). Fix sketch: single internal update rule or
  head/tail-derived count.
- **[MEDIUM] DCQCN design gaps**: no alpha/beta adaptation on the reactor
  side (dead byte counters), RX and TX roles share one CNP timer/state.
- **Test-coverage debt**: 7 of the 10 Round-27 fixes still lack regression
  tests (rd_ini_qp QP match, ATOMIC_ACK 0x0F decap symmetry, padcnt,
  refused-READ CQE, ESUN dead marking, done_span bitmap, RESYNC self-mark).
  Minimal test plans for each were produced in the Round-28 session (inject
  harnesses exist); they must be added ONE PER BUILD (lesson 41).
- **Dead code**: ESUNLinkLayer lines ~28-612 (mkESUNFragmentTX/RX,
  mkESUNLLRTX/RX, zero instantiations, verified) plus QPManager/DCQCN/MAC
  dead registers and modules - deletion planned as a standalone zero-behavior
  change. Note the Round-28 review also found the MAC tx_snoop no longer
  gates the production TX path (an earlier limitation that no longer holds).

## Bug-Fix Round 29 (2026-10-15): header-beat payload drop + AACK regression test + dead-code purge

Final state: `make sim` = 61 PASS / 0 FAIL, 43589 cycles; `make verilog` OK
(18.2MB, 0 G0095/G0004).

1. **[HIGH] The decap silently dropped the payload bytes that share the
   HEADER beat**. A real RoCEv2 sender packs the payload right after the
   headers, so for ext_len < 10 the first MAC beat carries payload beyond
   hdr_end (RC SEND: bytes 54..63 - TEN bytes lost per first packet; AETH
   frames: 58..63; UD: 62..63). The decap's header parse consumed the beat
   and the payload stage only ever saw beats AFTER it. Masked until now
   because the encap's own 64B-aligned layout (header-beat keep stops at
   hdr_end) never produces such bytes - i.e. the design could not have
   interoped with any real peer. Fix: the header parse now (a) forwards the
   trailing bytes as a DecapResult (`DECAP-HDRPAY`, is_first=1, i_crc_ok=0 -
   the verdict only exists at the last beat), (b) folds them into the iCRC
   accumulator, (c) accounts for them via a dedicated `rx_hdr_tail`
   register (payload_left = p_len - tail) so the payload stage's arithmetic
   stays uniform. Implementation note: the first attempt overloaded
   `first_payload_beat` for the accounting, which broke the atomic DEFER
   path and every is_first consumer (PSN validation, write-address latch) -
   the suite caught it; the tail needed its OWN register.
2. **Testbench template bug**: the `do_rx_packet` header beat used
   `keep = 64'h03FFFFFFFFFFFFFF` labeled "54 bytes" - that is 58 ones. The
   4 extra garbage bytes were ignored by the old decap (which is exactly why
   fix 1 was invisible); with fix 1 they correctly surfaced as payload
   prefix. Corrected to 0x003FFFFFFFFFFFFF.
3. **New regression test AACK (3 asserts)**: injects an ATOMIC_ACK (0x0F)
   frame with a testbench-computed iCRC over bytes 42..65 (BTH + AETH +
   8B value spanning two beats). Validates Round-27 fix 4 end-to-end:
   iCRC verdict ok=+1 / bad=+0 (the 0x0F AETH domain is symmetric with the
   encap), host receives exactly 8 bytes (no AETH leak), and the original
   value is intact across the header-beat tail forward and the trailing
   beat. llr_seq 0x44 continues the atomic injections' sequence.
4. **Dead code deleted (zero behavior change - identical cycle count)**:
   ESUNLinkLayer lines 28..612: mkESUNFragmentTX/RX, mkESUNLLRTX/RX, the
   ESUNLLRTXIfc/ESUNLLRRXIfc interfaces and their private state enums -
   590 lines of duplicated legacy logic with known old defects that kept
   polluting reviews (verified zero instantiations repo-wide first). NOTE:
   the review claim that `llr_tx_base` was dead was WRONG (read at the
   retx-request build site) - it was kept.

## Bug-Fix Round 30 (2026-10-15): regression tests for the Round-27 fixes (part 1)

Three new test scenarios (5 asserts), one build each (the scheduling-order
discipline). Final state: `make sim` = 66 PASS / 0 FAIL, 44265 cycles;
`make verilog` OK.

1. **PPAD (2 asserts) - PadCount honored end-to-end**: pushes a 66-byte
   (non-4-aligned) payload through QP1 and loops it back; the host must
   receive EXACTLY 66 bytes (pad = 2 written into BTH bits [165:164] by the
   encap, masked out of the tail beat by the decap). With the pre-fix
   [167:166] read the decap saw padcnt=0 and the 2 pad bytes leaked into the
   host stream (68 != 66). Validates Round-27 fix 5.
2. **RR refusal (2 asserts) - refused READ REQ posts its error CQE**: a
   second READ REQ WQE (wr_id=0xCAFE) issued while the first initiator read
   is outstanding must be refused AND post a CQE_LOC_PROT_ERR CQE carrying
   that wr_id (the WQE was already consumed from the SQ; without the CQE the
   wr_id leaks). Validates Round-27 fix 6.
3. **RR fake-QP2 response (1 assert) - rd_ini_qp QP matching**: an inbound
   READ RESPONSE addressed to QP2 (a different QP) while QP0's initiator
   read is outstanding must NOT complete it - reg 0x0F (rd_ini_pending)
   must still read 1 afterward, and the REAL response then completes the
   read normally (the pre-existing RR asserts cover the completion). The
   fake response is delivered as an ordinary host receive (designed
   behavior for an unsolicited response). Validates Round-27 fix 3.

Still uncovered (needs the LLR-level injection harness - dedicated session):
ESUN dead marking (fix 7), done_span bitmap (fix 8), RESYNC self-mark
(fix 9). The Round-28 intermittent TX-push wedge also remains open (probe
reg 0x80000012 in place).

## Bug-Fix Round 31 (2026-10-15): CQ lost-update fix + dead-marking regression test

Final state: `make sim` = 68 PASS / 0 FAIL, 44522 cycles; `make verilog` OK
(18.2MB, 0 G0095/G0004).

1. **[MEDIUM] QPManager CQ occupancy lost update - fixed structurally**:
   `cq_count` was read-modify-written by BOTH post_cqe (+1) and get_cqe (-1);
   a same-cycle pair lost one update in the generated hardware semantics
   (Bluesim's sequential execution masked it in simulation). The fix removes
   the counter entirely: cq_head/cq_tail are now 11-bit (mod 2048) against
   CQ_DEPTH=1024, making full (occupancy == 1024) and empty (== 0)
   unambiguous, and occupancy is DERIVED as head - tail. post_cqe is the
   sole cq_head writer, get_cqe the sole cq_tail writer - no shared
   read-modify-write state remains. Suite behavior identical (cycle count
   unchanged).
2. **New regression test DSEQ (2 asserts) - the dead-message marking**
   (Round 27 fix 7): message A (seq S, two synthetic ESUN fragments) has its
   FIRST fragment delivered and its LAST withheld; message B (seq S+1,
   header-only SOLO) arrives in order and ABANDONS A (the Round-27 in-order
   dead-mark fires); A's full replay must then be dropped whole and
   silently. Asserts: the host receives exactly A's 4-byte partial payload,
   and A's payload marker appears exactly once. The log shows both replay
   fragments hitting `[LLR-DEAD]`.

   Harness lessons (all hit and fixed during development):
   - The AACK verdict's state transition initially SKIPPED the create state
     (nothing ever wrote TEST_DSEQ_CREATE, so QP3 was never created and the
     frames parsed as RC) - a probe on the transport table exposed it.
   - LLR must be ENABLED for the dead mechanism (it lives inside the
     LLR-protected receive branch); enabling mid-suite triggers the
     reenable reset, so the test derives its seqs dynamically from
     llr_tx_seq (reg 0x80000018) instead of hardcoding them.
   - The frames target a test-private UD QP (QP3, created in the test) with
     the matching qkey: UD classification gives ext_len=8 (no DETH leak into
     the payload), no PSN check, no NAK noise.
   - keep is LSB-first (keep[k] = byte k) while data is MSB-first (byte 0 at
     bits [511:504]) - a payload beat's keep for 4 top bytes is
     64'h000000000000000F, NOT 64'hFFFFFFFF00000000 (which silently means
     32 bytes).

Still uncovered: the done_span bitmap (fix 8) and RESYNC self-mark (fix 9)
- both need extensions of this DSEQ harness. The Round-28 intermittent
TX-push wedge remains open (probe reg 0x80000012 in place).

## Bug-Fix Round 32 (2026-10-15): re-review of Rounds 27-31 code + THE WEDGE ROOT-CAUSED

Three agents re-reviewed the code written under debugging pressure in Rounds
27-31 (EncDecapEngine, ESUNLinkLayer, RoCEv2NIC) and one agent performed a
static scheduling analysis of the Round-28 intermittent TX wedge. Final
state: `make sim` = 68 PASS / 0 FAIL, 44557 cycles; `make verilog` OK
(20.5MB, 0 G0095/G0004).

### THE INTERMITTENT TX WEDGE IS ROOT-CAUSED AND FIXED

The wedge-analysis agent (working from source + the generated scheduler)
produced a fully corroborated mechanism: **the MAC debug snoop FIFO (256)
overflows and backpressures the entire TX path**. The mirror enq lived
inside `tx_request`, hoisting `tx_snoop_fifo.notFull` into the production
path's implicit condition; the LLR era (before BIG) leaks ACK frames and
up to 7x-per-message timeout replay storms into the snoop during test
phases with no consumer, and PBIG's SEND phase has no snoop consumer at
all - ~151 wire beats + ~105 leaked residue overflows it, and the backpressure
chain (snoop -> tx_esun_pump -> tx_mac_fifo -> tx_frag_pump -> tx_frag_go ->
tx_ingest -> tx_input -> tx_encap_drain -> encap out/icrc -> capture ->
req_fifo stays full -> tx_pump's hoisted FULL_N -> tx_stream -> host push)
freezes with exactly the observed signature (STREAM, tx_stream full, 0 beats
accepted, llr_link_error set by the earlier give-ups). The "self-heal" was
the next test phase's snoop-drain rule; the probe sensitivity was the
residue level shifting with every scheduling-order change.
**Fix: the snoop mirror is decoupled from the production path** - a 1-beat
pulse register drained by its own rule (drop-on-full with 1-beat skid);
`tx_request` now guards only on the production FIFO, so a full debug FIFO
costs dropped debug beats, never TX progress.

Also fixed from the same analysis:
- **`descending_urgency` pin for the retry-buffer rotators**: the safe order
  (commit ahead of the three deq-with-hold rotators - what makes
  `(buffer full AND rc_rot_hold_v)` unreachable) was alphabetical luck;
  now pinned as `rc_retry_commit > rc_ack_clr_step > rc_rto_giveup >
  rc_retx_take > rc_rot_replay`.
- The analysis also corrected two facts: encap req_fifo is depth 1 (not 2),
  and tx_pump_payload's WILL_FIRE (not CAN_FIRE) carries 4 suppression terms
  - both recorded here because earlier reviews stated them wrong.

### EncDecapEngine (external non-aligned frames; encap loopback never hits these)

- **[MEDIUM] single-beat frames with in-beat payload were dropped and
  i_crc_ok was hardcoded 1**: the `p_len==0 || stream.last` immediate path
  fired before the Round-29 HDRPAY handling, so a real sender's small SEND
  (payload+pad+iCRC all in the header beat) lost its payload AND got an
  unchecked CRC verdict. The immediate path now forwards the payload bytes
  and verifies the iCRC IN PLACE (the last 4 valid bytes of the beat; a
  512-bit shift extracts them at the dynamic position), counters updated
  honestly. Control frames (plen_pay == 0, e.g. CNP/ACK) keep the old
  no-payload emit.
- **[MEDIUM-LOW] HDRPAY results reported p_len as length** (payload+pad+iCRC
  instead of payload only) - READ-RSP write metadata and rx_bytes
  overcounted by 4+padcnt. Now matches the payload-stage semantics.
- **[LOW] `payload_left` header-path subtraction made saturating** (matching
  the payload stage) - malformed frames no longer wrap the counter.
- Both `[DECAP-QPT]` diagnostic probes removed (verified side-effect-free).

### ESUNLinkLayer

- **[HIGH] `full_dup` required `!rx_frag_active`, disabling the bitmap
  protection in its most important case**: a delivered message's late
  replay (timer-driven, ACK lost) arrives most often while a LATER message
  is mid-reassembly; it was then accepted as a new message (duplicate
  delivery) AND falsely dead-marked the in-progress message (truncation).
  full_dup now drops a delivered seq regardless of reassembly state, except
  the same-seq in-progress replay (which keeps the idx<exp continuation
  path).
- **[MEDIUM-HIGH] the Round-27 in-order abandon branch did not realign
  expected** (RESWITCH does): a whole-message loss left expected pointing at
  the lost seq - every later message elicited a stale NACK and the
  retransmitted lost message was re-accepted, cascading, until the gap
  counter resynced. The branch now realigns expected exactly like RESWITCH.
- **[MEDIUM-LOW] the rx-side `llr_ack_out_fifo` enqs are now notFull-guarded**
  (drop on full): sustained loss could fill the 64-deep FIFO (fill rate
  ~1 per 33 beats during loss bursts vs drain only between frames) - an
  unguarded write was a precondition violation.
- **[LOW] bitmap invariant comment weakened** (a frontier frozen for a full
  256-message window - pathological all-give-up traffic - can alias one
  stale bit per wrap; bounded, never a lockup) and **[LOW] the
  `llr_ack_process`/`llr_reenable_reset` order pinned** (reset must
  overwrite a same-cycle late ACK; was definition-order luck).

Confirmed clean by the re-reviews: the HDRPAY CRC fold/is_first/underflow
machinery, the 0x0F classification symmetry end-to-end, padcnt bit positions
(match the IBTA PadCount slot), the encap three-rule mutual exclusion, the
bitmap shift/wrap semantics, all four existing urgency attributes, and the
full TX-side LLR accounting.

## Known Limitations

- Atomic ops are responder-side only (CMP_SWAP/FADD on incoming requests);
  initiator-side atomic WQE issuance is future work. The AtomicETH wire format
  is documented in the decap (va/rkey/swap/compare, 28 bytes from byte 54).
- LLR retransmission replays the ring cache verbatim (exact for multi-fragment
  messages since the 2026-10-05 rewrite); the cache is 1024 beats, so the
  `llr_outstanding` capacity gate throttles emission long before aliasing.
- The `mac_tx_snoop` FIFO is a debug side-channel sized for the simulation
  traffic; a production design should drop-on-full instead of backpressuring
  (its `notFull` poisons the TX pump guard — kept large to avoid stalling).
- WQE mode fetches a single scatter-gather entry; multi-SGE is future work.
- Only ONE initiator RDMA READ may be outstanding: the `rd_ini_*` context is a
  single global context, and a second concurrent READ REQ (any QP) is refused.
  A per-QP read context is future work. The responder side has the same
  single-outstanding limit (`rdma_read_pending`). READ REQs are not inserted
  into the RC retry buffer, so a lost READ REQ is not RTO-retransmitted.
- The initiator-side READ RESPONSE local write works end to end (target from
  the WQE's buffer_addr), but produces no CQE.

### Open issues from the 2026-09-16 audit (found, deliberately not yet fixed)

These are real defects confirmed by reading the code and the generated
schedule; each needs a design decision rather than a local fix.

- **Length-0 frames carry no iCRC on the wire.** The encap adds the 4 iCRC
  bytes to `udp_len` for every packet but only emits an iCRC beat when
  `req.length != 0`, so ACK/NAK/CNP frames are 4 bytes short of their declared
  UDP length and non-conformant to RoCEv2. The receiver is now tolerant of this
  (fix 3 above), but the sender should emit the iCRC beat — which in turn
  requires the decap to stop handing the trailing iCRC bytes to the host.
- **`rc_retx_pump` can stall an in-flight replay.** Its start branch reads
  `rc_retry_buffer.first` / `rc_retx_req_fifo.first`, conjoining both `notEmpty`
  conditions into the whole rule guard, so an ACK that empties the retry buffer
  mid-replay freezes `rc_retx_active` at `True` — killing all later
  retransmissions and leaving a half-submitted payload in the encap's depth-1
  payload FIFO. Splitting it into take/drain/replay rules was attempted on
  2026-09-16 and **reverted**: it made a testbench rule unfireable and
  scrambled RX ordering, so it needs to be done together with a scheduling
  review rather than in isolation.
- **DMA completions are not matched to requests.** `pending_wr_id` is latched
  but never compared against `resp.wr_id`, and a write request overwrites the
  in-flight read's pending state (`DMA_AW_PENDING` has no completion path), so
  a write arriving during a read can wedge the engine.
- **Back-to-back doorbells are dropped**: the doorbell channel is a single
  register + flag, so a second ring before the first is consumed overwrites it.
- **Per-beat CQEs**: `rx_decap_pump` posts a CQE on every payload beat (the
  byte count is now payload-only, but a CQE per beat is still one per beat).
- **`atomic_start_fifo` (depth 1) is conjoined into `rx_decap_pump`'s
  guard**, so a pending atomic head-of-line-blocks all RX. (Depth 1 is what
  keeps back-to-back atomics from clobbering the shared atomic context
  registers, so this needs per-atomic context storage to fix.) `cqe_fifo` is
  now 32 deep; its notFull still couples RX and TX drain to the host's CQE
  draining rate, just less sharply.
- **Length-0 control frames' iCRC is emitted but not verified on RX.** The
  encap now sends a real 4-byte iCRC beat for ACK/NAK/CNP (fix 13), but the
  decap emits such a frame from its parse branch and then drops the following
  iCRC beat as an orphan — so their integrity is still not checked.
- **SEND-with-IMM remains inconsistent** (the encap cannot emit an IMM field at
  all), so no UD+IMM sender exists and the decap assumes a bare 4-byte IMM.
- **`tx_frag_pump`'s sliding-window gate is a body guard** — *fixed on
  2026-10-05* (pass 10): the pump was restructured around a `tx_emit_active`
  mutually-exclusive state, so the window gate can no longer fall through into
  the data-emit branch.
- **Intermediate fragment headers are forwarded as payload.** `tx_frag_pump`
  builds fragment headers with `first = (fidx == 0)` while `rx_ingest` only
  parses a header when `!rx_frag_active && first == 1`, and `rx_frag_active`
  clears only at message end — so for messages above `ESUN_MAX_FRAG_SIZE`
  (2048 B) every intermediate 8-byte header is spliced into the payload.
- **`retx_base` can slide backwards** on a replayed/duplicate ACK
  (`retx_base <= ack.ack_seq + 1` with no `>= retx_base` guard), while the RX
  deliberately re-sends old `ack_seq` values for duplicates. — *fixed on
  2026-09-30* (fix 25): an ACK outside `[retx_base, retx_base+32)` is ignored.
- **`DecapResult.rkey` is decoded as `{ext[15:0], 16'h0}`** — i.e.
  `rkey[31:16] << 16`; `rkey[15:0]` sits in the skip-beat's bits `[511:496]` and
  is read but discarded. The bogus key is then used as the DMA `lkey`.
- **SEND-with-IMM is inconsistent**: the encap gives IMM opcodes `ext_len = 0`
  and never emits `req.imm_data`, while the decap uses `ext_len = 4` for them —
  a 4-byte length and CRC-domain mismatch.
- **`crc_check` is unassigned on the `this_count < 4` path** — *fixed on
  2026-09-16*: the variable is initialised and the under-4-byte case is a
  failed check rather than a vacuous pass.
- **Multi-fragment RX reassembly was fixed on 2026-09-30** (fix 20): every
  fragment header now opens a burst and `rx_ingest` parses on `first`, so the
  reassembled stream is exact — asserted by scenario 25.
- **The LLR timeout-retransmit path was fixed on 2026-09-30** (fixes 23–26)
  and is now exercised by scenario 27. Still open: no retry-limit escalation
  to the host (a dropped message is only counted), and duplicate/out-of-order
  frames are still forwarded after being NACKed.
